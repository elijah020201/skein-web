#include "GrimoireGameInstance.h"
#include "UI/GrimoireUpdateChecker.h"
#include "UI/SGrimoireScreenManager.h"
#include "UI/GrimoireStyle.h"
#include "Engine/GameViewportClient.h"
#include "Fonts/CompositeFont.h"
#include "Fonts/SlateFontInfo.h"
#include "Styling/CoreStyle.h"

// ============================================================
//  GRIMOIRE APP — Game Instance
//  GrimoireGameInstance.cpp
// ============================================================

// Font store — keyed "Family.Typeface" e.g. "Cinzel.Bold"
static TMap<FName, FSlateFontInfo> GGrimoireFonts;

static void RegisterGrimoireFonts()
{
    if (GGrimoireFonts.Num() > 0) return;

    const FString Dir = FPaths::ProjectDir() / TEXT("Content/Fonts/");

    struct FFontEntry { const TCHAR* Family; const TCHAR* Typeface; const TCHAR* File; };
    const FFontEntry Entries[] = {
        { TEXT("Cinzel"),    TEXT("Regular"), TEXT("Cinzel-Regular.ttf")            },
        { TEXT("Cinzel"),    TEXT("Bold"),    TEXT("Cinzel-Bold.ttf")               },
        { TEXT("Cormorant"), TEXT("Regular"), TEXT("CormorantGaramond-Regular.ttf") },
        { TEXT("Cormorant"), TEXT("Medium"),  TEXT("CormorantGaramond-Medium.ttf")  },
        { TEXT("Cormorant"), TEXT("Italic"),  TEXT("CormorantGaramond-Italic.ttf")  },
    };

    bool bAnyLoaded = false;
    for (const FFontEntry& E : Entries)
    {
        const FString Path = Dir + E.File;
        if (!FPaths::FileExists(Path))
        {
            UE_LOG(LogTemp, Warning,
                TEXT("GrimoireStyle: Font not found: %s"), *Path);
            continue;
        }

        // FCompositeFont(FontName, Filename, Hinting, LoadingPolicy)
        // builds DefaultTypeface with a single FTypefaceEntry for us.
        TSharedRef<FStandaloneCompositeFont> Composite =
            MakeShareable(new FStandaloneCompositeFont(
                FName(E.Typeface),
                Path,
                EFontHinting::Default,
                EFontLoadingPolicy::LazyLoad));

        const FName Key(*FString::Printf(TEXT("%s.%s"), E.Family, E.Typeface));
        GGrimoireFonts.Add(Key, FSlateFontInfo(Composite, 14.f, FName(E.Typeface)));
        UE_LOG(LogTemp, Log, TEXT("GrimoireStyle: Loaded %s"), *Key.ToString());
        bAnyLoaded = true;
    }

    if (!bAnyLoaded)
    {
        UE_LOG(LogTemp, Warning,
            TEXT("GrimoireStyle: No fonts loaded — drop TTFs into Content/Fonts/ for Cinzel + Cormorant Garamond."));
    }
}

static void UnregisterGrimoireFonts()
{
    GGrimoireFonts.Empty();
}

// Font lookup — called by GrimoireStyle::GetFont (declared GRIMOIREAPP_API in GrimoireStyle.h)
const FSlateFontInfo* GrimoireFontLookup(FName Key)
{
    return GGrimoireFonts.Find(Key);
}

namespace GrimoireStyle
{
    FSlateFontInfo GetFont(FName FontFamily, float Size, FName TypefaceEntry)
    {
        const FName Key(*FString::Printf(TEXT("%s.%s"),
            *FontFamily.ToString(), *TypefaceEntry.ToString()));
        if (const FSlateFontInfo* Found = GGrimoireFonts.Find(Key))
        {
            FSlateFontInfo Scaled = *Found;
            Scaled.Size = Size;
            return Scaled;
        }
        return FCoreStyle::GetDefaultFontStyle(
            TypefaceEntry == FName("Bold") ? "Bold" : "Regular",
            Size);
    }
}

// ============================================================

UGrimoireGameInstance::UGrimoireGameInstance()
{
}

void UGrimoireGameInstance::Init()
{
    Super::Init();

    RegisterGrimoireFonts();

    UE_LOG(LogTemp, Log, TEXT("GrimoireGameInstance: Initializing services..."));

    LocalStore = MakeUnique<FGrimoireLocalStore>();
    if (!LocalStore->Open())
    {
        UE_LOG(LogTemp, Fatal,
            TEXT("GrimoireGameInstance: Failed to open local database."));
        return;
    }

    AuthService = MakeUnique<FGrimoireAuthService>();
    AuthService->SetConfig(COGNITO_USER_POOL_ID, COGNITO_CLIENT_ID);

    SyncService = MakeUnique<FGrimoireSyncService>(LocalStore.Get(), AuthService.Get());
    SyncService->SetAPIEndpoint(API_ENDPOINT);

    UE_LOG(LogTemp, Log, TEXT("GrimoireGameInstance: All services ready."));

    if (AuthService->IsLoggedIn())
    {
        // Set current user ID so LocalStore filters entries by owner
        LocalStore->SetCurrentUserID(AuthService->GetCognitoSub());
        LocalStore->MigrateOrphanedEntries(); // Fix any pre-filter entries
        UE_LOG(LogTemp, Log,
            TEXT("GrimoireGameInstance: Restoring session for sub: %s"),
            *AuthService->GetCognitoSub());
        SyncService->SyncPendingEntries(FOnSyncComplete::CreateLambda(
            [](bool bOk, FString Msg)
            {
                if (bOk)
                {
                    UE_LOG(LogTemp, Log,
                        TEXT("GrimoireGameInstance: Background sync complete."));
                }
                else
                {
                    UE_LOG(LogTemp, Warning,
                        TEXT("GrimoireGameInstance: Sync failed: %s"), *Msg);
                }
            }));
    }

    // Check for app updates in background — fires after UI mounts
    FTimerHandle UpdateTimer;
    GetTimerManager().SetTimer(
        UpdateTimer,
        FTimerDelegate::CreateWeakLambda(this, [this]()
        {
            TSharedPtr<FGrimoireUpdateChecker> Checker =
                MakeShareable(new FGrimoireUpdateChecker());
            Checker->CheckForUpdate(
                API_ENDPOINT,
                TEXT("0.1.0"),
                TEXT("windows"),
                FOnUpdateCheckComplete::CreateWeakLambda(this,
                    [this, Checker](bool bAvail, FString Latest, FString DlUrl)
                    {
                        if (bAvail)
                        {
                            UE_LOG(LogTemp, Log,
                                TEXT("GrimoireGameInstance: Update available: %s → %s"),
                                TEXT("0.1.0"), *Latest);
                            PendingUpdateVersion = Latest;
                            PendingUpdateURL     = DlUrl;
                            bUpdateAvailable     = true;
                        }
                    }));
        }),
        3.0f,   // Wait 3s for UI to fully mount before showing any banner
        false);

    FTimerHandle MountTimer;
    GetTimerManager().SetTimer(
        MountTimer,
        FTimerDelegate::CreateWeakLambda(this, [this]()
        {
            if (GEngine && GEngine->GameViewport)
            {
                GEngine->GameViewport->AddViewportWidgetContent(
                    SNew(SGrimoireScreenManager).GameInstance(this), 10);
                UE_LOG(LogTemp, Log,
                    TEXT("GrimoireGameInstance: UI mounted."));
            }
        }),
        0.1f,
        false);
}

void UGrimoireGameInstance::Shutdown()
{
    UE_LOG(LogTemp, Log, TEXT("GrimoireGameInstance: Shutting down..."));

    if (SyncService && AuthService && AuthService->IsLoggedIn())
    {
        SyncService->SyncPendingEntries(FOnSyncComplete::CreateLambda(
            [](bool bOk, FString Msg)
            {
                UE_LOG(LogTemp, Log,
                    TEXT("GrimoireGameInstance: Shutdown sync done."));
            }));
    }

    if (LocalStore)
    {
        LocalStore->Close();
    }

    UnregisterGrimoireFonts();
    Super::Shutdown();
}
