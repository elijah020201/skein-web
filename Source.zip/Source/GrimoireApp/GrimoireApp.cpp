// Copyright Epic Games, Inc. All Rights Reserved.

#include "GrimoireApp.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, GrimoireApp, "GrimoireApp" );
