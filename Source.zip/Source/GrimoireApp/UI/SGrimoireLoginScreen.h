#pragma once

#include "CoreMinimal.h"
#include "SGrimoireBaseWidget.h"

// ============================================================
//  GRIMOIRE APP — Login Screen
//  SGrimoireLoginScreen.h
//
//  Screens:
//    0 — Login   (Enter)
//    1 — Register (Initiate)
//    2 — Verify  (Confirm email code — shown after registration)
// ============================================================

class GRIMOIREAPP_API SGrimoireLoginScreen : public SGrimoireBaseWidget
{
public:
    SLATE_BEGIN_ARGS(SGrimoireLoginScreen) {}
        SLATE_ARGUMENT(UGrimoireGameInstance*, GameInstance)
        SLATE_EVENT(FOnNavigate, OnNavigate)
    SLATE_END_ARGS()

    void Construct(const FArguments& InArgs);
    void OnScreenActivated();
    void RequestReset(); // Call before navigating to login after sign-out

private:

    enum class ELoginTab { Enter, Initiate };
    ELoginTab ActiveTab = ELoginTab::Enter;

    bool bShowingVerification = false;
    FString PendingEmail;

    TSharedPtr<SEditableText>   LoginEmailInput;
    TSharedPtr<SEditableText>   LoginPasswordInput;
    TSharedPtr<SEditableText>   RegisterEmailInput;
    TSharedPtr<SEditableText>   RegisterPasswordInput;
    TSharedPtr<SEditableText>   ConfirmPasswordInput;
    TSharedPtr<SEditableText>   VerifyCodeInput;
    TSharedPtr<STextBlock>      StatusText;
    TSharedPtr<SWidgetSwitcher> TabSwitcher;

    bool bIsLoading = false;
    bool bNeedsReset = false; // set true on explicit sign-out

    TSharedRef<SWidget> BuildHeader();
    TSharedRef<SWidget> BuildTabBar();
    TSharedRef<SWidget> BuildLoginForm();
    TSharedRef<SWidget> BuildRegisterForm();
    TSharedRef<SWidget> BuildVerifyForm();
    TSharedRef<SWidget> BuildLoreFooter();
    TSharedRef<SWidget> MakeInputField(TSharedPtr<SEditableText>& OutInput,
        const FText& Label, const FText& Placeholder, bool bPassword);

    void OnLoginPressed();
    void OnRegisterPressed();
    void OnVerifyPressed();
    void OnTabChanged(ELoginTab NewTab);
    void ShowVerification(const FString& Email);
    void SetStatus(const FString& Message, bool bIsError);
    void SetLoading(bool bLoading);

    void HandleLoginResult(const FAuthResult& Result);
    void HandleRegisterResult(const FAuthResult& Result);
    void HandleVerifyResult(const FAuthResult& Result);
};
