#include "SGrimoireDashboardScreen.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/Input/SButton.h"
#include "Misc/DateTime.h"

// ============================================================
//  GRIMOIRE APP — Dashboard Screen
//  Design: Obsidian Glass
//
//  Layout:
//    TopBar: GRIMOIRE wordmark | sync pill | settings
//    ─────────────────────────────────────── 1px border
//    [SCROLL]
//      Moon banner — full-width card
//      NEW ENTRY section header + quick-add chips
//      COLLECTIONS section header + horizontal scroll
//      RECENT section header + entry list
//    ─────────────────────────────────────── 1px border
//    Bottom nav: Tome | Entries | Collect | Profile
//    FAB overlaid bottom-right
// ============================================================

void SGrimoireDashboardScreen::Construct(const FArguments& InArgs)
{
    SGrimoireBaseWidget::Construct(
        SGrimoireBaseWidget::FArguments()
        .GameInstance(InArgs._GameInstance)
        .OnNavigate(InArgs._OnNavigate));

    ChildSlot
    [
        SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::BG)
        [
            SNew(SVerticalBox)

            // ── Top bar ──
            + SVerticalBox::Slot()
            .AutoHeight()
            [ BuildTopBar() ]

            // ── 1px border under topbar ──
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                SNew(SBox).HeightOverride(1.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::Border)
                ]
            ]

            // ── Update available banner (hidden by default) ──
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                SAssignNew(UpdateBannerContainer, SBox)
                .Visibility(EVisibility::Collapsed)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(FLinearColor(0.1f, 0.08f, 0.0f, 1.f))
                    .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadSM))
                    [
                        SNew(SHorizontalBox)
                        + SHorizontalBox::Slot()
                        .FillWidth(1.f)
                        .VAlign(VAlign_Center)
                        [
                            SAssignNew(UpdateBannerText, STextBlock)
                            .Font(GrimoireStyle::FontUI(9.f))
                            .ColorAndOpacity(GrimoireStyle::SC_Gold)
                        ]
                        + SHorizontalBox::Slot()
                        .AutoWidth()
                        .VAlign(VAlign_Center)
                        [
                            SNew(SButton)
                            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                            .OnClicked_Lambda([this]()
                            {
                                // Open download URL in browser
                                if (GameInstance != nullptr)
                                {
                                    FPlatformProcess::LaunchURL(
                                        *GameInstance->GetUpdateURL(), nullptr, nullptr);
                                    GameInstance->ClearUpdateBanner();
                                    if (UpdateBannerContainer.IsValid())
                                        UpdateBannerContainer->SetVisibility(EVisibility::Collapsed);
                                }
                                return FReply::Handled();
                            })
                            [
                                SNew(SBox)
                                .Padding(FMargin(GrimoireStyle::PadSM, 4.f))
                                [
                                    SNew(STextBlock)
                                    .Text(FText::FromString(TEXT("UPDATE NOW")))
                                    .Font(GrimoireStyle::FontUI(9.f))
                                    .ColorAndOpacity(GrimoireStyle::SC_Gold)
                                ]
                            ]
                        ]
                        + SHorizontalBox::Slot()
                        .AutoWidth()
                        .VAlign(VAlign_Center)
                        [
                            SNew(SButton)
                            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                            .OnClicked_Lambda([this]()
                            {
                                if (GameInstance != nullptr)
                                    GameInstance->ClearUpdateBanner();
                                if (UpdateBannerContainer.IsValid())
                                    UpdateBannerContainer->SetVisibility(EVisibility::Collapsed);
                                return FReply::Handled();
                            })
                            [
                                SNew(SBox)
                                .Padding(FMargin(GrimoireStyle::PadSM, 4.f))
                                [
                                    SNew(STextBlock)
                                    .Text(FText::FromString(TEXT("x")))
                                    .Font(GrimoireStyle::FontUI(9.f))
                                    .ColorAndOpacity(GrimoireStyle::TextMuted)
                                ]
                            ]
                        ]
                    ]
                ]
            ]

            // ── Scrollable content + FAB overlay ──
            + SVerticalBox::Slot()
            .FillHeight(1.f)
            [
                SNew(SOverlay)

                + SOverlay::Slot()
                [
                    SNew(SScrollBox)

                    + SScrollBox::Slot()
                    .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadMD, GrimoireStyle::PadMD, 0.f)
                    [ BuildMoonBanner() ]

                    + SScrollBox::Slot()
                    .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadLG, GrimoireStyle::PadMD, 0.f)
                    [ BuildQuickAddSection() ]

                    + SScrollBox::Slot()
                    .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadLG, GrimoireStyle::PadMD, 0.f)
                    [ BuildCollectionsSection() ]

                    + SScrollBox::Slot()
                    .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadLG, GrimoireStyle::PadMD, GrimoireStyle::PadXXL)
                    [ BuildRecentEntriesSection() ]
                ]

                // FAB
                + SOverlay::Slot()
                .HAlign(HAlign_Right)
                .VAlign(VAlign_Bottom)
                .Padding(GrimoireStyle::PadLG)
                [ BuildFAB() ]
            ]

            // ── 1px border above bottom nav ──
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                SNew(SBox).HeightOverride(1.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::Border)
                ]
            ]

            // ── Bottom nav ──
            + SVerticalBox::Slot()
            .AutoHeight()
            [ BuildBottomNav() ]
        ]
    ];

    // Load data after widget tree is fully built
    LoadRecentEntries();
    LoadCollections();
}

// --------------------------------------------------------
//  Top bar
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildTopBar()
{
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(FMargin(GrimoireStyle::PadMD, 0.f))
        [
            SNew(SBox)
            .HeightOverride(GrimoireStyle::TopBarHeight)
            [
                SNew(SHorizontalBox)

                // Sigil mark
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
                [
                    SNew(SBox)
                    .WidthOverride(26.f)
                    .HeightOverride(26.f)
                    [
                        SNew(SBorder)
                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                        .BorderBackgroundColor(GrimoireStyle::RedDim)
                        .HAlign(HAlign_Center)
                        .VAlign(VAlign_Center)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(TEXT("*")))
                            .Font(GrimoireStyle::FontDisplay(12.f))
                            .ColorAndOpacity(GrimoireStyle::SC_Gold)
                        ]
                    ]
                ]

                // Wordmark
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("GRIMOIRE")))
                    .Font(GrimoireStyle::FontDisplay(16.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                ]

                + SHorizontalBox::Slot().FillWidth(1.f)

                // Sync status pill
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::Border)
                    .Padding(FMargin(GrimoireStyle::PadSM + 2.f, 4.f))
                    [
                        SAssignNew(SyncStatusText, STextBlock)
                        .Text(FText::FromString(TEXT("SYNCED")))
                        .Font(GrimoireStyle::FontUI(8.f))
                        .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
                    ]
                ]

                // Settings / Sign Out
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(GrimoireStyle::PadSM, 0.f, GrimoireStyle::PadMD, 0.f)
                [
                    SNew(SHorizontalBox)

                    + SHorizontalBox::Slot()
                    .AutoWidth()
                    .VAlign(VAlign_Center)
                    .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
                    [
                        SNew(SButton)
                        .ButtonStyle(FCoreStyle::Get(), "NoBorder")
                        .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                        .OnClicked_Lambda([this]()
                        {
                            NavigateTo(FName("SignOut"));
                            return FReply::Handled();
                        })
                        .VAlign(VAlign_Center)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(TEXT("out")))
                            .Font(GrimoireStyle::FontUI(8.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                        ]
                    ]

                    + SHorizontalBox::Slot()
                    .AutoWidth()
                    .VAlign(VAlign_Center)
                    [
                        SNew(SButton)
                        .ButtonStyle(FCoreStyle::Get(), "NoBorder")
                        .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                        .OnClicked_Lambda([this]()
                        {
                            NavigateTo(FName("Settings"));
                            return FReply::Handled();
                        })
                        .VAlign(VAlign_Center)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(TEXT("= =")))
                            .Font(GrimoireStyle::FontUI(11.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                        ]
                    ]
                ]
            ]
        ];
}

// --------------------------------------------------------
//  Moon phase banner
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildMoonBanner()
{
    FMoonPhaseInfo Moon = CalculateMoonPhase();

    // Left accent stripe (colored by energy level)
    const FLinearColor EnergyColor = FLinearColor::LerpUsingHSV(
        GrimoireStyle::GoldDim, GrimoireStyle::Gold, Moon.EnergyLevel);

    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Border)
        .Padding(GrimoireStyle::BorderPx)
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::Surface)
            .Padding(0.f)
            [
                SNew(SHorizontalBox)

                // Left gold accent stripe
                + SHorizontalBox::Slot()
                .AutoWidth()
                [
                    SNew(SBox)
                    .WidthOverride(3.f)
                    [
                        SNew(SBorder)
                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                        .BorderBackgroundColor(EnergyColor)
                    ]
                ]

                // Main content
                + SHorizontalBox::Slot()
                .FillWidth(1.f)
                .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadMD)
                [
                    SNew(SHorizontalBox)

                    // Moon glyph — large
                    + SHorizontalBox::Slot()
                    .AutoWidth()
                    .VAlign(VAlign_Center)
                    .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
                    [
                        SNew(STextBlock)
                        .Text(Moon.PhaseGlyph)
                        .Font(GrimoireStyle::FontBody(44.f))
                        .ColorAndOpacity(GrimoireStyle::SC_Gold)
                    ]

                    // Phase name + date + description
                    + SHorizontalBox::Slot()
                    .FillWidth(1.f)
                    .VAlign(VAlign_Center)
                    [
                        SNew(SVerticalBox)

                        + SVerticalBox::Slot().AutoHeight()
                        .Padding(0.f, 0.f, 0.f, 3.f)
                        [
                            SNew(STextBlock)
                            .Text(Moon.PhaseName)
                            .Font(GrimoireStyle::FontDisplay(13.f))
                            .ColorAndOpacity(GrimoireStyle::SC_Gold)
                        ]

                        + SVerticalBox::Slot().AutoHeight()
                        .Padding(0.f, 0.f, 0.f, 5.f)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString([]()
                            {
                                static const FString Days[]   = {TEXT("Monday"),TEXT("Tuesday"),TEXT("Wednesday"),TEXT("Thursday"),TEXT("Friday"),TEXT("Saturday"),TEXT("Sunday")};
                                static const FString Months[] = {TEXT("January"),TEXT("February"),TEXT("March"),TEXT("April"),TEXT("May"),TEXT("June"),TEXT("July"),TEXT("August"),TEXT("September"),TEXT("October"),TEXT("November"),TEXT("December")};
                                FDateTime N = FDateTime::Now();
                                int32 DayIdx = (int32)N.GetDayOfWeek();
                                int32 MonIdx = N.GetMonth() - 1;
                                return FString::Printf(TEXT("%s, %d %s %d"), *Days[DayIdx], N.GetDay(), *Months[MonIdx], N.GetYear());
                            }()))
                            .Font(GrimoireStyle::FontBodyItalic(14.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
                        ]

                        + SVerticalBox::Slot().AutoHeight()
                        [
                            SNew(STextBlock)
                            .Text(Moon.Description)
                            .Font(GrimoireStyle::FontBodyItalic(13.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                            .AutoWrapText(true)
                        ]
                    ]

                    // Energy meter (right side)
                    + SHorizontalBox::Slot()
                    .AutoWidth()
                    .VAlign(VAlign_Center)
                    .Padding(GrimoireStyle::PadMD, 0.f, 0.f, 0.f)
                    [
                        SNew(SVerticalBox)

                        + SVerticalBox::Slot().AutoHeight()
                        .HAlign(HAlign_Center)
                        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadXS)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(TEXT("ENERGY")))
                            .Font(GrimoireStyle::FontUI(7.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                        ]

                        // Vertical progress bar — 4px wide, 48px tall
                        + SVerticalBox::Slot().AutoHeight()
                        .HAlign(HAlign_Center)
                        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadXS)
                        [
                            SNew(SBox)
                            .WidthOverride(4.f)
                            .HeightOverride(48.f)
                            [
                                SNew(SOverlay)
                                + SOverlay::Slot()
                                [
                                    SNew(SBorder)
                                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                                    .BorderBackgroundColor(GrimoireStyle::Surface2)
                                ]
                                // Fill from bottom
                                + SOverlay::Slot()
                                .VAlign(VAlign_Bottom)
                                [
                                    SNew(SBox)
                                    .HeightOverride(48.f * Moon.EnergyLevel)
                                    [
                                        SNew(SBorder)
                                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                                        .BorderBackgroundColor(EnergyColor)
                                    ]
                                ]
                            ]
                        ]

                        + SVerticalBox::Slot().AutoHeight()
                        .HAlign(HAlign_Center)
                        [
                            SNew(STextBlock)
                            .Text(Moon.EnergyLabel)
                            .Font(GrimoireStyle::FontBodyItalic(11.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                        ]
                    ]
                ]
            ]
        ];
}

// --------------------------------------------------------
//  Quick-add section
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildQuickAddSection()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ BuildSectionHeader(FText::FromString(TEXT("NEW ENTRY"))) ]

        + SVerticalBox::Slot().AutoHeight()
        [ BuildQuickAddStrip() ];
}

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildQuickAddStrip()
{
    TSharedRef<SHorizontalBox> Strip = SNew(SHorizontalBox);

    struct FChip { FText Letter; FText Label; EGrimoireEntryType Type; };
    const TArray<FChip> Chips = {
        { FText::FromString(TEXT("S")),  FText::FromString(TEXT("SPELL")),   EGrimoireEntryType::Spell },
        { FText::FromString(TEXT("R")),  FText::FromString(TEXT("RITUAL")),  EGrimoireEntryType::Ritual },
        { FText::FromString(TEXT("J")),  FText::FromString(TEXT("JOURNAL")), EGrimoireEntryType::JournalEntry },
        { FText::FromString(TEXT("H")),  FText::FromString(TEXT("HERBAL")),  EGrimoireEntryType::HerbalCorrespondence },
        { FText::FromString(TEXT("Si")),  FText::FromString(TEXT("SIGIL")),   EGrimoireEntryType::Sigil },
        { FText::FromString(TEXT("T")),  FText::FromString(TEXT("TAROT")),   EGrimoireEntryType::TarotLog },
        { FText::FromString(TEXT("A")),  FText::FromString(TEXT("ASTRO")),   EGrimoireEntryType::AstrologicalData },
    };

    for (const FChip& Chip : Chips)
    {
        const FLinearColor TypeCol = GrimoireStyle::GetTypeColor(Chip.Type);

        Strip->AddSlot()
        .AutoWidth()
        .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::Border)
            .Padding(GrimoireStyle::BorderPx)
            [
                SNew(SButton)
                .ButtonColorAndOpacity(GrimoireStyle::Surface)
                .OnClicked_Lambda([this, Type = Chip.Type]()
                {
                    NavigateTo(FName(*FString::Printf(TEXT("Editor:new:%d"), (int32)Type)));
                    return FReply::Handled();
                })
                [
                    SNew(SBox)
                    .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadSM + 2.f))
                    [
                        SNew(SVerticalBox)

                        // Type letter in type color
                        + SVerticalBox::Slot().AutoHeight()
                        .HAlign(HAlign_Center)
                        .Padding(0.f, 0.f, 0.f, 3.f)
                        [
                            SNew(STextBlock)
                            .Text(Chip.Letter)
                            .Font(GrimoireStyle::FontDisplay(14.f))
                            .ColorAndOpacity(GrimoireStyle::SC(TypeCol))
                        ]

                        // Label
                        + SVerticalBox::Slot().AutoHeight()
                        .HAlign(HAlign_Center)
                        [
                            SNew(STextBlock)
                            .Text(Chip.Label)
                            .Font(GrimoireStyle::FontUI(8.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                        ]
                    ]
                ]
            ]
        ];
    }

    return SNew(SScrollBox)
        .Orientation(Orient_Horizontal)
        + SScrollBox::Slot()
        [ Strip ];
}

// --------------------------------------------------------
//  Collections section
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildCollectionsSection()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [
            BuildSectionHeader(
                FText::FromString(TEXT("COLLECTIONS")),
                FText::FromString(TEXT("view all")),
                FSimpleDelegate::CreateLambda([this](){ NavigateTo(FName("Collection")); }))
        ]

        + SVerticalBox::Slot().AutoHeight()
        [
            SNew(SScrollBox)
            .Orientation(Orient_Horizontal)
            + SScrollBox::Slot()
            [ SAssignNew(CollectionList, SHorizontalBox) ]
        ];
}

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildCollectionCard(
    const FGrimoireCollection& Collection)
{
    return SNew(SBox)
        .WidthOverride(GrimoireStyle::CollectionCardW)
        .Padding(FMargin(0.f, 0.f, GrimoireStyle::PadSM, 0.f))
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::Border)
            .Padding(GrimoireStyle::BorderPx)
            [
                SNew(SButton)
                .ButtonColorAndOpacity(GrimoireStyle::Surface)
                .OnClicked_Lambda([this](){ NavigateTo(FName("Collection")); return FReply::Handled(); })
                [
                    SNew(SBox)
                    .HeightOverride(GrimoireStyle::CollectionCardH)
                    .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadSM + 4.f))
                    [
                        SNew(SVerticalBox)

                        // Gold book glyph
                        + SVerticalBox::Slot().AutoHeight()
                        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(TEXT("C")))
                            .Font(GrimoireStyle::FontDisplay(20.f))
                            .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
                        ]

                        + SVerticalBox::Slot().AutoHeight()
                        .Padding(0.f, 0.f, 0.f, 3.f)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(Collection.Name))
                            .Font(GrimoireStyle::FontBodyMedium(13.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                            .AutoWrapText(true)
                        ]

                        + SVerticalBox::Slot().AutoHeight()
                        [
                            SNew(STextBlock)
                            .Text(FText::Format(
                                FText::FromString(TEXT("{0} entries")),
                                FText::AsNumber(Collection.EntryIDs.Num())))
                            .Font(GrimoireStyle::FontBodyItalic(12.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                        ]
                    ]
                ]
            ]
        ];
}

// --------------------------------------------------------
//  Recent entries section
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildRecentEntriesSection()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [
            BuildSectionHeader(
                FText::FromString(TEXT("RECENT")),
                FText::FromString(TEXT("view all")),
                FSimpleDelegate::CreateLambda([this](){ NavigateTo(FName("Entries")); }))
        ]

        + SVerticalBox::Slot().AutoHeight()
        [ SAssignNew(EntryList, SVerticalBox) ];
}

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildEntryCard(const FGrimoireEntry& Entry)
{
    const FLinearColor TypeColor = GrimoireStyle::GetTypeColor(Entry.EntryType);

    return SNew(SBox)
        .Padding(FMargin(0.f, 0.f, 0.f, 1.f)) // 1px gap between cards (acts as separator)
        [
            SNew(SButton)
            .ButtonColorAndOpacity(GrimoireStyle::Surface)
            .OnClicked_Lambda([this, Entry]()
            {
                NavigateTo(FName(*FString::Printf(TEXT("Editor:%s"), *Entry.EntityID)));
                return FReply::Handled();
            })
            [
                SNew(SHorizontalBox)

                // Type accent stripe — 3px, full height
                + SHorizontalBox::Slot()
                .AutoWidth()
                [
                    SNew(SBox)
                    .WidthOverride(GrimoireStyle::AccentBarW)
                    [
                        SNew(SBorder)
                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                        .BorderBackgroundColor(TypeColor)
                    ]
                ]

                // Card body
                + SHorizontalBox::Slot()
                .FillWidth(1.f)
                .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadSM + 4.f,
                                 GrimoireStyle::PadMD, GrimoireStyle::PadSM + 4.f))
                [
                    SNew(SVerticalBox)

                    // Top row: type badge + date
                    + SVerticalBox::Slot().AutoHeight()
                    .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadXS)
                    [
                        SNew(SHorizontalBox)
                        + SHorizontalBox::Slot().AutoWidth()
                        .VAlign(VAlign_Center)
                        [ BuildTypeBadge(Entry.EntryType) ]
                        + SHorizontalBox::Slot().FillWidth(1.f)
                        + SHorizontalBox::Slot().AutoWidth()
                        .VAlign(VAlign_Center)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(Entry.UpdatedAt.Left(10)))
                            .Font(GrimoireStyle::FontBodyItalic(12.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                        ]
                    ]

                    // Title
                    + SVerticalBox::Slot().AutoHeight()
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(Entry.Title))
                        .Font(GrimoireStyle::FontBodyMedium(15.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                        .AutoWrapText(true)
                    ]
                ]

                // Right arrow hint
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT(">")))
                    .Font(GrimoireStyle::FontUI(9.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                ]
            ]
        ];
}

// --------------------------------------------------------
//  FAB — floating action button
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildFAB()
{
    // Crimson circle with gold asterisk
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::GoldFaint)
        .Padding(1.f)
        [
            SNew(SBox)
            .WidthOverride(GrimoireStyle::FABSize)
            .HeightOverride(GrimoireStyle::FABSize)
            [
                SNew(SButton)
                .ButtonColorAndOpacity(GrimoireStyle::Red)
                .OnClicked_Lambda([this]()
                {
                    NavigateTo(FName("Editor:new"));
                    return FReply::Handled();
                })
                .HAlign(HAlign_Center)
                .VAlign(VAlign_Center)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("+")))
                    .Font(GrimoireStyle::FontDisplay(22.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                ]
            ]
        ];
}

// --------------------------------------------------------
//  Bottom nav
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildBottomNav()
{
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(0.f)
        [
            SNew(SBox)
            .HeightOverride(GrimoireStyle::BottomNavHeight)
            [
                SNew(SHorizontalBox)
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("T")), FText::FromString(TEXT("TOME")),    FName("Dashboard"), true) ]
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("E")), FText::FromString(TEXT("ENTRIES")), FName("Entries")) ]
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("C")), FText::FromString(TEXT("COLLECT")), FName("Collection")) ]
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("P")), FText::FromString(TEXT("PROFILE")), FName("Settings")) ]
            ]
        ];
}

TSharedRef<SWidget> SGrimoireDashboardScreen::BuildNavItem(
    const FText& Glyph, const FText& Label, FName TargetScreen, bool bIsActive)
{
    const FSlateColor GlyphColor = bIsActive ? GrimoireStyle::SC_Gold    : GrimoireStyle::SC_TextFaint;
    const FSlateColor LabelColor = bIsActive ? GrimoireStyle::SC_GoldDim : GrimoireStyle::SC_TextFaint;

    return SNew(SButton)
        .ButtonStyle(FCoreStyle::Get(), "NoBorder")
        .ButtonColorAndOpacity(GrimoireStyle::Transparent)
        .OnClicked_Lambda([this, TargetScreen]()
        {
            if (TargetScreen != FName("Dashboard")) NavigateTo(TargetScreen);
            return FReply::Handled();
        })
        .HAlign(HAlign_Center)
        .VAlign(VAlign_Center)
        [
            SNew(SVerticalBox)

            // Active indicator dot
            + SVerticalBox::Slot().AutoHeight()
            .HAlign(HAlign_Center)
            .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadXS)
            [
                SNew(SBox)
                .WidthOverride(4.f)
                .HeightOverride(4.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(bIsActive ? GrimoireStyle::Gold : GrimoireStyle::Transparent)
                ]
            ]

            // Glyph letter (Cinzel display)
            + SVerticalBox::Slot().AutoHeight()
            .HAlign(HAlign_Center)
            [
                SNew(STextBlock)
                .Text(Glyph)
                .Font(GrimoireStyle::FontDisplay(14.f))
                .ColorAndOpacity(GlyphColor)
            ]

            // Label
            + SVerticalBox::Slot().AutoHeight()
            .HAlign(HAlign_Center)
            .Padding(0.f, 3.f, 0.f, 0.f)
            [
                SNew(STextBlock)
                .Text(Label)
                .Font(GrimoireStyle::FontUI(7.f))
                .ColorAndOpacity(LabelColor)
            ]
        ];
}

// --------------------------------------------------------
//  Data loading
// --------------------------------------------------------

void SGrimoireDashboardScreen::LoadRecentEntries()
{
    if (!Store()) return;
    RecentEntries.Empty();
    Store()->LoadAllEntries(RecentEntries);
    RecentEntries.Sort([](const FGrimoireEntry& A, const FGrimoireEntry& B)
    { return A.UpdatedAt > B.UpdatedAt; });
    if (RecentEntries.Num() > 10) RecentEntries.SetNum(10);
    RefreshEntryList();
}

void SGrimoireDashboardScreen::LoadCollections()
{
    if (!Store()) return;
    Collections.Empty();
    Store()->LoadAllCollections(Collections);
    RefreshCollectionList();
}

void SGrimoireDashboardScreen::RefreshEntryList()
{
    if (!EntryList.IsValid()) return;
    EntryList->ClearChildren();

    if (RecentEntries.Num() == 0)
    {
        EntryList->AddSlot().AutoHeight()
        [
            SNew(SBox)
            .Padding(FMargin(0.f, GrimoireStyle::PadXL))
            [
                SNew(SVerticalBox)
                + SVerticalBox::Slot().AutoHeight()
                .HAlign(HAlign_Center)
                .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("*")))
                    .Font(GrimoireStyle::FontDisplay(18.f))
                    .ColorAndOpacity(GrimoireStyle::SC_GoldFaint)
                ]
                + SVerticalBox::Slot().AutoHeight()
                .HAlign(HAlign_Center)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("Your tome awaits its first inscription.")))
                    .Font(GrimoireStyle::FontBodyItalic(15.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                    .Justification(ETextJustify::Center)
                    .AutoWrapText(true)
                ]
            ]
        ];
        return;
    }

    for (const FGrimoireEntry& Entry : RecentEntries)
        EntryList->AddSlot().AutoHeight() [ BuildEntryCard(Entry) ];
}

void SGrimoireDashboardScreen::RefreshCollectionList()
{
    if (!CollectionList.IsValid()) return;
    CollectionList->ClearChildren();

    if (Collections.Num() == 0)
    {
        CollectionList->AddSlot().AutoWidth()
        [
            SNew(SBox)
            .WidthOverride(GrimoireStyle::CollectionCardW)
            .Padding(FMargin(0.f, 0.f, GrimoireStyle::PadSM, 0.f))
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::Border)
                .Padding(GrimoireStyle::BorderPx)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::Surface)
                    .Padding(GrimoireStyle::PadMD)
                    [
                        SNew(SBox)
                        .HeightOverride(GrimoireStyle::CollectionCardH - GrimoireStyle::PadMD * 2.f)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(TEXT("No collections yet")))
                            .Font(GrimoireStyle::FontBodyItalic(13.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                            .AutoWrapText(true)
                        ]
                    ]
                ]
            ]
        ];
        return;
    }

    for (const FGrimoireCollection& Col : Collections)
        CollectionList->AddSlot().AutoWidth() [ BuildCollectionCard(Col) ];
}

void SGrimoireDashboardScreen::OnScreenActivated()
{
    LoadRecentEntries();
    LoadCollections();

    // Show update banner if one is pending
    if (GameInstance != nullptr && GameInstance->IsUpdateAvailable())
    {
        const FString Latest = GameInstance->GetUpdateVersion();
        if (UpdateBannerText.IsValid())
            UpdateBannerText->SetText(FText::FromString(
                FString::Printf(TEXT("Version %s available"), *Latest)));
        if (UpdateBannerContainer.IsValid())
            UpdateBannerContainer->SetVisibility(EVisibility::Visible);
    }
}

// --------------------------------------------------------
//  Lunar calculation
// --------------------------------------------------------

SGrimoireDashboardScreen::FMoonPhaseInfo
SGrimoireDashboardScreen::CalculateMoonPhase()
{
    const FDateTime Epoch(2000, 1, 6, 18, 14, 0);
    const FDateTime Now = FDateTime::UtcNow();
    const double SynodicPeriod = 29.53058867;
    const double DaysSince = (Now - Epoch).GetTotalSeconds() / 86400.0;
    double Phase = FMath::Fmod(DaysSince, SynodicPeriod);
    if (Phase < 0) Phase += SynodicPeriod;
    const float N = (float)(Phase / SynodicPeriod);

    FMoonPhaseInfo I;
    if      (N < 0.025f)  { I.PhaseName=FText::FromString(TEXT("NEW MOON"));       I.PhaseGlyph=FText::FromString(TEXT("-O-")); I.Description=FText::FromString(TEXT("Set intentions. Begin new workings."));         I.EnergyLevel=0.05f; I.EnergyLabel=FText::FromString(TEXT("Still")); }
    else if (N < 0.250f)  { I.PhaseName=FText::FromString(TEXT("WAXING CRESCENT")); I.PhaseGlyph=FText::FromString(TEXT(")O")); I.Description=FText::FromString(TEXT("Favourable for growth and attraction."));       I.EnergyLevel=0.35f; I.EnergyLabel=FText::FromString(TEXT("Rising")); }
    else if (N < 0.275f)  { I.PhaseName=FText::FromString(TEXT("FIRST QUARTER"));  I.PhaseGlyph=FText::FromString(TEXT("D")); I.Description=FText::FromString(TEXT("Take decisive action. Break obstacles."));       I.EnergyLevel=0.55f; I.EnergyLabel=FText::FromString(TEXT("Building")); }
    else if (N < 0.475f)  { I.PhaseName=FText::FromString(TEXT("WAXING GIBBOUS")); I.PhaseGlyph=FText::FromString(TEXT("oD")); I.Description=FText::FromString(TEXT("Refine and strengthen your workings."));         I.EnergyLevel=0.75f; I.EnergyLabel=FText::FromString(TEXT("Strong")); }
    else if (N < 0.525f)  { I.PhaseName=FText::FromString(TEXT("FULL MOON"));      I.PhaseGlyph=FText::FromString(TEXT("-@-")); I.Description=FText::FromString(TEXT("Peak power. Charge your tools and sigils."));    I.EnergyLevel=1.00f; I.EnergyLabel=FText::FromString(TEXT("Peak")); }
    else if (N < 0.725f)  { I.PhaseName=FText::FromString(TEXT("WANING GIBBOUS")); I.PhaseGlyph=FText::FromString(TEXT("Co")); I.Description=FText::FromString(TEXT("Release, banish, and let go."));                 I.EnergyLevel=0.70f; I.EnergyLabel=FText::FromString(TEXT("Fading")); }
    else if (N < 0.775f)  { I.PhaseName=FText::FromString(TEXT("LAST QUARTER"));   I.PhaseGlyph=FText::FromString(TEXT("C")); I.Description=FText::FromString(TEXT("Break hexes. Remove obstacles."));                I.EnergyLevel=0.45f; I.EnergyLabel=FText::FromString(TEXT("Waning")); }
    else if (N < 0.975f)  { I.PhaseName=FText::FromString(TEXT("WANING CRESCENT")); I.PhaseGlyph=FText::FromString(TEXT("Co")); I.Description=FText::FromString(TEXT("Rest, reflect, and prepare."));                 I.EnergyLevel=0.20f; I.EnergyLabel=FText::FromString(TEXT("Low")); }
    else                  { I.PhaseName=FText::FromString(TEXT("DARK MOON"));       I.PhaseGlyph=FText::FromString(TEXT("-O-")); I.Description=FText::FromString(TEXT("Shadow work. The veil is thin."));               I.EnergyLevel=0.02f; I.EnergyLabel=FText::FromString(TEXT("Still")); }

    return I;
}
