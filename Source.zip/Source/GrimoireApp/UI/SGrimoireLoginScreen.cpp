#include "SGrimoireLoginScreen.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "Widgets/Input/SEditableText.h"
#include "Widgets/Input/SButton.h"

// ============================================================
//  GRIMOIRE APP — Login Screen
//  Design: Obsidian Glass — centered card on deep dark bg
//
//  Layout (top to bottom):
//    88px sigil — 16px gap
//    GRIMOIRE wordmark (Cinzel Bold 32pt)
//    "your sacred digital tome" italic tagline
//    48px gap
//    Card:
//      ENTER | INITIATE tabs (Cinzel 11pt)
//      1px hairline separator
//      Form content (switcher: login / register / verify)
//      Status message
//    Lore quote footer
// ============================================================

void SGrimoireLoginScreen::Construct(const FArguments& InArgs)
{
    SGrimoireBaseWidget::Construct(
        SGrimoireBaseWidget::FArguments()
        .GameInstance(InArgs._GameInstance)
        .OnNavigate(InArgs._OnNavigate));

    ChildSlot
    [
        // Full-screen background
        SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::BG)
        [
            // Center column
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot().FillWidth(1.f)
            + SHorizontalBox::Slot()
            .AutoWidth()
            [
                SNew(SBox)
                .WidthOverride(GrimoireStyle::CardWidth)
                [
                    SNew(SScrollBox)
                    + SScrollBox::Slot()
                    .Padding(0.f, GrimoireStyle::PadXXL, 0.f, GrimoireStyle::PadXL)
                    [
                        SNew(SVerticalBox)

                        // ── Sigil + Wordmark ──
                        + SVerticalBox::Slot()
                        .AutoHeight()
                        .HAlign(HAlign_Center)
                        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadXL)
                        [ BuildHeader() ]

                        // ── Auth Card ──
                        + SVerticalBox::Slot()
                        .AutoHeight()
                        [
                            BuildCard(
                                SNew(SVerticalBox)

                                // Tabs
                                + SVerticalBox::Slot()
                                .AutoHeight()
                                [ BuildTabBar() ]

                                // Gold hairline below tabs
                                + SVerticalBox::Slot()
                                .AutoHeight()
                                .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadLG)
                                [
                                    SNew(SBox).HeightOverride(1.f)
                                    [
                                        SNew(SBorder)
                                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                                        .BorderBackgroundColor(GrimoireStyle::Border)
                                    ]
                                ]

                                // Form switcher
                                + SVerticalBox::Slot()
                                .AutoHeight()
                                [
                                    SAssignNew(TabSwitcher, SWidgetSwitcher)
                                    .WidgetIndex(0)
                                    + SWidgetSwitcher::Slot() [ BuildLoginForm() ]
                                    + SWidgetSwitcher::Slot() [ BuildRegisterForm() ]
                                    + SWidgetSwitcher::Slot() [ BuildVerifyForm() ]
                                ]

                                // Status message
                                + SVerticalBox::Slot()
                                .AutoHeight()
                                .Padding(0.f, GrimoireStyle::PadMD, 0.f, 0.f)
                                [
                                    SAssignNew(StatusText, STextBlock)
                                    .Text(FText::GetEmpty())
                                    .Font(GrimoireStyle::FontBodyItalic(14.f))
                                    .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
                                    .Justification(ETextJustify::Center)
                                    .WrapTextAt(340.f)
                                ],

                                GrimoireStyle::Surface,
                                GrimoireStyle::Border,
                                FMargin(GrimoireStyle::PadLG)
                            )
                        ]

                        // ── Lore footer ──
                        + SVerticalBox::Slot()
                        .AutoHeight()
                        .Padding(0.f, GrimoireStyle::PadXL, 0.f, 0.f)
                        [ BuildLoreFooter() ]
                    ]
                ]
            ]
            + SHorizontalBox::Slot().FillWidth(1.f)
        ]
    ];
}

// --------------------------------------------------------
//  Header — sigil + wordmark + tagline
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireLoginScreen::BuildHeader()
{
    return SNew(SVerticalBox)

        // Sigil — crimson circle with gold asterisk
        + SVerticalBox::Slot()
        .AutoHeight()
        .HAlign(HAlign_Center)
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [
            SNew(SBox)
            .WidthOverride(GrimoireStyle::SigilSize)
            .HeightOverride(GrimoireStyle::SigilSize)
            [
                SNew(SOverlay)
                // Outer gold ring (1px border)
                + SOverlay::Slot()
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::GoldFaint)
                    .Padding(1.f)
                    [
                        SNew(SBorder)
                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                        .BorderBackgroundColor(GrimoireStyle::RedDim)
                        .HAlign(HAlign_Center)
                        .VAlign(VAlign_Center)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(TEXT("*")))
                            .Font(GrimoireStyle::FontDisplay(38.f))
                            .ColorAndOpacity(GrimoireStyle::SC_Gold)
                        ]
                    ]
                ]
            ]
        ]

        // Wordmark
        + SVerticalBox::Slot()
        .AutoHeight()
        .HAlign(HAlign_Center)
        .Padding(0.f, 0.f, 0.f, 6.f)
        [
            SNew(STextBlock)
            .Text(FText::FromString(TEXT("GRIMOIRE")))
            .Font(GrimoireStyle::FontDisplay(32.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
        ]

        // Tagline
        + SVerticalBox::Slot()
        .AutoHeight()
        .HAlign(HAlign_Center)
        [
            SNew(STextBlock)
            .Text(FText::FromString(TEXT("your sacred digital tome")))
            .Font(GrimoireStyle::FontBodyItalic(16.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
        ];
}

// --------------------------------------------------------
//  Tab bar
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireLoginScreen::BuildTabBar()
{
    return SNew(SHorizontalBox)

        + SHorizontalBox::Slot()
        .FillWidth(1.f)
        [
            SNew(SButton)
            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
            .OnClicked_Lambda([this]()
            {
                if (!bShowingVerification) OnTabChanged(ELoginTab::Enter);
                return FReply::Handled();
            })
            .HAlign(HAlign_Center)
            .VAlign(VAlign_Center)
            [
                SNew(SBox)
                .Padding(FMargin(0.f, GrimoireStyle::PadSM, 0.f, GrimoireStyle::PadSM + 2.f))
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("ENTER")))
                    .Font(GrimoireStyle::FontUI(11.f))
                    .ColorAndOpacity_Lambda([this]()
                    {
                        return (!bShowingVerification && ActiveTab == ELoginTab::Enter)
                            ? GrimoireStyle::SC_Gold
                            : GrimoireStyle::SC_TextFaint;
                    })
                ]
            ]
        ]

        // Thin vertical separator
        + SHorizontalBox::Slot()
        .AutoWidth()
        .VAlign(VAlign_Center)
        [
            SNew(SBox).WidthOverride(1.f).HeightOverride(14.f)
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::Border)
            ]
        ]

        + SHorizontalBox::Slot()
        .FillWidth(1.f)
        [
            SNew(SButton)
            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
            .OnClicked_Lambda([this]()
            {
                if (!bShowingVerification) OnTabChanged(ELoginTab::Initiate);
                return FReply::Handled();
            })
            .HAlign(HAlign_Center)
            .VAlign(VAlign_Center)
            [
                SNew(SBox)
                .Padding(FMargin(0.f, GrimoireStyle::PadSM, 0.f, GrimoireStyle::PadSM + 2.f))
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("INITIATE")))
                    .Font(GrimoireStyle::FontUI(11.f))
                    .ColorAndOpacity_Lambda([this]()
                    {
                        return (!bShowingVerification && ActiveTab == ELoginTab::Initiate)
                            ? GrimoireStyle::SC_Gold
                            : GrimoireStyle::SC_TextFaint;
                    })
                ]
            ]
        ];
}

// --------------------------------------------------------
//  Shared input field
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireLoginScreen::MakeInputField(
    TSharedPtr<SEditableText>& OutInput,
    const FText& Label,
    const FText& Placeholder,
    bool bPassword)
{
    return SNew(SVerticalBox)

        // Label
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(2.f, 0.f, 0.f, 5.f)
        [
            SNew(STextBlock)
            .Text(Label)
            .Font(GrimoireStyle::FontUI(9.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
        ]

        // Input — dark fill, hairline border, 44px tall
        + SVerticalBox::Slot()
        .AutoHeight()
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::Border)
            .Padding(GrimoireStyle::BorderPx)
            [
                SNew(SBox)
                .HeightOverride(GrimoireStyle::InputHeight)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::Surface2)
                    .VAlign(VAlign_Center)
                    .Padding(FMargin(GrimoireStyle::PadMD, 0.f))
                    [
                        SAssignNew(OutInput, SEditableText)
                        .HintText(Placeholder)
                        .IsPassword(bPassword)
                        .Font(GrimoireStyle::FontBody(15.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                    ]
                ]
            ]
        ];
}

// --------------------------------------------------------
//  Login form
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireLoginScreen::BuildLoginForm()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeInputField(LoginEmailInput,
            FText::FromString(TEXT("EMAIL ADDRESS")),
            FText::FromString(TEXT("your@coven.com")), false) ]

        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadLG)
        [ MakeInputField(LoginPasswordInput,
            FText::FromString(TEXT("PASSPHRASE")),
            FText::FromString(TEXT("words of power")), true) ]

        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [
            BuildPrimaryButton(
                FText::FromString(TEXT("OPEN THE TOME")),
                FSimpleDelegate::CreateSP(this, &SGrimoireLoginScreen::OnLoginPressed))
        ]

        + SVerticalBox::Slot().AutoHeight()
        .HAlign(HAlign_Center)
        [
            SNew(SButton)
            .ButtonStyle(FCoreStyle::Get(), "NoBorder")
            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
            .OnClicked_Lambda([](){ return FReply::Handled(); })
            [
                SNew(STextBlock)
                .Text(FText::FromString(TEXT("Forgotten your words of power?")))
                .Font(GrimoireStyle::FontBodyItalic(14.f))
                .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
            ]
        ];
}

// --------------------------------------------------------
//  Register form
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireLoginScreen::BuildRegisterForm()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeInputField(RegisterEmailInput,
            FText::FromString(TEXT("EMAIL ADDRESS")),
            FText::FromString(TEXT("your@coven.com")), false) ]

        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeInputField(RegisterPasswordInput,
            FText::FromString(TEXT("CRAFT A PASSPHRASE")),
            FText::FromString(TEXT("8+ chars, uppercase & symbol")), true) ]

        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadLG)
        [ MakeInputField(ConfirmPasswordInput,
            FText::FromString(TEXT("CONFIRM PASSPHRASE")),
            FText::FromString(TEXT("once more, with feeling")), true) ]

        + SVerticalBox::Slot().AutoHeight()
        [
            BuildPrimaryButton(
                FText::FromString(TEXT("BEGIN THE RITE")),
                FSimpleDelegate::CreateSP(this, &SGrimoireLoginScreen::OnRegisterPressed))
        ];
}

// --------------------------------------------------------
//  Verify form — shown after successful registration
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireLoginScreen::BuildVerifyForm()
{
    return SNew(SVerticalBox)

        // Small ornament
        + SVerticalBox::Slot()
        .AutoHeight()
        .HAlign(HAlign_Center)
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [
            SNew(STextBlock)
            .Text(FText::FromString(TEXT("* * *")))
            .Font(GrimoireStyle::FontDisplay(10.f))
            .ColorAndOpacity(GrimoireStyle::SC_GoldFaint)
        ]

        // Instruction
        + SVerticalBox::Slot()
        .AutoHeight()
        .HAlign(HAlign_Center)
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadLG)
        [
            SNew(STextBlock)
            .Text(FText::FromString(
                TEXT("A confirmation seal has been sent\nto your sanctum. Enter it below.")))
            .Font(GrimoireStyle::FontBodyItalic(15.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
            .Justification(ETextJustify::Center)
            .AutoWrapText(true)
        ]

        // Code input — oversized, centered, gold text
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadLG)
        [
            SNew(SVerticalBox)
            + SVerticalBox::Slot().AutoHeight()
            .Padding(2.f, 0.f, 0.f, 5.f)
            [
                SNew(STextBlock)
                .Text(FText::FromString(TEXT("CONFIRMATION SEAL")))
                .Font(GrimoireStyle::FontUI(9.f))
                .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                .Justification(ETextJustify::Center)
            ]
            + SVerticalBox::Slot().AutoHeight()
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::BorderGold)
                .Padding(GrimoireStyle::BorderPx)
                [
                    SNew(SBox)
                    .HeightOverride(60.f)
                    [
                        SNew(SBorder)
                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                        .BorderBackgroundColor(GrimoireStyle::Surface2)
                        .HAlign(HAlign_Fill)
                        .VAlign(VAlign_Center)
                        .Padding(FMargin(GrimoireStyle::PadMD, 0.f))
                        [
                            SAssignNew(VerifyCodeInput, SEditableText)
                            .HintText(FText::FromString(TEXT("000000")))
                            .Font(GrimoireStyle::FontDisplay(26.f))
                            .ColorAndOpacity(GrimoireStyle::SC_Gold)
                            .Justification(ETextJustify::Center)
                        ]
                    ]
                ]
            ]
        ]

        // Consecrate button
        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [
            BuildPrimaryButton(
                FText::FromString(TEXT("CONSECRATE")),
                FSimpleDelegate::CreateSP(this, &SGrimoireLoginScreen::OnVerifyPressed))
        ]

        // Back link
        + SVerticalBox::Slot().AutoHeight()
        .HAlign(HAlign_Center)
        [
            SNew(SButton)
            .ButtonStyle(FCoreStyle::Get(), "NoBorder")
            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
            .OnClicked_Lambda([this]()
            {
                bShowingVerification = false;
                OnTabChanged(ELoginTab::Initiate);
                SetStatus(TEXT(""), false);
                return FReply::Handled();
            })
            [
                SNew(STextBlock)
                .Text(FText::FromString(TEXT("Back to registration")))
                .Font(GrimoireStyle::FontBodyItalic(14.f))
                .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
            ]
        ];
}

// --------------------------------------------------------
//  Lore footer
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireLoginScreen::BuildLoreFooter()
{
    return SNew(SVerticalBox)
        + SVerticalBox::Slot().AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ BuildOrnamentDivider() ]

        + SVerticalBox::Slot().AutoHeight()
        .HAlign(HAlign_Center)
        [
            SNew(STextBlock)
            .Text(FText::FromString(
                TEXT("\"What is written here shall not\nbe forgotten by flame or flood.\"")))
            .Font(GrimoireStyle::FontBodyItalic(14.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
            .Justification(ETextJustify::Center)
            .AutoWrapText(true)
        ];
}

// --------------------------------------------------------
//  Actions
// --------------------------------------------------------

void SGrimoireLoginScreen::OnScreenActivated()
{
    if (!bNeedsReset) return;
    bNeedsReset = false;

    bIsLoading = false;
    PendingEmail = TEXT("");
    SetStatus(TEXT(""), false);
    // Switch back to login tab without clearing fields —
    // programmatic SetText can break Slate input state
    OnTabChanged(ELoginTab::Enter);
}

void SGrimoireLoginScreen::RequestReset()
{
    bNeedsReset = true;
}

void SGrimoireLoginScreen::OnLoginPressed()
{
    if (!Auth() || bIsLoading) return;

    const FString Email    = LoginEmailInput.IsValid()    ? LoginEmailInput->GetText().ToString()    : TEXT("");
    const FString Password = LoginPasswordInput.IsValid() ? LoginPasswordInput->GetText().ToString() : TEXT("");

    if (Email.IsEmpty() || Password.IsEmpty())
    { SetStatus(TEXT("Please fill in all fields."), true); return; }

    SetLoading(true);
    SetStatus(TEXT("Opening the tome..."), false);

    Auth()->Login(Email, Password, FOnAuthComplete::CreateSP(
        this, &SGrimoireLoginScreen::HandleLoginResult));
}

void SGrimoireLoginScreen::HandleLoginResult(const FAuthResult& Result)
{
    SetLoading(false);
    if (Result.bSuccess)
    {
        // Set user ID filter and migrate any pre-filter orphaned entries
        if (Store() && Auth())
        {
            Store()->SetCurrentUserID(Auth()->GetCognitoSub());
            Store()->MigrateOrphanedEntries();
        }
        SetStatus(TEXT(""), false);
        NavigateTo(FName("Dashboard"));
    }
    else
    { SetStatus(Result.ErrorMessage.IsEmpty()
        ? TEXT("The rite failed. Check your credentials.")
        : Result.ErrorMessage, true); }
}

void SGrimoireLoginScreen::OnRegisterPressed()
{
    if (!Auth() || bIsLoading) return;

    const FString Email   = RegisterEmailInput.IsValid()  ? RegisterEmailInput->GetText().ToString()  : TEXT("");
    const FString Pass    = RegisterPasswordInput.IsValid() ? RegisterPasswordInput->GetText().ToString() : TEXT("");
    const FString Confirm = ConfirmPasswordInput.IsValid() ? ConfirmPasswordInput->GetText().ToString() : TEXT("");

    if (Email.IsEmpty() || Pass.IsEmpty() || Confirm.IsEmpty())
    { SetStatus(TEXT("Please fill in all fields."), true); return; }
    if (Pass != Confirm)
    { SetStatus(TEXT("The passphrases do not match."), true); return; }
    if (Pass.Len() < 8)
    { SetStatus(TEXT("Passphrase must be at least 8 characters."), true); return; }

    SetLoading(true);
    SetStatus(TEXT("Beginning the rite..."), false);

    Auth()->RegisterUser(Email, Pass, FOnAuthComplete::CreateSP(
        this, &SGrimoireLoginScreen::HandleRegisterResult));
}

void SGrimoireLoginScreen::HandleRegisterResult(const FAuthResult& Result)
{
    SetLoading(false);
    if (Result.bSuccess)
    {
    const FString Email = RegisterEmailInput.IsValid() ? RegisterEmailInput->GetText().ToString() : TEXT("");
        ShowVerification(Email);
    }
    else
    {
        SetStatus(Result.ErrorMessage.IsEmpty()
            ? TEXT("The rite could not be completed.")
            : Result.ErrorMessage, true);
    }
}

void SGrimoireLoginScreen::ShowVerification(const FString& Email)
{
    PendingEmail         = Email;
    bShowingVerification = true;
    if (TabSwitcher.IsValid()) TabSwitcher->SetActiveWidgetIndex(2);
    SetStatus(TEXT(""), false);
}

void SGrimoireLoginScreen::OnVerifyPressed()
{
    if (!Auth() || bIsLoading) return;

    const FString Code = VerifyCodeInput.IsValid() ? VerifyCodeInput->GetText().ToString() : TEXT("");
    if (Code.IsEmpty())
    { SetStatus(TEXT("Enter the code sent to your email."), true); return; }

    SetLoading(true);
    SetStatus(TEXT("Consecrating the seal..."), false);

    Auth()->ConfirmRegistration(PendingEmail, Code, FOnAuthComplete::CreateSP(
        this, &SGrimoireLoginScreen::HandleVerifyResult));
}

void SGrimoireLoginScreen::HandleVerifyResult(const FAuthResult& Result)
{
    SetLoading(false);
    if (Result.bSuccess)
    {
        bShowingVerification = false;
        SetStatus(TEXT("Initiation complete. You may now enter."), false);
        OnTabChanged(ELoginTab::Enter);
    }
    else
    {
        SetStatus(Result.ErrorMessage.IsEmpty()
            ? TEXT("The seal was not accepted.")
            : Result.ErrorMessage, true);
    }
}

void SGrimoireLoginScreen::OnTabChanged(ELoginTab NewTab)
{
    ActiveTab = NewTab;
    bShowingVerification = false;
    if (TabSwitcher.IsValid())
        TabSwitcher->SetActiveWidgetIndex(NewTab == ELoginTab::Enter ? 0 : 1);
    SetStatus(TEXT(""), false);
}

void SGrimoireLoginScreen::SetStatus(const FString& Message, bool bIsError)
{
    if (StatusText.IsValid())
    {
        StatusText->SetText(FText::FromString(Message));
        StatusText->SetColorAndOpacity(bIsError
            ? GrimoireStyle::SC(GrimoireStyle::TypeSpell)
            : GrimoireStyle::SC_TextMuted);
    }
}

void SGrimoireLoginScreen::SetLoading(bool bLoading) { bIsLoading = bLoading; }
