#pragma once

#include "CoreMinimal.h"
#include "SGrimoireBaseWidget.h"

// ============================================================
//  GRIMOIRE APP — Settings / Profile Screen
//  SGrimoireSettingsScreen.h
//
//  Sections:
//    - Account: user ID, email (from token claims), sign out
//    - Sync: status, last synced time, manual sync trigger
//    - Data: entry count, local DB size
//    - App: version, build info
//    - Beta 2 placeholder: Pro / Lemon Squeezy (coming soon)
// ============================================================

class GRIMOIREAPP_API SGrimoireSettingsScreen : public SGrimoireBaseWidget
{
public:
    SLATE_BEGIN_ARGS(SGrimoireSettingsScreen) {}
        SLATE_ARGUMENT(UGrimoireGameInstance*, GameInstance)
        SLATE_EVENT(FOnNavigate, OnNavigate)
    SLATE_END_ARGS()

    void Construct(const FArguments& InArgs);
    void OnScreenActivated();

private:

    // Live widget refs
    TSharedPtr<STextBlock> SyncStatusText;
    TSharedPtr<STextBlock> SyncButtonText;
    TSharedPtr<STextBlock> EntryCountText;
    bool bSyncing = false;

    // Builders
    TSharedRef<SWidget> BuildTopBar();
    TSharedRef<SWidget> BuildAccountSection();
    TSharedRef<SWidget> BuildSyncSection();
    TSharedRef<SWidget> BuildDataSection();
    TSharedRef<SWidget> BuildAppSection();
    TSharedRef<SWidget> BuildProPlaceholder();
    TSharedRef<SWidget> BuildBottomNav();

    // Reusable row builders
    TSharedRef<SWidget> MakeInfoRow(const FText& Label, const FText& Value);
    TSharedRef<SWidget> MakeSectionHeader(const FText& Label);
    TSharedRef<SWidget> MakeDivider();
    TSharedRef<SWidget> BuildNavItem(
        const FText& Glyph, const FText& Label,
        FName TargetScreen, bool bActive = false);

    // Logic
    void TriggerSync();
    void SignOut();
    FText GetUserDisplayID() const;
    FText GetEntryCountText() const;
};
