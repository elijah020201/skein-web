#include "SGrimoireSettingsScreen.h"
#include "GrimoireStyle.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SSpacer.h"

// ============================================================
//  GRIMOIRE APP — Settings / Profile Screen
//  SGrimoireSettingsScreen.cpp
// ============================================================

#define APP_VERSION TEXT("0.1.0-beta")
#define APP_BUILD   TEXT("2026.02")

void SGrimoireSettingsScreen::Construct(const FArguments& InArgs)
{
    SGrimoireBaseWidget::Construct(
        SGrimoireBaseWidget::FArguments()
        .GameInstance(InArgs._GameInstance)
        .OnNavigate(InArgs._OnNavigate));

    ChildSlot
    [
        SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::BG)
        [
            SNew(SVerticalBox)

            // Top bar
            + SVerticalBox::Slot()
            .AutoHeight()
            [ BuildTopBar() ]

            // Scrollable content
            + SVerticalBox::Slot()
            .FillHeight(1.f)
            [
                SNew(SScrollBox)
                .ScrollBarVisibility(EVisibility::Collapsed)

                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD)
                [ BuildAccountSection() ]

                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadMD, 0.f)
                [ MakeDivider() ]

                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD)
                [ BuildSyncSection() ]

                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadMD, 0.f)
                [ MakeDivider() ]

                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD)
                [ BuildDataSection() ]

                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadMD, 0.f)
                [ MakeDivider() ]

                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD)
                [ BuildProPlaceholder() ]

                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadMD, 0.f)
                [ MakeDivider() ]

                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD)
                [ BuildAppSection() ]

                // Bottom padding
                + SScrollBox::Slot()
                .Padding(0.f, GrimoireStyle::PadXL)
                [ SNew(SSpacer) ]
            ]

            // Hairline
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::Border)
                [ SNew(SBox).HeightOverride(1.f) ]
            ]

            // Bottom nav
            + SVerticalBox::Slot()
            .AutoHeight()
            [ BuildBottomNav() ]
        ]
    ];
}

void SGrimoireSettingsScreen::OnScreenActivated()
{
    // Refresh entry count when screen is shown
    if (EntryCountText.IsValid())
        EntryCountText->SetText(GetEntryCountText());
}

// ============================================================
//  TOP BAR
// ============================================================

TSharedRef<SWidget> SGrimoireSettingsScreen::BuildTopBar()
{
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(FMargin(GrimoireStyle::PadMD, 0.f))
        [
            SNew(SBox)
            .HeightOverride(GrimoireStyle::TopBarHeight)
            [
                SNew(SHorizontalBox)

                // Title
                + SHorizontalBox::Slot()
                .FillWidth(1.f)
                .VAlign(VAlign_Center)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("PROFILE & SETTINGS")))
                    .Font(GrimoireStyle::FontDisplay(15.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                ]

                // Version pill
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::GoldFaint)
                    .Padding(FMargin(GrimoireStyle::PadSM, 3.f))
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(APP_VERSION))
                        .Font(GrimoireStyle::FontUI(7.f))
                        .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
                    ]
                ]
            ]
        ];
}

// ============================================================
//  ACCOUNT SECTION
// ============================================================

TSharedRef<SWidget> SGrimoireSettingsScreen::BuildAccountSection()
{
    const FString UserID = Auth() ? Auth()->GetCognitoSub() : TEXT("—");
    // Truncate UUID for display: show first 8 chars
    const FString DisplayID = UserID.IsEmpty() ? TEXT("—")
        : UserID.Left(8).ToUpper() + TEXT("...");

    return SNew(SVerticalBox)

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("ACCOUNT"))) ]

        // User ID row
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeInfoRow(
            FText::FromString(TEXT("USER ID")),
            FText::FromString(DisplayID)) ]

        // Account status row
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeInfoRow(
            FText::FromString(TEXT("STATUS")),
            FText::FromString(TEXT("Free — Beta"))) ]

        // Sign out button
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, GrimoireStyle::PadMD, 0.f, 0.f)
        [
            SNew(SButton)
            .ButtonColorAndOpacity(GrimoireStyle::Surface2)
            .OnClicked_Lambda([this]()
            {
                SignOut();
                return FReply::Handled();
            })
            [
                SNew(SBox)
                .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadSM))
                [
                    SNew(SHorizontalBox)

                    + SHorizontalBox::Slot()
                    .FillWidth(1.f)
                    .VAlign(VAlign_Center)
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("SIGN OUT")))
                        .Font(GrimoireStyle::FontUI(11.f))
                        .ColorAndOpacity(GrimoireStyle::SC_Red)
                    ]

                    + SHorizontalBox::Slot()
                    .AutoWidth()
                    .VAlign(VAlign_Center)
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT(">")))
                        .Font(GrimoireStyle::FontUI(11.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                    ]
                ]
            ]
        ]
    ;
}

// ============================================================
//  SYNC SECTION
// ============================================================

TSharedRef<SWidget> SGrimoireSettingsScreen::BuildSyncSection()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("SYNC"))) ]

        // Sync status
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [
            SNew(SHorizontalBox)

            + SHorizontalBox::Slot()
            .FillWidth(1.f)
            .VAlign(VAlign_Center)
            [
                SNew(STextBlock)
                .Text(FText::FromString(TEXT("STATUS")))
                .Font(GrimoireStyle::FontUI(8.f))
                .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
            ]

            + SHorizontalBox::Slot()
            .AutoWidth()
            .VAlign(VAlign_Center)
            [
                SAssignNew(SyncStatusText, STextBlock)
                .Text(FText::FromString(
                    Auth() && Auth()->IsLoggedIn()
                        ? TEXT("Connected")
                        : TEXT("Not signed in")))
                .Font(GrimoireStyle::FontBody(13.f))
                .ColorAndOpacity(
                    Auth() && Auth()->IsLoggedIn()
                        ? GrimoireStyle::SC_Gold
                        : GrimoireStyle::SC_TextFaint)
            ]
        ]

        // Manual sync button
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, GrimoireStyle::PadSM, 0.f, 0.f)
        [
            SNew(SButton)
            .ButtonColorAndOpacity(GrimoireStyle::Surface2)
            .OnClicked_Lambda([this]()
            {
                TriggerSync();
                return FReply::Handled();
            })
            [
                SNew(SBox)
                .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadSM))
                [
                    SNew(SHorizontalBox)

                    + SHorizontalBox::Slot()
                    .FillWidth(1.f)
                    .VAlign(VAlign_Center)
                    [
                        SAssignNew(SyncButtonText, STextBlock)
                        .Text(FText::FromString(TEXT("SYNC NOW")))
                        .Font(GrimoireStyle::FontUI(11.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
                    ]

                    + SHorizontalBox::Slot()
                    .AutoWidth()
                    .VAlign(VAlign_Center)
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT(">")))
                        .Font(GrimoireStyle::FontUI(11.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                    ]
                ]
            ]
        ]

        // Full sync (download from cloud)
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, GrimoireStyle::PadSM, 0.f, 0.f)
        [
            SNew(SButton)
            .ButtonColorAndOpacity(GrimoireStyle::Surface2)
            .OnClicked_Lambda([this]()
            {
                if (FGrimoireSyncService* S = Sync())
                {
                    if (SyncStatusText.IsValid())
                        SyncStatusText->SetText(
                            FText::FromString(TEXT("Downloading...")));

                    S->FullSync(FOnSyncComplete::CreateLambda(
                        [this](bool bOk, FString Msg)
                        {
                            if (SyncStatusText.IsValid())
                                SyncStatusText->SetText(FText::FromString(
                                    bOk ? TEXT("Full sync complete") : TEXT("Sync failed")));
                        }));
                }
                return FReply::Handled();
            })
            [
                SNew(SBox)
                .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadSM))
                [
                    SNew(SHorizontalBox)
                    + SHorizontalBox::Slot()
                    .FillWidth(1.f)
                    .VAlign(VAlign_Center)
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("RESTORE FROM CLOUD")))
                        .Font(GrimoireStyle::FontUI(11.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
                    ]
                    + SHorizontalBox::Slot()
                    .AutoWidth()
                    .VAlign(VAlign_Center)
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT(">")))
                        .Font(GrimoireStyle::FontUI(11.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                    ]
                ]
            ]
        ]
    ;
}

// ============================================================
//  DATA SECTION
// ============================================================

TSharedRef<SWidget> SGrimoireSettingsScreen::BuildDataSection()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("YOUR DATA"))) ]

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            .FillWidth(1.f)
            .VAlign(VAlign_Center)
            [
                SNew(STextBlock)
                .Text(FText::FromString(TEXT("TOTAL ENTRIES")))
                .Font(GrimoireStyle::FontUI(8.f))
                .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
            ]
            + SHorizontalBox::Slot()
            .AutoWidth()
            .VAlign(VAlign_Center)
            [
                SAssignNew(EntryCountText, STextBlock)
                .Text(GetEntryCountText())
                .Font(GrimoireStyle::FontBody(13.f))
                .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
            ]
        ]

        + SVerticalBox::Slot()
        .AutoHeight()
        [ MakeInfoRow(
            FText::FromString(TEXT("LOCAL STORAGE")),
            FText::FromString(TEXT("SQLite"))) ]

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, GrimoireStyle::PadSM, 0.f, 0.f)
        [ MakeInfoRow(
            FText::FromString(TEXT("CLOUD STORAGE")),
            FText::FromString(TEXT("AWS DynamoDB"))) ]
    ;
}

// ============================================================
//  PRO PLACEHOLDER (Beta 2)
// ============================================================

TSharedRef<SWidget> SGrimoireSettingsScreen::BuildProPlaceholder()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("GRIMOIRE PRO"))) ]

        + SVerticalBox::Slot()
        .AutoHeight()
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::GoldFaint)
            .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadSM))
            [
                SNew(SHorizontalBox)

                + SHorizontalBox::Slot()
                .FillWidth(1.f)
                .VAlign(VAlign_Center)
                [
                    SNew(SVerticalBox)

                    + SVerticalBox::Slot()
                    .AutoHeight()
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("Unlock the full grimoire")))
                        .Font(GrimoireStyle::FontBodyMedium(14.f))
                        .ColorAndOpacity(GrimoireStyle::SC_Gold)
                    ]

                    + SVerticalBox::Slot()
                    .AutoHeight()
                    .Padding(0.f, 3.f, 0.f, 0.f)
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(
                            TEXT("Collections, coven sharing & more.\nComing in Beta 2.")))
                        .Font(GrimoireStyle::FontBodyItalic(12.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                        .AutoWrapText(true)
                    ]
                ]

                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(GrimoireStyle::PadMD, 0.f, 0.f, 0.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::Border)
                    .Padding(FMargin(GrimoireStyle::PadSM, 4.f))
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("SOON")))
                        .Font(GrimoireStyle::FontUI(8.f))
                        .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
                    ]
                ]
            ]
        ]
    ;
}

// ============================================================
//  APP INFO SECTION
// ============================================================

TSharedRef<SWidget> SGrimoireSettingsScreen::BuildAppSection()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("APP"))) ]

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeInfoRow(
            FText::FromString(TEXT("VERSION")),
            FText::FromString(APP_VERSION)) ]

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeInfoRow(
            FText::FromString(TEXT("BUILD")),
            FText::FromString(APP_BUILD)) ]

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeInfoRow(
            FText::FromString(TEXT("PLATFORM")),
            FText::FromString(
#if PLATFORM_ANDROID
                TEXT("Android")
#elif PLATFORM_IOS
                TEXT("iOS")
#else
                TEXT("Desktop")
#endif
            )) ]

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, GrimoireStyle::PadMD, 0.f, 0.f)
        [
            SNew(STextBlock)
            .Text(FText::FromString(TEXT("Grimoire — Your personal book of shadows.")))
            .Font(GrimoireStyle::FontBodyItalic(11.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
            .AutoWrapText(true)
        ]
    ;
}

// ============================================================
//  BOTTOM NAV
// ============================================================

TSharedRef<SWidget> SGrimoireSettingsScreen::BuildBottomNav()
{
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(FMargin(0.f))
        [
            SNew(SBox)
            .HeightOverride(GrimoireStyle::BottomNavHeight)
            [
                SNew(SHorizontalBox)
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("T")),
                    FText::FromString(TEXT("TOME")),    FName("Dashboard")) ]
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("E")),
                    FText::FromString(TEXT("ENTRIES")), FName("Entries")) ]
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("C")),
                    FText::FromString(TEXT("COLLECT")), FName("Collection")) ]
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("P")),
                    FText::FromString(TEXT("PROFILE")), FName("Settings"), true) ]
            ]
        ];
}

TSharedRef<SWidget> SGrimoireSettingsScreen::BuildNavItem(
    const FText& Glyph, const FText& Label, FName TargetScreen, bool bActive)
{
    return SNew(SButton)
        .ButtonStyle(FCoreStyle::Get(), "NoBorder")
        .ButtonColorAndOpacity(GrimoireStyle::Transparent)
        .HAlign(HAlign_Center)
        .VAlign(VAlign_Center)
        .OnClicked_Lambda([this, TargetScreen]()
        {
            NavigateTo(TargetScreen);
            return FReply::Handled();
        })
        [
            SNew(SVerticalBox)
            + SVerticalBox::Slot().AutoHeight().HAlign(HAlign_Center)
            .Padding(0.f, 6.f, 0.f, 2.f)
            [
                SNew(SBox).WidthOverride(4.f).HeightOverride(4.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(bActive
                        ? GrimoireStyle::Gold : GrimoireStyle::Transparent)
                ]
            ]
            + SVerticalBox::Slot().AutoHeight().HAlign(HAlign_Center)
            [
                SNew(STextBlock).Text(Glyph)
                .Font(GrimoireStyle::FontUI(14.f))
                .ColorAndOpacity(bActive
                    ? GrimoireStyle::SC_Gold : GrimoireStyle::SC_TextFaint)
            ]
            + SVerticalBox::Slot().AutoHeight().HAlign(HAlign_Center)
            .Padding(0.f, 2.f, 0.f, 6.f)
            [
                SNew(STextBlock).Text(Label)
                .Font(GrimoireStyle::FontUI(7.f))
                .ColorAndOpacity(bActive
                    ? GrimoireStyle::SC_Gold : GrimoireStyle::SC_TextFaint)
            ]
        ];
}

// ============================================================
//  REUSABLE WIDGETS
// ============================================================

TSharedRef<SWidget> SGrimoireSettingsScreen::MakeInfoRow(
    const FText& Label, const FText& Value)
{
    return SNew(SHorizontalBox)
        + SHorizontalBox::Slot()
        .FillWidth(1.f)
        .VAlign(VAlign_Center)
        [
            SNew(STextBlock)
            .Text(Label)
            .Font(GrimoireStyle::FontUI(8.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
        ]
        + SHorizontalBox::Slot()
        .AutoWidth()
        .VAlign(VAlign_Center)
        [
            SNew(STextBlock)
            .Text(Value)
            .Font(GrimoireStyle::FontBody(13.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
        ];
}

TSharedRef<SWidget> SGrimoireSettingsScreen::MakeSectionHeader(const FText& Label)
{
    return SNew(SHorizontalBox)
        + SHorizontalBox::Slot()
        .AutoWidth()
        .VAlign(VAlign_Center)
        .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
        [
            SNew(STextBlock)
            .Text(Label)
            .Font(GrimoireStyle::FontUI(8.f))
            .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
        ]
        + SHorizontalBox::Slot()
        .FillWidth(1.f)
        .VAlign(VAlign_Center)
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::Border)
            [ SNew(SBox).HeightOverride(1.f) ]
        ];
}

TSharedRef<SWidget> SGrimoireSettingsScreen::MakeDivider()
{
    return SNew(SBox)
        .HeightOverride(1.f)
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::Surface2)
        ];
}

// ============================================================
//  LOGIC
// ============================================================

void SGrimoireSettingsScreen::TriggerSync()
{
    if (bSyncing) return;

    if (!Auth() || !Auth()->IsLoggedIn())
    {
        if (SyncStatusText.IsValid())
            SyncStatusText->SetText(FText::FromString(TEXT("Not signed in")));
        return;
    }

    bSyncing = true;
    if (SyncButtonText.IsValid())
        SyncButtonText->SetText(FText::FromString(TEXT("SYNCING...")));
    if (SyncStatusText.IsValid())
        SyncStatusText->SetText(FText::FromString(TEXT("Syncing...")));

    if (FGrimoireSyncService* S = Sync())
    {
        S->SyncPendingEntries(FOnSyncComplete::CreateLambda(
            [this](bool bOk, FString Msg)
            {
                bSyncing = false;
                if (SyncButtonText.IsValid())
                    SyncButtonText->SetText(FText::FromString(TEXT("SYNC NOW")));
                if (SyncStatusText.IsValid())
                    SyncStatusText->SetText(FText::FromString(
                        bOk ? TEXT("Synced") : TEXT("Sync failed")));
            }));
    }
}

void SGrimoireSettingsScreen::SignOut()
{
    if (Auth())
        Auth()->Logout();
    NavigateTo(FName("Login"));
}

FText SGrimoireSettingsScreen::GetUserDisplayID() const
{
    if (!Auth() || !Auth()->IsLoggedIn())
        return FText::FromString(TEXT("—"));
    const FString Sub = Auth()->GetCognitoSub();
    return FText::FromString(Sub.IsEmpty() ? TEXT("—") : Sub.Left(8).ToUpper() + TEXT("..."));
}

FText SGrimoireSettingsScreen::GetEntryCountText() const
{
    if (!Store()) return FText::FromString(TEXT("0"));
    TArray<FGrimoireEntry> All;
    Store()->LoadAllEntries(All);
    All.RemoveAll([](const FGrimoireEntry& E){ return E.bIsDeleted; });
    return FText::AsNumber(All.Num());
}
