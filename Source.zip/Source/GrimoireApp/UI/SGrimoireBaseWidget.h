#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "GrimoireStyle.h"
#include "../GrimoireGameInstance.h"

// ============================================================
//  GRIMOIRE APP — Base Screen Widget
//  SGrimoireBaseWidget.h
//
//  All screens inherit from this. Provides:
//    — Service shortcuts (Auth, Store, Sync)
//    — Navigation delegate
//    — Shared component library (cards, buttons, inputs,
//      dividers, section headers)
//
//  Design language: Obsidian Glass
//    — Cards: 1px gold-tinted border, dark surface bg
//    — Buttons: full-width, crimson fill, 48px height
//    — Inputs: dark fill, 1px border, 44px height
//    — Section headers: small-caps gold label + hairline
//    — Ornamental dividers: ——  ✦  ——
// ============================================================

DECLARE_DELEGATE_OneParam(FOnNavigate, FName /*ScreenName*/);

class GRIMOIREAPP_API SGrimoireBaseWidget : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(SGrimoireBaseWidget) {}
        SLATE_ARGUMENT(UGrimoireGameInstance*, GameInstance)
        SLATE_EVENT(FOnNavigate, OnNavigate)
    SLATE_END_ARGS()

    void Construct(const FArguments& InArgs)
    {
        GameInstance = InArgs._GameInstance;
        OnNavigate   = InArgs._OnNavigate;
    }

    /** Called by ScreenManager each time this screen becomes visible. Override to refresh data or reset state. */
    virtual void OnScreenActivated() {}

protected:

    UGrimoireGameInstance* GameInstance = nullptr;
    FOnNavigate OnNavigate;

    FGrimoireAuthService* Auth()  const { return GameInstance ? &GameInstance->GetAuthService()  : nullptr; }
    FGrimoireLocalStore*  Store() const { return GameInstance ? &GameInstance->GetLocalStore()   : nullptr; }
    FGrimoireSyncService* Sync()  const { return GameInstance ? &GameInstance->GetSyncService()  : nullptr; }
    void NavigateTo(FName Screen)       { OnNavigate.ExecuteIfBound(Screen); }

    // --------------------------------------------------------
    //  CARD
    //  Standard surface container with hairline border.
    //  Optional gold border variant for highlighted state.
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildCard(
        TSharedRef<SWidget> Content,
        const FLinearColor& BgColor     = GrimoireStyle::Surface,
        const FLinearColor& BorderColor = GrimoireStyle::Border,
        const FMargin&      Padding     = FMargin(GrimoireStyle::PadLG))
    {
        return SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(BorderColor)
            .Padding(GrimoireStyle::BorderPx)
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(BgColor)
                .Padding(Padding)
                [ Content ]
            ];
    }

    // --------------------------------------------------------
    //  PRIMARY BUTTON
    //  Crimson fill, full width, 48px tall.
    //  Label in Cinzel UI font, cream text.
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildPrimaryButton(
        const FText& Label,
        FSimpleDelegate OnClicked,
        bool bDestructive = false)
    {
        const FLinearColor BgColor = bDestructive ? GrimoireStyle::RedDim : GrimoireStyle::Red;

        return SNew(SBox)
            .HeightOverride(GrimoireStyle::ButtonHeight)
            [
                SNew(SButton)
                .ButtonColorAndOpacity(BgColor)
                .OnClicked_Lambda([OnClicked]()
                {
                    OnClicked.ExecuteIfBound();
                    return FReply::Handled();
                })
                .HAlign(HAlign_Center)
                .VAlign(VAlign_Center)
                [
                    SNew(STextBlock)
                    .Text(Label)
                    .Font(GrimoireStyle::FontUI(11.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                ]
            ];
    }

    // --------------------------------------------------------
    //  GHOST BUTTON
    //  Transparent fill, gold border, gold text.
    //  Used for secondary actions.
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildGhostButton(
        const FText& Label,
        FSimpleDelegate OnClicked,
        bool bDestructive = false)
    {
        const FLinearColor BorderCol = bDestructive 
            ? FLinearColor(0.4f, 0.05f, 0.05f, 1.f) 
            : GrimoireStyle::BorderGold;
        return SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(BorderCol)
            .Padding(GrimoireStyle::BorderPx)
            [
                SNew(SBox)
                .HeightOverride(GrimoireStyle::ButtonHeight - 2.f)
                [
                    SNew(SButton)
                    .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                    .OnClicked_Lambda([OnClicked]()
                    {
                        OnClicked.ExecuteIfBound();
                        return FReply::Handled();
                    })
                    .HAlign(HAlign_Center)
                    .VAlign(VAlign_Center)
                    [
                        SNew(STextBlock)
                        .Text(Label)
                        .Font(GrimoireStyle::FontUI(11.f))
                        .ColorAndOpacity(bDestructive ? GrimoireStyle::SC_Red : GrimoireStyle::SC_Gold)
                    ]
                ]
            ];
    }

    // --------------------------------------------------------
    //  SECTION HEADER
    //  Small-caps label (Cinzel 9pt, muted gold) + hairline rule.
    //  Optional right-aligned link.
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildSectionHeader(
        const FText& Title,
        const FText& LinkText = FText::GetEmpty(),
        FSimpleDelegate OnLinkClicked = FSimpleDelegate())
    {
        TSharedRef<SHorizontalBox> Row = SNew(SHorizontalBox)

            // Left: gold diamond ornament + label
            + SHorizontalBox::Slot()
            .AutoWidth()
            .VAlign(VAlign_Center)
            [
                SNew(SHorizontalBox)
                // Tiny diamond
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(0.f, 0.f, GrimoireStyle::PadXS + 2.f, 0.f)
                [
                    SNew(SBox)
                    .WidthOverride(4.f)
                    .HeightOverride(4.f)
                    [
                        SNew(SBorder)
                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                        .BorderBackgroundColor(GrimoireStyle::GoldDim)
                    ]
                ]
                + SHorizontalBox::Slot()
                .AutoWidth()
                [
                    SNew(STextBlock)
                    .Text(Title)
                    .Font(GrimoireStyle::FontUI(9.f))
                    .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
                ]
            ]

            // Hairline rule
            + SHorizontalBox::Slot()
            .FillWidth(1.f)
            .VAlign(VAlign_Center)
            .Padding(GrimoireStyle::PadSM, 0.f)
            [
                SNew(SBox).HeightOverride(1.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::Border)
                ]
            ];

        // Optional right link
        if (!LinkText.IsEmpty())
        {
            Row->AddSlot()
            .AutoWidth()
            .VAlign(VAlign_Center)
            [
                SNew(SButton)
                .ButtonStyle(FCoreStyle::Get(), "NoBorder")
                .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                .OnClicked_Lambda([OnLinkClicked]()
                {
                    OnLinkClicked.ExecuteIfBound();
                    return FReply::Handled();
                })
                [
                    SNew(STextBlock)
                    .Text(LinkText)
                    .Font(GrimoireStyle::FontBodyItalic(12.f))
                    .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
                ]
            ];
        }

        return SNew(SBox)
            .Padding(FMargin(0.f, 0.f, 0.f, GrimoireStyle::PadSM))
            [ Row ];
    }

    // --------------------------------------------------------
    //  ORNAMENT DIVIDER
    //  Full-width hairline with centered diamond glyph.
    //  ——————  ✦  ——————
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildOrnamentDivider()
    {
        return SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            .FillWidth(1.f)
            .VAlign(VAlign_Center)
            [
                SNew(SBox).HeightOverride(1.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::Border)
                ]
            ]
            + SHorizontalBox::Slot()
            .AutoWidth()
            .VAlign(VAlign_Center)
            .Padding(GrimoireStyle::PadMD, 0.f)
            [
                SNew(STextBlock)
                .Text(FText::FromString(TEXT("*")))
                .Font(GrimoireStyle::FontDisplay(10.f))
                .ColorAndOpacity(GrimoireStyle::SC_GoldFaint)
            ]
            + SHorizontalBox::Slot()
            .FillWidth(1.f)
            .VAlign(VAlign_Center)
            [
                SNew(SBox).HeightOverride(1.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(GrimoireStyle::Border)
                ]
            ];
    }

    // --------------------------------------------------------
    //  TYPE BADGE
    //  Colored accent pill for entry type.
    //  Small colored square + type label.
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildTypeBadge(EGrimoireEntryType Type)
    {
        const FLinearColor TypeColor = GrimoireStyle::GetTypeColor(Type);
        const FText TypeLabel        = GrimoireStyle::GetTypeLabel(Type);

        return SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            .AutoWidth()
            .VAlign(VAlign_Center)
            .Padding(0.f, 0.f, GrimoireStyle::PadXS, 0.f)
            [
                SNew(SBox)
                .WidthOverride(5.f)
                .HeightOverride(5.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(TypeColor)
                ]
            ]
            + SHorizontalBox::Slot()
            .AutoWidth()
            .VAlign(VAlign_Center)
            [
                SNew(STextBlock)
                .Text(TypeLabel)
                .Font(GrimoireStyle::FontUI(9.f))
                .ColorAndOpacity(GrimoireStyle::SC(
                    FLinearColor::LerpUsingHSV(TypeColor,
                        GrimoireStyle::TextPrimary, 0.4f)))
            ];
    }
};
