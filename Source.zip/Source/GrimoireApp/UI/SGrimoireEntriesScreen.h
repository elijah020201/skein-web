#pragma once

#include "CoreMinimal.h"
#include "SGrimoireBaseWidget.h"
#include "../Core/DataModel/GrimoireEntry.h"

// ============================================================
//  GRIMOIRE APP — Entries List Screen
//  SGrimoireEntriesScreen.h
//
//  Full entry browser with:
//    - Search bar (filters by title + tags)
//    - Type filter chips (All / Spell / Ritual / Journal / ...)
//    - Sort toggle (Date / Name / Type)
//    - Scrollable medium-density entry list
//    - Empty state
//    - Back navigation + FAB to create new entry
// ============================================================

class GRIMOIREAPP_API SGrimoireEntriesScreen : public SGrimoireBaseWidget
{
public:
    SLATE_BEGIN_ARGS(SGrimoireEntriesScreen) {}
        SLATE_ARGUMENT(UGrimoireGameInstance*, GameInstance)
        SLATE_EVENT(FOnNavigate, OnNavigate)
    SLATE_END_ARGS()

    void Construct(const FArguments& InArgs);
    void OnScreenActivated();

private:

    // --------------------------------------------------------
    //  State
    // --------------------------------------------------------

    TArray<FGrimoireEntry>         AllEntries;
    TArray<FGrimoireEntry>         FilteredEntries;

    FString                        SearchText;
    EGrimoireEntryType             ActiveTypeFilter = (EGrimoireEntryType)255; // 255 = All
    int32                          SortMode         = 0; // 0=Date 1=Name 2=Type

    // Live widgets
    TSharedPtr<SVerticalBox>       EntryList;
    TSharedPtr<SBox>               FilterRowContainer;
    TSharedPtr<SBox>               SortRowContainer;
    TSharedPtr<STextBlock>         ResultCount;

    // --------------------------------------------------------
    //  Section builders
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildTopBar();
    TSharedRef<SWidget> BuildSearchBar();
    TSharedRef<SWidget> BuildFilterRow();
    TSharedRef<SWidget> BuildSortRow();
    TSharedRef<SWidget> BuildEntryList();
    TSharedRef<SWidget> BuildEntryCard(const FGrimoireEntry& Entry);
    TSharedRef<SWidget> BuildEmptyState();
    TSharedRef<SWidget> BuildFAB();
    TSharedRef<SWidget> BuildBottomNav();

    // Filter chip (All + each type)
    TSharedRef<SWidget> BuildFilterChip(
        const FText& Label,
        EGrimoireEntryType Type,  // 255 = All
        bool bActive);

    // Sort button
    TSharedRef<SWidget> BuildSortButton(
        const FText& Label,
        int32 Mode,
        bool bActive);

    // --------------------------------------------------------
    //  Data & filtering
    // --------------------------------------------------------

    void LoadEntries();
    void ApplyFilters();
    void RefreshList();
    void RefreshFilterRow();
    void RefreshSortRow();

    bool PassesTypeFilter(const FGrimoireEntry& E) const;
    bool PassesSearchFilter(const FGrimoireEntry& E) const;

    static FString FormatDate(const FString& ISO);

    // --------------------------------------------------------
    //  Bottom nav item
    // --------------------------------------------------------
    TSharedRef<SWidget> BuildNavItem(
        const FText& Glyph,
        const FText& Label,
        FName TargetScreen,
        bool bActive = false);
};
