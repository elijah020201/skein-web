#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "../GrimoireGameInstance.h"
#include "SGrimoireBaseWidget.h"
#include "../Core/DataModel/GrimoireEntry.h"

// ============================================================
//  GRIMOIRE APP — Screen Manager
//  SGrimoireScreenManager.h
//
//  The root widget that owns and switches between all screens.
//  Mounted once onto the viewport in GrimoireGameInstance.
//
//  Navigation works via FName screen identifiers:
//    "Login"     — login / register
//    "Dashboard" — main home feed
//    "Entries"   — full entry list
//    "Editor"    — create / edit an entry
//    "Collection"— single collection view
//    "Settings"  — account and sync settings
//
//  To navigate from any screen:
//    NavigateTo(FName("Dashboard"));
// ============================================================

class SGrimoireBaseWidget;
class SGrimoireLoginScreen;
class SGrimoireDashboardScreen;
class SGrimoireEntriesScreen;
class SGrimoireEditorScreen;
class SGrimoireSettingsScreen;

class GRIMOIREAPP_API SGrimoireScreenManager : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(SGrimoireScreenManager) {}
        SLATE_ARGUMENT(UGrimoireGameInstance*, GameInstance)
    SLATE_END_ARGS()

    void Construct(const FArguments& InArgs);

    // Navigate to a named screen, optionally passing context data
    void NavigateTo(FName ScreenName, TSharedPtr<FJsonObject> Context = nullptr);

    // Navigate to editor with a specific entry (empty = new entry)
    void NavigateToEditor(const FString& EntryID = TEXT(""), EGrimoireEntryType DefaultType = EGrimoireEntryType::JournalEntry);

    // Sign out — clears session and resets login screen
    void SignOut();

private:

    UGrimoireGameInstance* GameInstance = nullptr;

    // The switcher holds all screens — only one is visible at a time
    TSharedPtr<SWidgetSwitcher> Switcher;

    // Screen index map — populated in Construct()
    TMap<FName, int32>  ScreenIndex;
    TSharedPtr<SGrimoireEditorScreen>  EditorScreen;
    TSharedPtr<SGrimoireDashboardScreen> DashboardScreen;
    TSharedPtr<SGrimoireSettingsScreen>  SettingsScreen;
    TSharedPtr<SGrimoireLoginScreen>   LoginScreen;
    TMap<FName, TSharedPtr<SGrimoireBaseWidget>> ScreenWidgets;

    // Current screen name for back-stack
    TArray<FName> NavStack;

    // --------------------------------------------------------
    //  Screen builders
    //  Each returns a fully constructed screen widget.
    //  Called once in Construct() and cached in the Switcher.
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildLoginScreen();
    TSharedRef<SWidget> BuildDashboardScreen();
    TSharedRef<SWidget> BuildEntriesScreen();
    TSharedRef<SWidget> BuildEditorScreen();
    TSharedRef<SWidget> BuildSettingsScreen();
    TSharedRef<SWidget> BuildPlaceholderScreen(const FText& Label);

    // Navigate back to previous screen
    void NavigateBack();

    // Called by child screens via delegate
    void HandleNavigation(FName ScreenName);
};
