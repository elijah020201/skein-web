#pragma once

#include "CoreMinimal.h"
#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"

// ============================================================
//  FGrimoireUpdateChecker
//  Polls the Lambda app:version endpoint on startup.
//  Notifies the UI if an update is available.
// ============================================================

DECLARE_DELEGATE_ThreeParams(FOnUpdateCheckComplete,
    bool   /* bUpdateAvailable */,
    FString /* latestVersion */,
    FString /* downloadUrl */);

class GRIMOIREAPP_API FGrimoireUpdateChecker
{
public:
    void CheckForUpdate(
        const FString& APIEndpoint,
        const FString& CurrentVersion,
        const FString& Platform,           // "windows" | "mac" | "android"
        FOnUpdateCheckComplete OnComplete);
};
