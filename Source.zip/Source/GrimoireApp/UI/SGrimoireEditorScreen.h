#pragma once

#include "CoreMinimal.h"
#include "SGrimoireBaseWidget.h"
#include "../Core/DataModel/GrimoireEntry.h"

// ============================================================
//  GRIMOIRE APP — Entry Editor Screen
//  SGrimoireEditorScreen.h
//
//  Create / edit any entry type. Layout:
//    - Top bar: back | type selector | save button
//    - Universal header: title, tags, pin/fav, collection, visibility
//    - Tabbed body: Details | Notes | Assets
//      - Details tab fields vary by entry type
//      - Notes tab: free-form reflection / outcome notes
//      - Assets tab: placeholder for future image attachments
//    - Delete button (edit mode only)
// ============================================================

class GRIMOIREAPP_API SGrimoireEditorScreen : public SGrimoireBaseWidget
{
public:
    SLATE_BEGIN_ARGS(SGrimoireEditorScreen) {}
        SLATE_ARGUMENT(UGrimoireGameInstance*, GameInstance)
        SLATE_EVENT(FOnNavigate, OnNavigate)
    SLATE_END_ARGS()

    void Construct(const FArguments& InArgs);

    // Called by screen manager when navigating here
    // Pass empty string to create a new entry
    void SetEntryID(const FString& InEntryID);
    void SetInitialType(EGrimoireEntryType InType);
    void RefreshUniversalHeader();
    void RefreshTabBar();
    void RefreshActionBar();
    TSharedRef<SWidget> BuildActionBar();
    void SetViewMode(bool bInViewMode);
    TSharedRef<SWidget> BuildViewPage();

private:

    // --------------------------------------------------------
    //  State
    // --------------------------------------------------------

    FGrimoireEntry             WorkingEntry;     // In-memory copy being edited
    bool                       bIsNewEntry   = true;
    bool                       bViewMode     = false;  // true = read-only grimoire page
    int32                      ActiveTab   = 0;  // 0=Details 1=Notes 2=Assets
    bool                       bDirty      = false;

    TArray<FGrimoireCollection> AvailableCollections;

    // Live widget refs for dynamic updates
    TSharedPtr<SVerticalBox>   TabContent;
    TSharedPtr<STextBlock>     SaveStatusText;
    TSharedPtr<SBox>           TypeSelectorContainer;
    TSharedPtr<SBox>           TabBarContainer;
    TSharedPtr<SBox>           ActionBarContainer;
    bool                       bConfirmingDelete = false;
    TSharedPtr<SBox>           CollectionPickerContainer;
    TSharedPtr<SBox>           ToggleRowContainer;
    TSharedPtr<SBox>           VisibilityRowContainer;

    // --------------------------------------------------------
    //  Top-level builders
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildTopBar();
    TSharedRef<SWidget> BuildUniversalHeader();
    TSharedRef<SWidget> BuildTabBar();
    TSharedRef<SWidget> BuildTabContent();
    TSharedRef<SWidget> BuildBottomActions();

    // --------------------------------------------------------
    //  Tab content builders (by type)
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildDetailsTab();
    TSharedRef<SWidget> BuildNotesTab();
    TSharedRef<SWidget> BuildAssetsTab();

    // Type-specific details sections
    TSharedRef<SWidget> BuildSpellDetails();
    TSharedRef<SWidget> BuildRitualDetails();
    TSharedRef<SWidget> BuildJournalDetails();
    TSharedRef<SWidget> BuildHerbalDetails();
    TSharedRef<SWidget> BuildSigilDetails();
    TSharedRef<SWidget> BuildAstroDetails();
    TSharedRef<SWidget> BuildTarotDetails();

    // --------------------------------------------------------
    //  Reusable field widgets
    // --------------------------------------------------------

    // Labelled single-line text input bound to an FString member
    TSharedRef<SWidget> MakeTextField(
        const FText& Label,
        const FString& Value,
        TFunction<void(const FText&)> OnChanged,
        const FText& Hint = FText::GetEmpty());

    // Labelled multiline text input
    TSharedRef<SWidget> MakeMultilineField(
        const FText& Label,
        const FString& Value,
        TFunction<void(const FText&)> OnChanged,
        float HeightPx = 120.f,
        const FText& Hint = FText::GetEmpty());

    // Section header within a tab
    TSharedRef<SWidget> MakeSectionHeader(const FText& Label);

    // Type selector button (shown in top bar)
    TSharedRef<SWidget> BuildTypeButton(EGrimoireEntryType Type, bool bActive);

    // Tab button
    TSharedRef<SWidget> BuildTabButton(const FText& Label, int32 TabIndex, bool bActive);

    // Visibility toggle row
    TSharedRef<SWidget> BuildVisibilityRow();

    // Pin / favourite toggles
    TSharedRef<SWidget> BuildToggleRow();

    // Collection picker dropdown (simple button cycle for now)
    TSharedRef<SWidget> BuildCollectionPicker();

    // --------------------------------------------------------
    //  Logic
    // --------------------------------------------------------

    void LoadEntry(const FString& EntryID);
    void LoadCollections();
    void RefreshTabContent();
    void SwitchTab(int32 TabIndex);
    void SetEntryType(EGrimoireEntryType NewType);

    void SaveEntry();
    void DeleteEntry();
    void MarkDirty();


    static FString FormatTagArray(const TArray<FString>& Tags);
    static TArray<FString> ParseTagString(const FString& Raw);
};
