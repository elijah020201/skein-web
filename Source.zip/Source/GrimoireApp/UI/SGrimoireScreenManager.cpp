#include "SGrimoireScreenManager.h"
#include "SGrimoireBaseWidget.h"
#include "SGrimoireLoginScreen.h"
#include "SGrimoireDashboardScreen.h"
#include "SGrimoireEntriesScreen.h"
#include "SGrimoireEditorScreen.h"
#include "SGrimoireSettingsScreen.h"
#include "GrimoireStyle.h"
#include "Widgets/Layout/SWidgetSwitcher.h"

// ============================================================
//  GRIMOIRE APP — Screen Manager Implementation
//  SGrimoireScreenManager.cpp
// ============================================================

void SGrimoireScreenManager::Construct(const FArguments& InArgs)
{
    GameInstance = InArgs._GameInstance;

    // Build all screens up front and register them in the switcher.
    // This means zero construction cost when navigating — screens
    // are just shown/hidden, not created on demand.
    //
    // For a large app you'd use lazy construction, but for our
    // screen count this is cleaner and avoids flicker on nav.

    TSharedRef<SWidgetSwitcher> SwitcherRef = SNew(SWidgetSwitcher);
    Switcher = SwitcherRef;

    // ── Register screens ──────────────────────────────────
    // The order here defines the widget index.
    // ScreenIndex maps FName → index for O(1) lookup.

    auto AddScreen = [&](FName Name, TSharedRef<SWidget> Widget,
        TSharedPtr<SGrimoireBaseWidget> Base = nullptr)
    {
        int32 Idx = ScreenIndex.Num();
        ScreenIndex.Add(Name, Idx);
        SwitcherRef->AddSlot() [ Widget ];
        if (Base.IsValid())
            ScreenWidgets.Add(Name, Base);
    };

    { auto W = SNew(SGrimoireLoginScreen).GameInstance(GameInstance).OnNavigate(FOnNavigate::CreateSP(this, &SGrimoireScreenManager::HandleNavigation)); LoginScreen = W; AddScreen(FName("Login"), W, W); }
    BuildDashboardScreen(); AddScreen(FName("Dashboard"),  DashboardScreen.ToSharedRef(), DashboardScreen);
    { auto W = SNew(SGrimoireEntriesScreen).GameInstance(GameInstance).OnNavigate(FOnNavigate::CreateSP(this, &SGrimoireScreenManager::HandleNavigation)); AddScreen(FName("Entries"), W, W); }
    BuildEditorScreen(); AddScreen(FName("Editor"),     EditorScreen.ToSharedRef(), EditorScreen);
    AddScreen(FName("Collection"), BuildPlaceholderScreen(FText::FromString(TEXT("Collection"))));
    BuildSettingsScreen(); AddScreen(FName("Settings"),   SettingsScreen.ToSharedRef(), SettingsScreen);

    // ── Decide starting screen ────────────────────────────
    // If the user has a valid saved session, go straight to
    // Dashboard. Otherwise show Login.
    FName StartScreen = FName("Login");
    if (GameInstance && GameInstance->GetAuthService().IsLoggedIn())
        StartScreen = FName("Dashboard");

    NavStack.Add(StartScreen);
    if (const int32* Idx = ScreenIndex.Find(StartScreen))
        SwitcherRef->SetActiveWidgetIndex(*Idx);

    // ── Mount root widget ─────────────────────────────────
    ChildSlot
    [
        SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::BG)
        [ SwitcherRef ]
    ];
}

// --------------------------------------------------------
//  Screen builders
// --------------------------------------------------------

TSharedRef<SWidget> SGrimoireScreenManager::BuildLoginScreen()
{
    return SNew(SGrimoireLoginScreen)
        .GameInstance(GameInstance)
        .OnNavigate(FOnNavigate::CreateSP(
            this, &SGrimoireScreenManager::HandleNavigation));
}

TSharedRef<SWidget> SGrimoireScreenManager::BuildDashboardScreen()
{
    TSharedRef<SGrimoireDashboardScreen> W = SNew(SGrimoireDashboardScreen)
        .GameInstance(GameInstance)
        .OnNavigate(FOnNavigate::CreateSP(
            this, &SGrimoireScreenManager::HandleNavigation));
    DashboardScreen = W;
    return W;
}

TSharedRef<SWidget> SGrimoireScreenManager::BuildSettingsScreen()
{
    TSharedRef<SGrimoireSettingsScreen> W = SNew(SGrimoireSettingsScreen)
        .GameInstance(GameInstance)
        .OnNavigate(FOnNavigate::CreateSP(
            this, &SGrimoireScreenManager::HandleNavigation));
    SettingsScreen = W;
    return W;
}

TSharedRef<SWidget> SGrimoireScreenManager::BuildEditorScreen()
{
    TSharedRef<SGrimoireEditorScreen> W = SNew(SGrimoireEditorScreen)
        .GameInstance(GameInstance)
        .OnNavigate(FOnNavigate::CreateSP(
            this, &SGrimoireScreenManager::HandleNavigation));
    EditorScreen = W;
    return W;
}

void SGrimoireScreenManager::NavigateToEditor(const FString& EntryID, EGrimoireEntryType DefaultType)
{
    NavigateTo(FName("Editor"));
    if (EditorScreen.IsValid())
    {
        if (EntryID.IsEmpty())
        {
            EditorScreen->SetEntryID(TEXT(""));
            EditorScreen->SetInitialType(DefaultType);
        }
        else
        {
            EditorScreen->SetEntryID(EntryID);
            EditorScreen->SetViewMode(true);  // Open existing entries in read-only view
        }
        EditorScreen->RefreshUniversalHeader();
    }
}

TSharedRef<SWidget> SGrimoireScreenManager::BuildEntriesScreen()
{
    return SNew(SGrimoireEntriesScreen)
        .GameInstance(GameInstance)
        .OnNavigate(FOnNavigate::CreateSP(
            this, &SGrimoireScreenManager::HandleNavigation));
}

TSharedRef<SWidget> SGrimoireScreenManager::BuildPlaceholderScreen(const FText& Label)
{
    // Temporary stand-in for screens not yet built.
    // Replace each one as we implement them.
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::BG)
        [
            SNew(SVerticalBox)
            + SVerticalBox::Slot()
            .FillHeight(1.f)
            .VAlign(VAlign_Center)
            .HAlign(HAlign_Center)
            [
                SNew(SVerticalBox)
                + SVerticalBox::Slot()
                .AutoHeight()
                .HAlign(HAlign_Center)
                .Padding(0.f, 0.f, 0.f, 16.f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("✦")))
                    .Font(GrimoireStyle::FontDisplay(32.f))
                    .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
                ]
                + SVerticalBox::Slot()
                .AutoHeight()
                .HAlign(HAlign_Center)
                [
                    SNew(STextBlock)
                    .Text(Label)
                    .Font(GrimoireStyle::FontUI(14.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
                ]
                + SVerticalBox::Slot()
                .AutoHeight()
                .HAlign(HAlign_Center)
                .Padding(0.f, 8.f, 0.f, 0.f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("This page is being written...")))
                    .Font(GrimoireStyle::FontBodyItalic(13.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                ]
                // Back button
                + SVerticalBox::Slot()
                .AutoHeight()
                .HAlign(HAlign_Center)
                .Padding(0.f, 24.f, 0.f, 0.f)
                [
                    SNew(SButton)
                    .ButtonColorAndOpacity(GrimoireStyle::Surface)
                    .OnClicked_Lambda([this]()
                    {
                        NavigateBack();
                        return FReply::Handled();
                    })
                    [
                        SNew(SBox)
                        .Padding(FMargin(24.f, 8.f))
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(TEXT("RETURN")))
                            .Font(GrimoireStyle::FontUI(11.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
                        ]
                    ]
                ]
            ]
        ];
}

// --------------------------------------------------------
//  Navigation
// --------------------------------------------------------

void SGrimoireScreenManager::NavigateTo(FName ScreenName, TSharedPtr<FJsonObject> Context)
{
    if (!Switcher.IsValid()) return;

    const int32* Idx = ScreenIndex.Find(ScreenName);
    if (!Idx)
    {
        UE_LOG(LogTemp, Warning,
            TEXT("ScreenManager: Unknown screen '%s'"), *ScreenName.ToString());
        return;
    }

    UE_LOG(LogTemp, Log,
        TEXT("ScreenManager: Navigating to '%s'"), *ScreenName.ToString());

    NavStack.Add(ScreenName);
    Switcher->SetActiveWidgetIndex(*Idx);

    // Notify the screen it's becoming active
    if (TSharedPtr<SGrimoireBaseWidget>* Widget = ScreenWidgets.Find(ScreenName))
    {
        if (Widget->IsValid())
            (*Widget)->OnScreenActivated();
    }
}

void SGrimoireScreenManager::NavigateBack()
{
    if (NavStack.Num() <= 1) return;

    NavStack.Pop();
    FName PreviousScreen = NavStack.Last();

    if (const int32* Idx = ScreenIndex.Find(PreviousScreen))
        Switcher->SetActiveWidgetIndex(*Idx);
}

void SGrimoireScreenManager::SignOut()
{
    if (LoginScreen.IsValid())
        LoginScreen->RequestReset();
    NavigateTo(FName("Login"));
}

void SGrimoireScreenManager::HandleNavigation(FName ScreenName)
{
    FString NameStr = ScreenName.ToString();

    // Sign out
    if (NameStr == TEXT("SignOut"))
    {
        SignOut();
        return;
    }

    // Support "Editor:entryID" and "Editor:new:TypeIndex" conventions
    if (NameStr.StartsWith(TEXT("Editor:")))
    {
        TArray<FString> Parts;
        NameStr.ParseIntoArray(Parts, TEXT(":"));

        if (Parts.Num() >= 2 && Parts[1] == TEXT("new") && Parts.Num() >= 3)
        {
            // New entry with specific type: "Editor:new:2"
            int32 TypeIdx = FCString::Atoi(*Parts[2]);
            NavigateToEditor(TEXT(""), (EGrimoireEntryType)TypeIdx);
        }
        else if (Parts.Num() >= 2 && Parts[1] != TEXT("new"))
        {
            // Open existing entry: "Editor:some-guid-here"
            NavigateToEditor(Parts[1]);
        }
        else
        {
            // Just "Editor:new"
            NavigateToEditor();
        }
        return;
    }

    NavigateTo(ScreenName);
}
