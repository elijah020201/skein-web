#include "SGrimoireEntriesScreen.h"
#include "GrimoireStyle.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SSpacer.h"
#include "Widgets/Input/SEditableTextBox.h"

// ============================================================
//  GRIMOIRE APP — Entries List Screen
//  SGrimoireEntriesScreen.cpp
// ============================================================

// Sentinel value meaning "no type filter active"
static constexpr uint8 TypeFilter_All = 255;

void SGrimoireEntriesScreen::Construct(const FArguments& InArgs)
{
    SGrimoireBaseWidget::Construct(
        SGrimoireBaseWidget::FArguments()
        .GameInstance(InArgs._GameInstance)
        .OnNavigate(InArgs._OnNavigate));

    LoadEntries();
    ApplyFilters();

    ChildSlot
    [
        SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::BG)
        [
            SNew(SVerticalBox)

            // Top bar
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                BuildTopBar()
            ]

            // Search bar
            + SVerticalBox::Slot()
            .AutoHeight()
            .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadSM,
                     GrimoireStyle::PadMD, 0.f)
            [
                BuildSearchBar()
            ]

            // Filter chips
            + SVerticalBox::Slot()
            .AutoHeight()
            .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadSM,
                     GrimoireStyle::PadMD, 0.f)
            [
                SAssignNew(FilterRowContainer, SBox)
                [ BuildFilterRow() ]
            ]

            // Sort + result count row
            + SVerticalBox::Slot()
            .AutoHeight()
            .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadSM,
                     GrimoireStyle::PadMD, GrimoireStyle::PadSM)
            [
                SAssignNew(SortRowContainer, SBox)
                [ BuildSortRow() ]
            ]

            // 1px separator
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::Border)
                [ SNew(SBox).HeightOverride(1.f) ]
            ]

            // Entry list (fills remaining space)
            + SVerticalBox::Slot()
            .FillHeight(1.f)
            [
                BuildEntryList()
            ]

            // 1px separator
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::Border)
                [ SNew(SBox).HeightOverride(1.f) ]
            ]

            // Bottom nav
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                BuildBottomNav()
            ]
        ]
    ];
}

void SGrimoireEntriesScreen::OnScreenActivated()
{
    LoadEntries();
    ApplyFilters();
    RefreshList();
}

// ============================================================
//  TOP BAR
// ============================================================

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildTopBar()
{
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(FMargin(GrimoireStyle::PadMD, 0.f))
        [
            SNew(SBox)
            .HeightOverride(GrimoireStyle::TopBarHeight)
            [
                SNew(SHorizontalBox)

                // Back arrow
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
                [
                    SNew(SButton)
                    .ButtonStyle(FCoreStyle::Get(), "NoBorder")
                    .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                    .OnClicked_Lambda([this]()
                    {
                        NavigateTo(FName("Dashboard"));
                        return FReply::Handled();
                    })
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("<")))
                        .Font(GrimoireStyle::FontUI(14.f))
                        .ColorAndOpacity(GrimoireStyle::SC_Gold)
                    ]
                ]

                // Title
                + SHorizontalBox::Slot()
                .FillWidth(1.f)
                .VAlign(VAlign_Center)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("ENTRIES")))
                    .Font(GrimoireStyle::FontDisplay(16.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                ]

                // Result count
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                [
                    SAssignNew(ResultCount, STextBlock)
                    .Text(FText::FromString(TEXT("")))
                    .Font(GrimoireStyle::FontUI(9.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                ]
            ]
        ];
}

// ============================================================
//  SEARCH BAR
// ============================================================

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildSearchBar()
{
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface2)
        .Padding(FMargin(GrimoireStyle::PadSM, 0.f))
        [
            SNew(SBox)
            .HeightOverride(GrimoireStyle::InputHeight)
            [
                SNew(SHorizontalBox)

                // Search icon label
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(GrimoireStyle::PadSM, 0.f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("~")))
                    .Font(GrimoireStyle::FontUI(12.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                ]

                // Text input
                + SHorizontalBox::Slot()
                .FillWidth(1.f)
                .VAlign(VAlign_Center)
                [
                    SNew(SEditableTextBox)
                    .HintText(FText::FromString(TEXT("Search by title or tag...")))
                    .BackgroundColor(GrimoireStyle::Transparent)
                    .ForegroundColor(GrimoireStyle::SC_TextPrimary)
                    .Font(GrimoireStyle::FontBody(14.f))
                    .OnTextChanged_Lambda([this](const FText& Text)
                    {
                        SearchText = Text.ToString();
                        ApplyFilters();
                        RefreshList();
                    })
                ]

                // Clear button — only show when text is present
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
                [
                    SNew(SButton)
                    .ButtonStyle(FCoreStyle::Get(), "NoBorder")
                    .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                    .OnClicked_Lambda([this]()
                    {
                        SearchText = TEXT("");
                        ApplyFilters();
                        RefreshList();
                        return FReply::Handled();
                    })
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("x")))
                        .Font(GrimoireStyle::FontUI(9.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                    ]
                ]
            ]
        ];
}

// ============================================================
//  FILTER ROW
// ============================================================

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildFilterRow()
{
    TSharedRef<SScrollBox> Scroll = SNew(SScrollBox)
        .Orientation(Orient_Horizontal)
        .ScrollBarVisibility(EVisibility::Collapsed);

    // "All" chip
    Scroll->AddSlot()
    .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
    [
        BuildFilterChip(
            FText::FromString(TEXT("ALL")),
            (EGrimoireEntryType)TypeFilter_All,
            (uint8)ActiveTypeFilter == TypeFilter_All)
    ];

    // One chip per type
    const TArray<EGrimoireEntryType> Types = {
        EGrimoireEntryType::Spell,
        EGrimoireEntryType::Ritual,
        EGrimoireEntryType::JournalEntry,
        EGrimoireEntryType::TarotLog,
        EGrimoireEntryType::HerbalCorrespondence,
        EGrimoireEntryType::Sigil,
        EGrimoireEntryType::AstrologicalData,
    };

    for (EGrimoireEntryType Type : Types)
    {
        Scroll->AddSlot()
        .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
        [
            BuildFilterChip(
                GrimoireStyle::GetTypeLabel(Type),
                Type,
                ActiveTypeFilter == Type)
        ];
    }

    return Scroll;
}

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildFilterChip(
    const FText& Label,
    EGrimoireEntryType Type,
    bool bActive)
{
    const FLinearColor TypeColor = (uint8)Type == TypeFilter_All
        ? GrimoireStyle::Gold
        : GrimoireStyle::GetTypeColor(Type);

    const FLinearColor BgColor  = bActive
        ? FLinearColor(TypeColor.R * 0.2f, TypeColor.G * 0.2f, TypeColor.B * 0.2f, 1.f)
        : GrimoireStyle::Surface2;

    const FLinearColor TextColor = bActive ? GrimoireStyle::TextPrimary : GrimoireStyle::TextMuted;
    const FLinearColor BorderColor = bActive ? TypeColor : GrimoireStyle::Border;

    return SNew(SButton)
        .ButtonStyle(FCoreStyle::Get(), "NoBorder")
        .ButtonColorAndOpacity(BgColor)
        .OnClicked_Lambda([this, Type]()
        {
            ActiveTypeFilter = Type;
            ApplyFilters();
            RefreshList();
            RefreshFilterRow();
            return FReply::Handled();
        })
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(BorderColor)
            .Padding(FMargin(GrimoireStyle::PadMD, 6.f))
            [
                SNew(STextBlock)
                .Text(Label)
                .Font(GrimoireStyle::FontUI(9.f))
                .ColorAndOpacity(FSlateColor(TextColor))
            ]
        ];
}

// ============================================================
//  SORT ROW
// ============================================================

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildSortRow()
{
    return SNew(SHorizontalBox)

        // Label
        + SHorizontalBox::Slot()
        .AutoWidth()
        .VAlign(VAlign_Center)
        .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
        [
            SNew(STextBlock)
            .Text(FText::FromString(TEXT("SORT")))
            .Font(GrimoireStyle::FontUI(8.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
        ]

        + SHorizontalBox::Slot()
        .AutoWidth()
        .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
        [
            BuildSortButton(FText::FromString(TEXT("DATE")), 0, SortMode == 0)
        ]

        + SHorizontalBox::Slot()
        .AutoWidth()
        .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
        [
            BuildSortButton(FText::FromString(TEXT("NAME")), 1, SortMode == 1)
        ]

        + SHorizontalBox::Slot()
        .AutoWidth()
        [
            BuildSortButton(FText::FromString(TEXT("TYPE")), 2, SortMode == 2)
        ]

        // Spacer
        + SHorizontalBox::Slot()
        .FillWidth(1.f)
        [ SNew(SSpacer) ]

        // Filtered count
        + SHorizontalBox::Slot()
        .AutoWidth()
        .VAlign(VAlign_Center)
        [
            SAssignNew(ResultCount, STextBlock)
            .Text(FText::Format(
                FText::FromString(TEXT("{0} entries")),
                FText::AsNumber(FilteredEntries.Num())))
            .Font(GrimoireStyle::FontUI(8.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
        ]
    ;
}

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildSortButton(
    const FText& Label, int32 Mode, bool bActive)
{
    return SNew(SButton)
        .ButtonStyle(FCoreStyle::Get(), "NoBorder")
        .ButtonColorAndOpacity(GrimoireStyle::Transparent)
        .OnClicked_Lambda([this, Mode]()
        {
            SortMode = Mode;
            ApplyFilters();
            RefreshList();
            RefreshSortRow();
            return FReply::Handled();
        })
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(bActive ? GrimoireStyle::GoldFaint : GrimoireStyle::Transparent)
            .Padding(FMargin(GrimoireStyle::PadSM, 3.f))
            [
                SNew(STextBlock)
                .Text(Label)
                .Font(GrimoireStyle::FontUI(8.f))
                .ColorAndOpacity(bActive
                    ? GrimoireStyle::SC_Gold
                    : GrimoireStyle::SC_TextFaint)
            ]
        ];
}

// ============================================================
//  ENTRY LIST
// ============================================================

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildEntryList()
{
    return SNew(SScrollBox)
        .ScrollBarVisibility(EVisibility::Collapsed)
        + SScrollBox::Slot()
        [
            SAssignNew(EntryList, SVerticalBox)
        ];
}

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildEntryCard(const FGrimoireEntry& Entry)
{
    const FLinearColor TypeColor = GrimoireStyle::GetTypeColor(Entry.EntryType);
    const FString DateStr = FormatDate(Entry.UpdatedAt.IsEmpty()
        ? Entry.CreatedAt : Entry.UpdatedAt);

    // Preview snippet — pick the first meaningful body text by type
    FString Preview;
    switch (Entry.EntryType)
    {
        case EGrimoireEntryType::Spell:
            Preview = Entry.SpellData.Intent; break;
        case EGrimoireEntryType::Ritual:
            Preview = Entry.RitualData.Purpose; break;
        case EGrimoireEntryType::JournalEntry:
            Preview = Entry.JournalData.ReflectionBody; break;
        case EGrimoireEntryType::HerbalCorrespondence:
            Preview = Entry.HerbalData.UsageNotes; break;
        case EGrimoireEntryType::TarotLog:
            Preview = Entry.TarotData.OverallInterpretation; break;
        default:
            Preview = TEXT(""); break;
    }
    if (Preview.Len() > 80)
        Preview = Preview.Left(80) + TEXT("...");

    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(FMargin(0.f))
        [
            SNew(SButton)
            .ButtonStyle(FCoreStyle::Get(), "NoBorder")
            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
            .OnClicked_Lambda([this, Entry]()
            {
                NavigateTo(FName(*FString::Printf(TEXT("Editor:%s"), *Entry.EntityID)));
                return FReply::Handled();
            })
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::Border)
                .Padding(FMargin(0.f, 0.f, 0.f, GrimoireStyle::BorderPx))
                [
                    SNew(SHorizontalBox)

                    // 3px type accent bar on left
                    + SHorizontalBox::Slot()
                    .AutoWidth()
                    [
                        SNew(SBorder)
                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                        .BorderBackgroundColor(TypeColor)
                        [ SNew(SBox).WidthOverride(GrimoireStyle::AccentBarW) ]
                    ]

                    // Content
                    + SHorizontalBox::Slot()
                    .FillWidth(1.f)
                    .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadSM)
                    [
                        SNew(SVerticalBox)

                        // Row 1: type badge + title
                        + SVerticalBox::Slot()
                        .AutoHeight()
                        .Padding(0.f, 0.f, 0.f, 3.f)
                        [
                            SNew(SHorizontalBox)

                            // Type label
                            + SHorizontalBox::Slot()
                            .AutoWidth()
                            .VAlign(VAlign_Center)
                            .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
                            [
                                SNew(SBorder)
                                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                                .BorderBackgroundColor(FLinearColor(
                                    TypeColor.R * 0.15f,
                                    TypeColor.G * 0.15f,
                                    TypeColor.B * 0.15f, 1.f))
                                .Padding(FMargin(5.f, 2.f))
                                [
                                    SNew(STextBlock)
                                    .Text(GrimoireStyle::GetTypeLabel(Entry.EntryType))
                                    .Font(GrimoireStyle::FontUI(7.f))
                                    .ColorAndOpacity(FSlateColor(TypeColor))
                                ]
                            ]

                            // Pinned indicator
                            + SHorizontalBox::Slot()
                            .AutoWidth()
                            .VAlign(VAlign_Center)
                            .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
                            [
                                SNew(STextBlock)
                                .Text(FText::FromString(TEXT("*")))
                                .Font(GrimoireStyle::FontUI(9.f))
                                .ColorAndOpacity(GrimoireStyle::SC_Gold)
                                .Visibility(Entry.bIsPinned
                                    ? EVisibility::Visible
                                    : EVisibility::Collapsed)
                            ]
                        ]

                        // Row 2: Title
                        + SVerticalBox::Slot()
                        .AutoHeight()
                        .Padding(0.f, 0.f, 0.f, 4.f)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(
                                Entry.Title.IsEmpty()
                                    ? TEXT("Untitled")
                                    : Entry.Title))
                            .Font(GrimoireStyle::FontBodyMedium(15.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                        ]

                        // Row 3: Preview snippet
                        + SVerticalBox::Slot()
                        .AutoHeight()
                        .Padding(0.f, 0.f, 0.f, 5.f)
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(
                                Preview.IsEmpty()
                                    ? TEXT("No content yet.")
                                    : Preview))
                            .Font(GrimoireStyle::FontBodyItalic(12.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                            .AutoWrapText(true)
                        ]

                        // Row 4: Date + tags
                        + SVerticalBox::Slot()
                        .AutoHeight()
                        [
                            SNew(SHorizontalBox)

                            + SHorizontalBox::Slot()
                            .AutoWidth()
                            .VAlign(VAlign_Center)
                            [
                                SNew(STextBlock)
                                .Text(FText::FromString(DateStr))
                                .Font(GrimoireStyle::FontUI(8.f))
                                .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                            ]

                            // Tags (up to 3)
                            + SHorizontalBox::Slot()
                            .FillWidth(1.f)
                            .VAlign(VAlign_Center)
                            .Padding(GrimoireStyle::PadSM, 0.f, 0.f, 0.f)
                            [
                                SNew(STextBlock)
                                .Text(FText::FromString(
                                    Entry.Tags.Num() > 0
                                        ? FString::Join(
                                            TArray<FString>(
                                                Entry.Tags.GetData(),
                                                FMath::Min(Entry.Tags.Num(), 3)),
                                            TEXT("  "))
                                        : TEXT("")))
                                .Font(GrimoireStyle::FontUI(7.f))
                                .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
                            ]
                        ]
                    ]

                    // Right arrow hint
                    + SHorizontalBox::Slot()
                    .AutoWidth()
                    .VAlign(VAlign_Center)
                    .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT(">")))
                        .Font(GrimoireStyle::FontUI(10.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                    ]
                ]
            ]
        ];
}

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildEmptyState()
{
    FString Message = SearchText.IsEmpty() && (uint8)ActiveTypeFilter == TypeFilter_All
        ? TEXT("Your tome awaits its first inscription.")
        : TEXT("No entries match your search.");

    return SNew(SVerticalBox)
        + SVerticalBox::Slot()
        .FillHeight(1.f)
        .VAlign(VAlign_Center)
        .HAlign(HAlign_Center)
        [
            SNew(SVerticalBox)

            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
            [
                SNew(STextBlock)
                .Text(FText::FromString(TEXT("- o -")))
                .Font(GrimoireStyle::FontDisplay(24.f))
                .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
            ]

            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            [
                SNew(STextBlock)
                .Text(FText::FromString(Message))
                .Font(GrimoireStyle::FontBodyItalic(14.f))
                .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
            ]

            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            .Padding(0.f, GrimoireStyle::PadXL, 0.f, 0.f)
            [
                SNew(SButton)
                .ButtonColorAndOpacity(GrimoireStyle::Red)
                .OnClicked_Lambda([this]()
                {
                    NavigateTo(FName("Editor:new"));
                    return FReply::Handled();
                })
                [
                    SNew(SBox)
                    .Padding(FMargin(GrimoireStyle::PadXL, GrimoireStyle::PadSM))
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("CREATE FIRST ENTRY")))
                        .Font(GrimoireStyle::FontUI(11.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                    ]
                ]
            ]
        ];
}

// ============================================================
//  FAB
// ============================================================

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildFAB()
{
    return SNew(SOverlay)

        + SOverlay::Slot()
        .HAlign(HAlign_Right)
        .VAlign(VAlign_Bottom)
        .Padding(GrimoireStyle::PadXL, 0.f, GrimoireStyle::PadXL,
                 GrimoireStyle::BottomNavHeight + GrimoireStyle::PadXL)
        [
            SNew(SBox)
            .WidthOverride(GrimoireStyle::FABSize)
            .HeightOverride(GrimoireStyle::FABSize)
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::Gold)
                .Padding(1.f)
                [
                    SNew(SButton)
                    .ButtonColorAndOpacity(GrimoireStyle::Red)
                    .HAlign(HAlign_Center)
                    .VAlign(VAlign_Center)
                    .OnClicked_Lambda([this]()
                    {
                        NavigateTo(FName("Editor:new"));
                        return FReply::Handled();
                    })
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("+")))
                        .Font(GrimoireStyle::FontDisplay(22.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                    ]
                ]
            ]
        ];
}

// ============================================================
//  BOTTOM NAV
// ============================================================

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildBottomNav()
{
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(FMargin(0.f))
        [
            SNew(SBox)
            .HeightOverride(GrimoireStyle::BottomNavHeight)
            [
                SNew(SHorizontalBox)
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("T")),
                    FText::FromString(TEXT("TOME")),
                    FName("Dashboard")) ]
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("E")),
                    FText::FromString(TEXT("ENTRIES")),
                    FName("Entries"), true) ]
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("C")),
                    FText::FromString(TEXT("COLLECT")),
                    FName("Collection")) ]
                + SHorizontalBox::Slot().FillWidth(1.f)
                [ BuildNavItem(FText::FromString(TEXT("P")),
                    FText::FromString(TEXT("PROFILE")),
                    FName("Settings")) ]
            ]
        ];
}

TSharedRef<SWidget> SGrimoireEntriesScreen::BuildNavItem(
    const FText& Glyph, const FText& Label, FName TargetScreen, bool bActive)
{
    return SNew(SButton)
        .ButtonStyle(FCoreStyle::Get(), "NoBorder")
        .ButtonColorAndOpacity(GrimoireStyle::Transparent)
        .HAlign(HAlign_Center)
        .VAlign(VAlign_Center)
        .OnClicked_Lambda([this, TargetScreen]()
        {
            NavigateTo(TargetScreen);
            return FReply::Handled();
        })
        [
            SNew(SVerticalBox)

            // Active dot
            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            .Padding(0.f, 6.f, 0.f, 2.f)
            [
                SNew(SBox)
                .WidthOverride(4.f)
                .HeightOverride(4.f)
                [
                    SNew(SBorder)
                    .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                    .BorderBackgroundColor(bActive
                        ? GrimoireStyle::Gold
                        : GrimoireStyle::Transparent)
                ]
            ]

            // Glyph
            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            [
                SNew(STextBlock)
                .Text(Glyph)
                .Font(GrimoireStyle::FontUI(14.f))
                .ColorAndOpacity(bActive
                    ? GrimoireStyle::SC_Gold
                    : GrimoireStyle::SC_TextFaint)
            ]

            // Label
            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            .Padding(0.f, 2.f, 0.f, 6.f)
            [
                SNew(STextBlock)
                .Text(Label)
                .Font(GrimoireStyle::FontUI(7.f))
                .ColorAndOpacity(bActive
                    ? GrimoireStyle::SC_Gold
                    : GrimoireStyle::SC_TextFaint)
            ]
        ];
}

// ============================================================
//  DATA & FILTERING
// ============================================================

void SGrimoireEntriesScreen::LoadEntries()
{
    AllEntries.Empty();

    if (FGrimoireLocalStore* S = Store())
    {
        S->LoadAllEntries(AllEntries);
        // Remove deleted entries
        AllEntries.RemoveAll([](const FGrimoireEntry& E)
        {
            return E.bIsDeleted;
        });
    }
}

void SGrimoireEntriesScreen::ApplyFilters()
{
    FilteredEntries = AllEntries.FilterByPredicate([this](const FGrimoireEntry& E)
    {
        return PassesTypeFilter(E) && PassesSearchFilter(E);
    });

    // Sort
    switch (SortMode)
    {
        case 1: // Name
            FilteredEntries.Sort([](const FGrimoireEntry& A, const FGrimoireEntry& B)
            {
                return A.Title < B.Title;
            });
            break;
        case 2: // Type
            FilteredEntries.Sort([](const FGrimoireEntry& A, const FGrimoireEntry& B)
            {
                return (uint8)A.EntryType < (uint8)B.EntryType;
            });
            break;
        default: // Date (newest first)
            FilteredEntries.Sort([](const FGrimoireEntry& A, const FGrimoireEntry& B)
            {
                const FString& DA = A.UpdatedAt.IsEmpty() ? A.CreatedAt : A.UpdatedAt;
                const FString& DB = B.UpdatedAt.IsEmpty() ? B.CreatedAt : B.UpdatedAt;
                return DA > DB;
            });
            break;
    }

    // Pinned entries always float to top
    FilteredEntries.StableSort([](const FGrimoireEntry& A, const FGrimoireEntry& B)
    {
        return A.bIsPinned && !B.bIsPinned;
    });
}

bool SGrimoireEntriesScreen::PassesTypeFilter(const FGrimoireEntry& E) const
{
    return (uint8)ActiveTypeFilter == TypeFilter_All
        || E.EntryType == ActiveTypeFilter;
}

bool SGrimoireEntriesScreen::PassesSearchFilter(const FGrimoireEntry& E) const
{
    if (SearchText.IsEmpty()) return true;

    const FString Lower = SearchText.ToLower();

    if (E.Title.ToLower().Contains(Lower)) return true;

    for (const FString& EntryTag : E.Tags)
        if (EntryTag.ToLower().Contains(Lower)) return true;

    return false;
}

void SGrimoireEntriesScreen::RefreshList()
{
    if (!EntryList.IsValid()) return;

    EntryList->ClearChildren();

    if (FilteredEntries.Num() == 0)
    {
        EntryList->AddSlot()
        .FillHeight(1.f)
        [ BuildEmptyState() ];
    }
    else
    {
        for (const FGrimoireEntry& Entry : FilteredEntries)
        {
            EntryList->AddSlot()
            .AutoHeight()
            [ BuildEntryCard(Entry) ];
        }
    }

    // Update result count
    if (ResultCount.IsValid())
    {
        ResultCount->SetText(FText::Format(
            FText::FromString(TEXT("{0} entries")),
            FText::AsNumber(FilteredEntries.Num())));
    }
}

void SGrimoireEntriesScreen::RefreshFilterRow()
{
    if (FilterRowContainer.IsValid())
        FilterRowContainer->SetContent(BuildFilterRow());
}

void SGrimoireEntriesScreen::RefreshSortRow()
{
    if (SortRowContainer.IsValid())
        SortRowContainer->SetContent(BuildSortRow());
}

FString SGrimoireEntriesScreen::FormatDate(const FString& ISO)
{
    if (ISO.IsEmpty()) return TEXT("—");

    // ISO format: "2026-02-19T12:34:56Z"
    // Extract just the date portion "Feb 19"
    if (ISO.Len() >= 10)
    {
        const FString Year  = ISO.Mid(0, 4);
        const FString Month = ISO.Mid(5, 2);
        const FString Day   = ISO.Mid(8, 2);

        static const TCHAR* Months[] = {
            TEXT("Jan"), TEXT("Feb"), TEXT("Mar"), TEXT("Apr"),
            TEXT("May"), TEXT("Jun"), TEXT("Jul"), TEXT("Aug"),
            TEXT("Sep"), TEXT("Oct"), TEXT("Nov"), TEXT("Dec")
        };

        int32 M = FCString::Atoi(*Month) - 1;
        if (M >= 0 && M < 12)
            return FString::Printf(TEXT("%s %s"), Months[M], *Day);
    }
    return ISO.Left(10);
}
