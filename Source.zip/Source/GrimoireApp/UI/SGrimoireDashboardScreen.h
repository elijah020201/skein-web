#pragma once

#include "CoreMinimal.h"
#include "SGrimoireBaseWidget.h"
#include "../Core/DataModel/GrimoireEntry.h"

// ============================================================
//  GRIMOIRE APP — Dashboard Screen
//  SGrimoireDashboardScreen.h
//
//  The main home screen. Shows:
//    - Top bar (wordmark, sync status, search, settings)
//    - Moon phase banner with current lunar data
//    - Quick-add entry type strip
//    - Collections horizontal scroll
//    - Recent entries feed
//    - Floating action button
//    - Bottom navigation bar
// ============================================================

class GRIMOIREAPP_API SGrimoireDashboardScreen : public SGrimoireBaseWidget
{
public:
    SLATE_BEGIN_ARGS(SGrimoireDashboardScreen) {}
        SLATE_ARGUMENT(UGrimoireGameInstance*, GameInstance)
        SLATE_EVENT(FOnNavigate, OnNavigate)
    SLATE_END_ARGS()

    void Construct(const FArguments& InArgs);

    // Called when the screen becomes active — refreshes data
    void OnScreenActivated();

private:

    // --------------------------------------------------------
    //  State
    // --------------------------------------------------------

    TArray<FGrimoireEntry> RecentEntries;
    TArray<FGrimoireCollection> Collections;
    bool bSynced = true;

    // Live widgets we need to update
    TSharedPtr<SVerticalBox>   EntryList;
    TSharedPtr<SHorizontalBox> CollectionList;
    TSharedPtr<STextBlock>     SyncStatusText;
    TSharedPtr<SBox>           UpdateBannerContainer;
    TSharedPtr<STextBlock>     UpdateBannerText;

    // --------------------------------------------------------
    //  Section builders
    // --------------------------------------------------------

    TSharedRef<SWidget> BuildTopBar();
    TSharedRef<SWidget> BuildMoonBanner();
    TSharedRef<SWidget> BuildQuickAddSection();
    TSharedRef<SWidget> BuildQuickAddStrip();
    TSharedRef<SWidget> BuildCollectionsSection();
    TSharedRef<SWidget> BuildRecentEntriesSection();
    TSharedRef<SWidget> BuildFAB();
    TSharedRef<SWidget> BuildBottomNav();

    // ── Entry card ──
    TSharedRef<SWidget> BuildEntryCard(const FGrimoireEntry& Entry);

    // ── Collection card ──
    TSharedRef<SWidget> BuildCollectionCard(const FGrimoireCollection& Collection);

    // ── Nav item ──
    TSharedRef<SWidget> BuildNavItem(
        const FText& Icon,
        const FText& Label,
        FName TargetScreen,
        bool bIsActive = false);

    // --------------------------------------------------------
    //  Data loading
    // --------------------------------------------------------

    void LoadRecentEntries();
    void LoadCollections();
    void RefreshEntryList();
    void RefreshCollectionList();

    // --------------------------------------------------------
    //  Lunar calculation
    // --------------------------------------------------------

    struct FMoonPhaseInfo
    {
        FText PhaseName;
        FText PhaseGlyph;
        FText Description;
        float EnergyLevel; // 0–1
        FText EnergyLabel;
    };

    static FMoonPhaseInfo CalculateMoonPhase();
};
