#include "SGrimoireEditorScreen.h"
#include "GrimoireStyle.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SSpacer.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SMultiLineEditableTextBox.h"
#include "Misc/Guid.h"

// ============================================================
//  GRIMOIRE APP — Entry Editor Screen
//  SGrimoireEditorScreen.cpp
// ============================================================

void SGrimoireEditorScreen::Construct(const FArguments& InArgs)
{
    SGrimoireBaseWidget::Construct(
        SGrimoireBaseWidget::FArguments()
        .GameInstance(InArgs._GameInstance)
        .OnNavigate(InArgs._OnNavigate));

    // Default new entry
    WorkingEntry.EntityID  = FGuid::NewGuid().ToString(EGuidFormats::DigitsWithHyphens);
    WorkingEntry.EntryType = EGrimoireEntryType::JournalEntry;
    WorkingEntry.Visibility = EEntryVisibility::Private;
    bIsNewEntry = true;

    LoadCollections();

    ChildSlot
    [
        SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::BG)
        [
            SNew(SVerticalBox)

            // Top bar
            + SVerticalBox::Slot()
            .AutoHeight()
            [ BuildTopBar() ]

            // Universal header (title, tags, etc.)
            + SVerticalBox::Slot()
            .AutoHeight()
            .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadSM,
                     GrimoireStyle::PadMD, 0.f)
            [ BuildUniversalHeader() ]

            // Hairline
            + SVerticalBox::Slot()
            .AutoHeight()
            .Padding(0.f, GrimoireStyle::PadSM, 0.f, 0.f)
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::Border)
                [ SNew(SBox).HeightOverride(1.f) ]
            ]

            // Tab bar
            + SVerticalBox::Slot()
            .AutoHeight()
            [ SAssignNew(TabBarContainer, SBox)[ BuildTabBar() ] ]

            // Hairline
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(GrimoireStyle::Border)
                [ SNew(SBox).HeightOverride(1.f) ]
            ]

            // Tab content (scrollable, fills space)
            + SVerticalBox::Slot()
            .FillHeight(1.f)
            [
                SNew(SScrollBox)
                .ScrollBarVisibility(EVisibility::Collapsed)
                + SScrollBox::Slot()
                .Padding(GrimoireStyle::PadMD)
                [
                    SAssignNew(TabContent, SVerticalBox)
                ]
            ]

            // Bottom actions
            + SVerticalBox::Slot()
            .AutoHeight()
            [ SAssignNew(ActionBarContainer, SBox)[ BuildActionBar() ] ]
        ]
    ];

    RefreshTabContent();
}

void SGrimoireEditorScreen::SetEntryID(const FString& InEntryID)
{
    if (InEntryID.IsEmpty())
    {
        WorkingEntry = FGrimoireEntry();
        WorkingEntry.EntityID = FGuid::NewGuid().ToString(EGuidFormats::DigitsWithHyphens);
        WorkingEntry.EntryType = EGrimoireEntryType::JournalEntry;
        WorkingEntry.Visibility = EEntryVisibility::Private;
        bIsNewEntry = true;
        bViewMode   = false;
    }
    else
    {
        LoadEntry(InEntryID);
        bIsNewEntry = false;
    }
    bDirty = false;
    RefreshTabContent();
    RefreshActionBar();
}

void SGrimoireEditorScreen::SetInitialType(EGrimoireEntryType InType)
{
    WorkingEntry.EntryType = InType;
    RefreshTabContent();
}

// ============================================================
//  TOP BAR
// ============================================================

TSharedRef<SWidget> SGrimoireEditorScreen::BuildTopBar()
{
    // Type color accent
    const FLinearColor TypeColor = GrimoireStyle::GetTypeColor(WorkingEntry.EntryType);

    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(FMargin(GrimoireStyle::PadMD, 0.f))
        [
            SNew(SBox)
            .HeightOverride(GrimoireStyle::TopBarHeight)
            [
                SNew(SHorizontalBox)

                // Back
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
                [
                    SNew(SButton)
                    .ButtonStyle(FCoreStyle::Get(), "NoBorder")
                    .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                    .OnClicked_Lambda([this]()
                    {
                        NavigateTo(FName("Entries"));
                        return FReply::Handled();
                    })
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("<")))
                        .Font(GrimoireStyle::FontUI(14.f))
                        .ColorAndOpacity(GrimoireStyle::SC_Gold)
                    ]
                ]

                // Title: NEW ENTRY or entry type name
                + SHorizontalBox::Slot()
                .FillWidth(1.f)
                .VAlign(VAlign_Center)
                [
                    SNew(SVerticalBox)
                    + SVerticalBox::Slot()
                    .AutoHeight()
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(
                            bIsNewEntry ? TEXT("NEW ENTRY") : TEXT("EDIT ENTRY")))
                        .Font(GrimoireStyle::FontDisplay(15.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                    ]
                    + SVerticalBox::Slot()
                    .AutoHeight()
                    [
                        SNew(STextBlock)
                        .Text(GrimoireStyle::GetTypeLabel(WorkingEntry.EntryType))
                        .Font(GrimoireStyle::FontUI(8.f))
                        .ColorAndOpacity(FSlateColor(TypeColor))
                    ]
                ]

                // Save status
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
                [
                    SAssignNew(SaveStatusText, STextBlock)
                    .Text(FText::GetEmpty())
                    .Font(GrimoireStyle::FontUI(10.f))
                    .ColorAndOpacity(GrimoireStyle::SC_Gold)
                ]

                // Save button
                + SHorizontalBox::Slot()
                .AutoWidth()
                .VAlign(VAlign_Center)
                [
                    SNew(SButton)
                    .ButtonColorAndOpacity(GrimoireStyle::Red)
                    .OnClicked_Lambda([this]()
                    {
                        SaveEntry();
                        return FReply::Handled();
                    })
                    [
                        SNew(SBox)
                        .Padding(FMargin(GrimoireStyle::PadMD, 6.f))
                        [
                            SNew(STextBlock)
                            .Text(FText::FromString(TEXT("SAVE")))
                            .Font(GrimoireStyle::FontUI(10.f))
                            .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                        ]
                    ]
                ]
            ]
        ];
}

// ============================================================
//  UNIVERSAL HEADER
// ============================================================

TSharedRef<SWidget> SGrimoireEditorScreen::BuildUniversalHeader()
{
    return SNew(SVerticalBox)

        // ── Type selector row ──
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [
            SAssignNew(TypeSelectorContainer, SBox)
            [
            SNew(SScrollBox)
            .Orientation(Orient_Horizontal)
            .ScrollBarVisibility(EVisibility::Collapsed)

            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::Spell,
                WorkingEntry.EntryType == EGrimoireEntryType::Spell) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::Ritual,
                WorkingEntry.EntryType == EGrimoireEntryType::Ritual) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::JournalEntry,
                WorkingEntry.EntryType == EGrimoireEntryType::JournalEntry) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::TarotLog,
                WorkingEntry.EntryType == EGrimoireEntryType::TarotLog) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::HerbalCorrespondence,
                WorkingEntry.EntryType == EGrimoireEntryType::HerbalCorrespondence) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::Sigil,
                WorkingEntry.EntryType == EGrimoireEntryType::Sigil) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::AstrologicalData,
                WorkingEntry.EntryType == EGrimoireEntryType::AstrologicalData) ]
        ] // SScrollBox
        ] // TypeSelectorContainer

        // ── Title ──
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [
            MakeTextField(
                FText::FromString(TEXT("TITLE")),
                WorkingEntry.Title,
                [this](const FText& T)
                {
                    WorkingEntry.Title = T.ToString();
                    MarkDirty();
                },
                FText::FromString(TEXT("Name this entry...")))
        ]

        // ── Tags ──
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [
            MakeTextField(
                FText::FromString(TEXT("TAGS")),
                FormatTagArray(WorkingEntry.Tags),
                [this](const FText& T)
                {
                    WorkingEntry.Tags = ParseTagString(T.ToString());
                    MarkDirty();
                },
                FText::FromString(TEXT("moon, protection, fire  (comma separated)")))
        ]

        // ── Pin / Favourite + Visibility + Collection ──
        + SVerticalBox::Slot()
        .AutoHeight()
        [
            SAssignNew(ToggleRowContainer, SBox)
            [
                SNew(SHorizontalBox)

                + SHorizontalBox::Slot()
                .FillWidth(1.f)
                [ BuildToggleRow() ]

                + SHorizontalBox::Slot()
                .AutoWidth()
                .Padding(GrimoireStyle::PadMD, 0.f, 0.f, 0.f)
                [ BuildVisibilityRow() ]
            ]
        ]

        // ── Collection picker ──
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, GrimoireStyle::PadSM, 0.f, 0.f)
        [
            SAssignNew(CollectionPickerContainer, SBox)
            [ BuildCollectionPicker() ]
        ]
    ;
}

// ============================================================
//  TAB BAR
// ============================================================

TSharedRef<SWidget> SGrimoireEditorScreen::BuildTabBar()
{
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(FMargin(GrimoireStyle::PadMD, 0.f))
        [
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot().AutoWidth()
            [ BuildTabButton(FText::FromString(TEXT("DETAILS")), 0, ActiveTab == 0) ]
            + SHorizontalBox::Slot().AutoWidth()
            [ BuildTabButton(FText::FromString(TEXT("NOTES")),   1, ActiveTab == 1) ]
            + SHorizontalBox::Slot().AutoWidth()
            [ BuildTabButton(FText::FromString(TEXT("ASSETS")),  2, ActiveTab == 2) ]
        ];
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildTabButton(
    const FText& Label, int32 TabIndex, bool bActive)
{
    return SNew(SButton)
        .ButtonStyle(FCoreStyle::Get(), "NoBorder")
        .ButtonColorAndOpacity(GrimoireStyle::Transparent)
        .OnClicked_Lambda([this, TabIndex]()
        {
            SwitchTab(TabIndex);
            return FReply::Handled();
        })
        [
            SNew(SBox)
            .Padding(FMargin(GrimoireStyle::PadMD, 12.f, GrimoireStyle::PadMD, 0.f))
            [
                SNew(SVerticalBox)
                + SVerticalBox::Slot()
                .AutoHeight()
                [
                    SNew(STextBlock)
                    .Text(Label)
                    .Font(GrimoireStyle::FontUI(9.f))
                    .ColorAndOpacity(bActive
                        ? GrimoireStyle::SC_Gold
                        : GrimoireStyle::SC_TextFaint)
                ]
                // Active underline
                + SVerticalBox::Slot()
                .AutoHeight()
                .Padding(0.f, 4.f, 0.f, 0.f)
                [
                    SNew(SBox)
                    .HeightOverride(2.f)
                    [
                        SNew(SBorder)
                        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                        .BorderBackgroundColor(bActive
                            ? GrimoireStyle::Gold
                            : GrimoireStyle::Transparent)
                    ]
                ]
            ]
        ];
}

// ============================================================
//  TAB CONTENT
// ============================================================

TSharedRef<SWidget> SGrimoireEditorScreen::BuildTabContent()
{
    switch (ActiveTab)
    {
        case 1:  return BuildNotesTab();
        case 2:  return BuildAssetsTab();
        default: return BuildDetailsTab();
    }
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildDetailsTab()
{
    switch (WorkingEntry.EntryType)
    {
        case EGrimoireEntryType::Spell:               return BuildSpellDetails();
        case EGrimoireEntryType::Ritual:              return BuildRitualDetails();
        case EGrimoireEntryType::JournalEntry:        return BuildJournalDetails();
        case EGrimoireEntryType::HerbalCorrespondence:return BuildHerbalDetails();
        case EGrimoireEntryType::Sigil:               return BuildSigilDetails();
        case EGrimoireEntryType::AstrologicalData:    return BuildAstroDetails();
        case EGrimoireEntryType::TarotLog:            return BuildTarotDetails();
        default:
            return SNew(STextBlock)
                .Text(FText::FromString(TEXT("No fields for this type yet.")))
                .Font(GrimoireStyle::FontBodyItalic(13.f))
                .ColorAndOpacity(GrimoireStyle::SC_TextFaint);
    }
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildNotesTab()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("PERSONAL NOTES"))) ]

        + SVerticalBox::Slot()
        .AutoHeight()
        [
            MakeMultilineField(
                FText::FromString(TEXT("REFLECTION")),
                WorkingEntry.JournalData.ReflectionBody,
                [this](const FText& T)
                {
                    WorkingEntry.JournalData.ReflectionBody = T.ToString();
                    MarkDirty();
                },
                200.f,
                FText::FromString(TEXT("Observations, reflections, what you noticed...")))
        ]

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, GrimoireStyle::PadMD, 0.f, 0.f)
        [
            MakeMultilineField(
                FText::FromString(TEXT("OUTCOME / RESULTS")),
                [this]() -> FString {
                    switch(WorkingEntry.EntryType) {
                        case EGrimoireEntryType::Spell:   return WorkingEntry.SpellData.ResultsNotes;
                        case EGrimoireEntryType::Ritual:  return WorkingEntry.RitualData.Outcome;
                        case EGrimoireEntryType::Sigil:   return WorkingEntry.SigilData.Outcome;
                        case EGrimoireEntryType::TarotLog:return WorkingEntry.TarotData.Outcome;
                        default:                           return WorkingEntry.SpellData.ResultsNotes;
                    }
                }(),
                [this](const FText& T){
                    switch(WorkingEntry.EntryType) {
                        case EGrimoireEntryType::Spell:    WorkingEntry.SpellData.ResultsNotes = T.ToString(); break;
                        case EGrimoireEntryType::Ritual:   WorkingEntry.RitualData.Outcome     = T.ToString(); break;
                        case EGrimoireEntryType::Sigil:    WorkingEntry.SigilData.Outcome      = T.ToString(); break;
                        case EGrimoireEntryType::TarotLog: WorkingEntry.TarotData.Outcome      = T.ToString(); break;
                        default:                            WorkingEntry.SpellData.ResultsNotes = T.ToString(); break;
                    }
                    MarkDirty();
                },
                120.f,
                FText::FromString(TEXT("What happened after...")))
        ]
    ;
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildAssetsTab()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("ATTACHED ASSETS"))) ]

        + SVerticalBox::Slot()
        .AutoHeight()
        .HAlign(HAlign_Center)
        .Padding(0.f, GrimoireStyle::PadXL)
        [
            SNew(SVerticalBox)
            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
            [
                SNew(STextBlock)
                .Text(FText::FromString(TEXT("[ ]")))
                .Font(GrimoireStyle::FontDisplay(28.f))
                .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
            ]
            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            [
                SNew(STextBlock)
                .Text(FText::FromString(
                    TEXT("Image & document attachments\ncoming in a future update.")))
                .Font(GrimoireStyle::FontBodyItalic(13.f))
                .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                .Justification(ETextJustify::Center)
            ]
        ]
    ;
}

// ============================================================
//  TYPE-SPECIFIC DETAIL TABS
// ============================================================

TSharedRef<SWidget> SGrimoireEditorScreen::BuildSpellDetails()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("WORKING"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("INTENT")),
            WorkingEntry.SpellData.Intent,
            [this](const FText& T){ WorkingEntry.SpellData.Intent = T.ToString(); MarkDirty(); },
            80.f, FText::FromString(TEXT("What does this spell intend to achieve?"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("INSTRUCTIONS")),
            WorkingEntry.SpellData.Instructions,
            [this](const FText& T){ WorkingEntry.SpellData.Instructions = T.ToString(); MarkDirty(); },
            160.f, FText::FromString(TEXT("Step by step..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("INCANTATION")),
            WorkingEntry.SpellData.Incantation,
            [this](const FText& T){ WorkingEntry.SpellData.Incantation = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("Words of power..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadSM)
        [ MakeSectionHeader(FText::FromString(TEXT("TIMING & CORRESPONDENCES"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("BEST MOON PHASE")),
            [this]() -> FString {
                switch(WorkingEntry.SpellData.BestMoonPhase) {
                    case EMoonPhase::New:            return TEXT("New Moon");
                    case EMoonPhase::WaxingCrescent: return TEXT("Waxing Crescent");
                    case EMoonPhase::FirstQuarter:   return TEXT("First Quarter");
                    case EMoonPhase::WaxingGibbous:  return TEXT("Waxing Gibbous");
                    case EMoonPhase::Full:            return TEXT("Full Moon");
                    case EMoonPhase::WaningGibbous:  return TEXT("Waning Gibbous");
                    case EMoonPhase::LastQuarter:    return TEXT("Last Quarter");
                    case EMoonPhase::WaningCrescent: return TEXT("Waning Crescent");
                    default:                          return TEXT("");
                }
            }(),
            [this](const FText& T){
                FString V = T.ToString().TrimStartAndEnd();
                if      (V.Equals(TEXT("New Moon"),        ESearchCase::IgnoreCase)) WorkingEntry.SpellData.BestMoonPhase = EMoonPhase::New;
                else if (V.Equals(TEXT("Waxing Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.SpellData.BestMoonPhase = EMoonPhase::WaxingCrescent;
                else if (V.Equals(TEXT("First Quarter"),   ESearchCase::IgnoreCase)) WorkingEntry.SpellData.BestMoonPhase = EMoonPhase::FirstQuarter;
                else if (V.Equals(TEXT("Waxing Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.SpellData.BestMoonPhase = EMoonPhase::WaxingGibbous;
                else if (V.Equals(TEXT("Full Moon"),       ESearchCase::IgnoreCase)) WorkingEntry.SpellData.BestMoonPhase = EMoonPhase::Full;
                else if (V.Equals(TEXT("Waning Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.SpellData.BestMoonPhase = EMoonPhase::WaningGibbous;
                else if (V.Equals(TEXT("Last Quarter"),    ESearchCase::IgnoreCase)) WorkingEntry.SpellData.BestMoonPhase = EMoonPhase::LastQuarter;
                else if (V.Equals(TEXT("Waning Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.SpellData.BestMoonPhase = EMoonPhase::WaningCrescent;
                MarkDirty();
            },
            FText::FromString(TEXT("New Moon, Waxing Crescent, Full Moon..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("BEST DAY")),
            WorkingEntry.SpellData.BestDayOfWeek,
            [this](const FText& T){ WorkingEntry.SpellData.BestDayOfWeek = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Friday, Tuesday..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadSM)
        [ MakeSectionHeader(FText::FromString(TEXT("INGREDIENTS & TOOLS"))) ]

        + SVerticalBox::Slot().AutoHeight()
        [ MakeMultilineField(FText::FromString(TEXT("INGREDIENTS")),
            FString::Join(WorkingEntry.SpellData.Ingredients, TEXT("\n")),
            [this](const FText& T)
            {
                T.ToString().ParseIntoArrayLines(WorkingEntry.SpellData.Ingredients);
                MarkDirty();
            },
            100.f, FText::FromString(TEXT("One per line..."))) ]
    ;
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildRitualDetails()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("WORKING"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("PURPOSE")),
            WorkingEntry.RitualData.Purpose,
            [this](const FText& T){ WorkingEntry.RitualData.Purpose = T.ToString(); MarkDirty(); },
            80.f, FText::FromString(TEXT("The intention of this ritual..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("TRADITION")),
            WorkingEntry.RitualData.Tradition,
            [this](const FText& T){ WorkingEntry.RitualData.Tradition = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Wiccan, Hellenic, Eclectic..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("DATE PERFORMED")),
            WorkingEntry.RitualData.DatePerformed,
            [this](const FText& T){ WorkingEntry.RitualData.DatePerformed = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("YYYY-MM-DD"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("MOON PHASE")),
            [this]() -> FString {
                switch(WorkingEntry.RitualData.MoonPhasePerformed) {
                    case EMoonPhase::New:            return TEXT("New Moon");
                    case EMoonPhase::WaxingCrescent: return TEXT("Waxing Crescent");
                    case EMoonPhase::FirstQuarter:   return TEXT("First Quarter");
                    case EMoonPhase::WaxingGibbous:  return TEXT("Waxing Gibbous");
                    case EMoonPhase::Full:            return TEXT("Full Moon");
                    case EMoonPhase::WaningGibbous:  return TEXT("Waning Gibbous");
                    case EMoonPhase::LastQuarter:    return TEXT("Last Quarter");
                    case EMoonPhase::WaningCrescent: return TEXT("Waning Crescent");
                    default:                          return TEXT("");
                }
            }(),
            [this](const FText& T){
                FString V = T.ToString().TrimStartAndEnd();
                if      (V.Equals(TEXT("New Moon"),        ESearchCase::IgnoreCase)) WorkingEntry.RitualData.MoonPhasePerformed = EMoonPhase::New;
                else if (V.Equals(TEXT("Waxing Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.RitualData.MoonPhasePerformed = EMoonPhase::WaxingCrescent;
                else if (V.Equals(TEXT("First Quarter"),   ESearchCase::IgnoreCase)) WorkingEntry.RitualData.MoonPhasePerformed = EMoonPhase::FirstQuarter;
                else if (V.Equals(TEXT("Waxing Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.RitualData.MoonPhasePerformed = EMoonPhase::WaxingGibbous;
                else if (V.Equals(TEXT("Full Moon"),       ESearchCase::IgnoreCase)) WorkingEntry.RitualData.MoonPhasePerformed = EMoonPhase::Full;
                else if (V.Equals(TEXT("Waning Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.RitualData.MoonPhasePerformed = EMoonPhase::WaningGibbous;
                else if (V.Equals(TEXT("Last Quarter"),    ESearchCase::IgnoreCase)) WorkingEntry.RitualData.MoonPhasePerformed = EMoonPhase::LastQuarter;
                else if (V.Equals(TEXT("Waning Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.RitualData.MoonPhasePerformed = EMoonPhase::WaningCrescent;
                MarkDirty();
            },
            FText::FromString(TEXT("New Moon, Waxing Crescent, Full Moon..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadSM)
        [ MakeSectionHeader(FText::FromString(TEXT("BODY"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("RITUAL SCRIPT")),
            WorkingEntry.RitualData.RitualBody,
            [this](const FText& T){ WorkingEntry.RitualData.RitualBody = T.ToString(); MarkDirty(); },
            240.f, FText::FromString(TEXT("The full working — invocations, actions, words..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("OUTCOME")),
            WorkingEntry.RitualData.Outcome,
            [this](const FText& T){ WorkingEntry.RitualData.Outcome = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("What manifested..."))) ]
    ;
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildJournalDetails()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("ENTRY"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("DATE")),
            WorkingEntry.JournalData.EntryDate,
            [this](const FText& T){ WorkingEntry.JournalData.EntryDate = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("YYYY-MM-DD"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("MOON PHASE")),
            [this]() -> FString {
                switch(WorkingEntry.JournalData.MoonPhase) {
                    case EMoonPhase::New:            return TEXT("New Moon");
                    case EMoonPhase::WaxingCrescent: return TEXT("Waxing Crescent");
                    case EMoonPhase::FirstQuarter:   return TEXT("First Quarter");
                    case EMoonPhase::WaxingGibbous:  return TEXT("Waxing Gibbous");
                    case EMoonPhase::Full:            return TEXT("Full Moon");
                    case EMoonPhase::WaningGibbous:  return TEXT("Waning Gibbous");
                    case EMoonPhase::LastQuarter:    return TEXT("Last Quarter");
                    case EMoonPhase::WaningCrescent: return TEXT("Waning Crescent");
                    default:                          return TEXT("");
                }
            }(),
            [this](const FText& T){
                FString V = T.ToString().TrimStartAndEnd();
                if      (V.Equals(TEXT("New Moon"),        ESearchCase::IgnoreCase)) WorkingEntry.JournalData.MoonPhase = EMoonPhase::New;
                else if (V.Equals(TEXT("Waxing Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.JournalData.MoonPhase = EMoonPhase::WaxingCrescent;
                else if (V.Equals(TEXT("First Quarter"),   ESearchCase::IgnoreCase)) WorkingEntry.JournalData.MoonPhase = EMoonPhase::FirstQuarter;
                else if (V.Equals(TEXT("Waxing Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.JournalData.MoonPhase = EMoonPhase::WaxingGibbous;
                else if (V.Equals(TEXT("Full Moon"),       ESearchCase::IgnoreCase)) WorkingEntry.JournalData.MoonPhase = EMoonPhase::Full;
                else if (V.Equals(TEXT("Waning Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.JournalData.MoonPhase = EMoonPhase::WaningGibbous;
                else if (V.Equals(TEXT("Last Quarter"),    ESearchCase::IgnoreCase)) WorkingEntry.JournalData.MoonPhase = EMoonPhase::LastQuarter;
                else if (V.Equals(TEXT("Waning Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.JournalData.MoonPhase = EMoonPhase::WaningCrescent;
                MarkDirty();
            },
            FText::FromString(TEXT("New Moon, Waxing Crescent, Full Moon..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("MOOD / ENERGY")),
            WorkingEntry.JournalData.MoodEnergy,
            [this](const FText& T){ WorkingEntry.JournalData.MoodEnergy = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Grounded, Scattered, Charged..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("BODY")),
            WorkingEntry.JournalData.ReflectionBody,
            [this](const FText& T){ WorkingEntry.JournalData.ReflectionBody = T.ToString(); MarkDirty(); },
            280.f, FText::FromString(TEXT("Write freely..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadSM)
        [ MakeSectionHeader(FText::FromString(TEXT("SIGNS & OMENS"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("DREAM RECORD")),
            WorkingEntry.JournalData.DreamRecord,
            [this](const FText& T){ WorkingEntry.JournalData.DreamRecord = T.ToString(); MarkDirty(); },
            100.f, FText::FromString(TEXT("Dreams, visions, impressions..."))) ]

        + SVerticalBox::Slot().AutoHeight()
        [ MakeMultilineField(FText::FromString(TEXT("OMENS & SYNCHRONICITIES")),
            WorkingEntry.JournalData.OmensSigns,
            [this](const FText& T){ WorkingEntry.JournalData.OmensSigns = T.ToString(); MarkDirty(); },
            80.f, FText::FromString(TEXT("Meaningful coincidences, signs noticed..."))) ]
    ;
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildHerbalDetails()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("IDENTIFICATION"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("COMMON NAME")),
            WorkingEntry.HerbalData.CommonName,
            [this](const FText& T){ WorkingEntry.HerbalData.CommonName = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Mugwort, Rose, Vervain..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("LATIN NAME")),
            WorkingEntry.HerbalData.LatinName,
            [this](const FText& T){ WorkingEntry.HerbalData.LatinName = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Artemisia vulgaris"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("PLANETARY RULER")),
            WorkingEntry.HerbalData.PlanetaryRuler,
            [this](const FText& T){ WorkingEntry.HerbalData.PlanetaryRuler = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Venus, Saturn, Moon..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadSM)
        [ MakeSectionHeader(FText::FromString(TEXT("PROPERTIES"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("MAGICAL PROPERTIES")),
            FString::Join(WorkingEntry.HerbalData.MagicalProperties, TEXT(", ")),
            [this](const FText& T)
            {
                T.ToString().ParseIntoArray(WorkingEntry.HerbalData.MagicalProperties, TEXT(","), true);
                MarkDirty();
            },
            80.f, FText::FromString(TEXT("protection, love, divination..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("USAGE NOTES")),
            WorkingEntry.HerbalData.UsageNotes,
            [this](const FText& T){ WorkingEntry.HerbalData.UsageNotes = T.ToString(); MarkDirty(); },
            100.f, FText::FromString(TEXT("How to use in workings..."))) ]

        + SVerticalBox::Slot().AutoHeight()
        [ MakeMultilineField(FText::FromString(TEXT("CAUTIONS")),
            WorkingEntry.HerbalData.Cautions,
            [this](const FText& T){ WorkingEntry.HerbalData.Cautions = T.ToString(); MarkDirty(); },
            60.f, FText::FromString(TEXT("Toxicity, contraindications, warnings..."))) ]
    ;
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildSigilDetails()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("SIGIL"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("INTENT")),
            WorkingEntry.SigilData.Intent,
            [this](const FText& T){ WorkingEntry.SigilData.Intent = T.ToString(); MarkDirty(); },
            80.f, FText::FromString(TEXT("What this sigil is charged with..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("CREATION METHOD")),
            WorkingEntry.SigilData.CreationMethod,
            [this](const FText& T){ WorkingEntry.SigilData.CreationMethod = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Letter elimination, Automatic drawing..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("CHARGING METHOD")),
            WorkingEntry.SigilData.ChargingMethod,
            [this](const FText& T){ WorkingEntry.SigilData.ChargingMethod = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Moonlight, Fire, Meditation..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("DATE CREATED")),
            WorkingEntry.SigilData.DateCreated,
            [this](const FText& T){ WorkingEntry.SigilData.DateCreated = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("YYYY-MM-DD"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("MOON PHASE")),
            [this]() -> FString {
                switch(WorkingEntry.SigilData.MoonPhaseCreated) {
                    case EMoonPhase::New:            return TEXT("New Moon");
                    case EMoonPhase::WaxingCrescent: return TEXT("Waxing Crescent");
                    case EMoonPhase::FirstQuarter:   return TEXT("First Quarter");
                    case EMoonPhase::WaxingGibbous:  return TEXT("Waxing Gibbous");
                    case EMoonPhase::Full:            return TEXT("Full Moon");
                    case EMoonPhase::WaningGibbous:  return TEXT("Waning Gibbous");
                    case EMoonPhase::LastQuarter:    return TEXT("Last Quarter");
                    case EMoonPhase::WaningCrescent: return TEXT("Waning Crescent");
                    default:                          return TEXT("");
                }
            }(),
            [this](const FText& T){
                FString V = T.ToString().TrimStartAndEnd();
                if      (V.Equals(TEXT("New Moon"),        ESearchCase::IgnoreCase)) WorkingEntry.SigilData.MoonPhaseCreated = EMoonPhase::New;
                else if (V.Equals(TEXT("Waxing Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.SigilData.MoonPhaseCreated = EMoonPhase::WaxingCrescent;
                else if (V.Equals(TEXT("First Quarter"),   ESearchCase::IgnoreCase)) WorkingEntry.SigilData.MoonPhaseCreated = EMoonPhase::FirstQuarter;
                else if (V.Equals(TEXT("Waxing Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.SigilData.MoonPhaseCreated = EMoonPhase::WaxingGibbous;
                else if (V.Equals(TEXT("Full Moon"),       ESearchCase::IgnoreCase)) WorkingEntry.SigilData.MoonPhaseCreated = EMoonPhase::Full;
                else if (V.Equals(TEXT("Waning Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.SigilData.MoonPhaseCreated = EMoonPhase::WaningGibbous;
                else if (V.Equals(TEXT("Last Quarter"),    ESearchCase::IgnoreCase)) WorkingEntry.SigilData.MoonPhaseCreated = EMoonPhase::LastQuarter;
                else if (V.Equals(TEXT("Waning Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.SigilData.MoonPhaseCreated = EMoonPhase::WaningCrescent;
                MarkDirty();
            },
            FText::FromString(TEXT("New Moon, Waxing Crescent, Full Moon..."))) ]

        + SVerticalBox::Slot().AutoHeight()
        [ MakeMultilineField(FText::FromString(TEXT("OUTCOME")),
            WorkingEntry.SigilData.Outcome,
            [this](const FText& T){ WorkingEntry.SigilData.Outcome = T.ToString(); MarkDirty(); },
            80.f, FText::FromString(TEXT("What manifested..."))) ]
    ;
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildAstroDetails()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("EVENT"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("EVENT TYPE")),
            WorkingEntry.AstrologicalData.EventType,
            [this](const FText& T){ WorkingEntry.AstrologicalData.EventType = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Full Moon, Solar Eclipse, Ingress..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("EVENT DATE")),
            WorkingEntry.AstrologicalData.EventDate,
            [this](const FText& T){ WorkingEntry.AstrologicalData.EventDate = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("YYYY-MM-DD"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("MOON PHASE")),
            [this]() -> FString {
                switch(WorkingEntry.AstrologicalData.MoonPhase) {
                    case EMoonPhase::New:            return TEXT("New Moon");
                    case EMoonPhase::WaxingCrescent: return TEXT("Waxing Crescent");
                    case EMoonPhase::FirstQuarter:   return TEXT("First Quarter");
                    case EMoonPhase::WaxingGibbous:  return TEXT("Waxing Gibbous");
                    case EMoonPhase::Full:            return TEXT("Full Moon");
                    case EMoonPhase::WaningGibbous:  return TEXT("Waning Gibbous");
                    case EMoonPhase::LastQuarter:    return TEXT("Last Quarter");
                    case EMoonPhase::WaningCrescent: return TEXT("Waning Crescent");
                    default:                          return TEXT("");
                }
            }(),
            [this](const FText& T){
                FString V = T.ToString().TrimStartAndEnd();
                if      (V.Equals(TEXT("New Moon"),        ESearchCase::IgnoreCase)) WorkingEntry.AstrologicalData.MoonPhase = EMoonPhase::New;
                else if (V.Equals(TEXT("Waxing Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.AstrologicalData.MoonPhase = EMoonPhase::WaxingCrescent;
                else if (V.Equals(TEXT("First Quarter"),   ESearchCase::IgnoreCase)) WorkingEntry.AstrologicalData.MoonPhase = EMoonPhase::FirstQuarter;
                else if (V.Equals(TEXT("Waxing Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.AstrologicalData.MoonPhase = EMoonPhase::WaxingGibbous;
                else if (V.Equals(TEXT("Full Moon"),       ESearchCase::IgnoreCase)) WorkingEntry.AstrologicalData.MoonPhase = EMoonPhase::Full;
                else if (V.Equals(TEXT("Waning Gibbous"),  ESearchCase::IgnoreCase)) WorkingEntry.AstrologicalData.MoonPhase = EMoonPhase::WaningGibbous;
                else if (V.Equals(TEXT("Last Quarter"),    ESearchCase::IgnoreCase)) WorkingEntry.AstrologicalData.MoonPhase = EMoonPhase::LastQuarter;
                else if (V.Equals(TEXT("Waning Crescent"), ESearchCase::IgnoreCase)) WorkingEntry.AstrologicalData.MoonPhase = EMoonPhase::WaningCrescent;
                MarkDirty();
            },
            FText::FromString(TEXT("New Moon, Waxing Crescent, Full Moon..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("MOON SIGN")),
            WorkingEntry.AstrologicalData.MoonSign,
            [this](const FText& T){ WorkingEntry.AstrologicalData.MoonSign = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Scorpio, Pisces..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadSM)
        [ MakeSectionHeader(FText::FromString(TEXT("INTERPRETATION"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("INTERPRETATION")),
            WorkingEntry.AstrologicalData.Interpretation,
            [this](const FText& T){ WorkingEntry.AstrologicalData.Interpretation = T.ToString(); MarkDirty(); },
            160.f, FText::FromString(TEXT("What this event means for your practice..."))) ]

        + SVerticalBox::Slot().AutoHeight()
        [ MakeMultilineField(FText::FromString(TEXT("ENERGY FORECAST")),
            WorkingEntry.AstrologicalData.EnergyForecast,
            [this](const FText& T){ WorkingEntry.AstrologicalData.EnergyForecast = T.ToString(); MarkDirty(); },
            100.f, FText::FromString(TEXT("How to work with this energy..."))) ]
    ;
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildTarotDetails()
{
    return SNew(SVerticalBox)

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [ MakeSectionHeader(FText::FromString(TEXT("READING"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("DATE")),
            WorkingEntry.TarotData.ReadingDate,
            [this](const FText& T){ WorkingEntry.TarotData.ReadingDate = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("YYYY-MM-DD"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeTextField(FText::FromString(TEXT("DECK USED")),
            WorkingEntry.TarotData.DeckUsed,
            [this](const FText& T){ WorkingEntry.TarotData.DeckUsed = T.ToString(); MarkDirty(); },
            FText::FromString(TEXT("e.g. Rider-Waite, Thoth, Wild Unknown..."))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
        [ MakeMultilineField(FText::FromString(TEXT("QUESTION")),
            WorkingEntry.TarotData.Question,
            [this](const FText& T){ WorkingEntry.TarotData.Question = T.ToString(); MarkDirty(); },
            60.f, FText::FromString(TEXT("What were you seeking guidance on?"))) ]

        + SVerticalBox::Slot().AutoHeight().Padding(0.f, GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadSM)
        [ MakeSectionHeader(FText::FromString(TEXT("INTERPRETATION"))) ]

        + SVerticalBox::Slot().AutoHeight()
        [ MakeMultilineField(FText::FromString(TEXT("OVERALL INTERPRETATION")),
            WorkingEntry.TarotData.OverallInterpretation,
            [this](const FText& T){ WorkingEntry.TarotData.OverallInterpretation = T.ToString(); MarkDirty(); },
            200.f, FText::FromString(TEXT("The message of the spread as a whole..."))) ]
    ;
}

// ============================================================
//  BOTTOM ACTIONS
// ============================================================

TSharedRef<SWidget> SGrimoireEditorScreen::BuildActionBar()
{
    return SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(GrimoireStyle::Surface)
        .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadSM))
        [
            SNew(SHorizontalBox)

            // Delete (edit mode only — hidden on new entries)
            + SHorizontalBox::Slot()
            .AutoWidth()
            [
                bIsNewEntry ? SNullWidget::NullWidget :
                SNew(SButton)
                .ButtonColorAndOpacity(GrimoireStyle::Transparent)
                .OnClicked_Lambda([this]()
                {
                    if (!bConfirmingDelete)
                    {
                        bConfirmingDelete = true;
                        if (SaveStatusText.IsValid())
                            SaveStatusText->SetText(FText::FromString(TEXT("Tap DELETE again to confirm.")));
                        RefreshActionBar();
                    }
                    else
                    {
                        bConfirmingDelete = false;
                        DeleteEntry();
                    }
                    return FReply::Handled();
                })
                [
                    SNew(SBox)
                    .Padding(FMargin(GrimoireStyle::PadMD, 6.f))
                    [
                        SNew(STextBlock)
                        .Text(bConfirmingDelete
                            ? FText::FromString(TEXT("CONFIRM?"))
                            : FText::FromString(TEXT("DELETE")))
                        .Font(GrimoireStyle::FontUI(10.f))
                        .ColorAndOpacity(GrimoireStyle::SC_Red)
                    ]
                ]
            ]

            + SHorizontalBox::Slot().FillWidth(1.f)
            [ SNew(SSpacer) ]

            // Cancel
            + SHorizontalBox::Slot()
            .AutoWidth()
            .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
            [
                SNew(SButton)
                .ButtonColorAndOpacity(GrimoireStyle::Surface2)
                .OnClicked_Lambda([this]()
                {
                    if (bDirty)
                    {
                        if (SaveStatusText.IsValid())
                            SaveStatusText->SetText(FText::FromString(TEXT("Tap CANCEL again to discard.")));
                        bDirty = false;
                    }
                    else
                        NavigateTo(FName("Entries"));
                    return FReply::Handled();
                })
                [
                    SNew(SBox)
                    .Padding(FMargin(GrimoireStyle::PadMD, 6.f))
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("CANCEL")))
                        .Font(GrimoireStyle::FontUI(10.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextMuted)
                    ]
                ]
            ]

            // Save
            + SHorizontalBox::Slot()
            .AutoWidth()
            [
                SNew(SButton)
                .ButtonColorAndOpacity(GrimoireStyle::Red)
                .OnClicked_Lambda([this]()
                {
                    SaveEntry();
                    return FReply::Handled();
                })
                [
                    SNew(SBox)
                    .Padding(FMargin(GrimoireStyle::PadXL, 6.f))
                    [
                        SNew(STextBlock)
                        .Text(FText::FromString(TEXT("SAVE ENTRY")))
                        .Font(GrimoireStyle::FontUI(10.f))
                        .ColorAndOpacity(GrimoireStyle::SC_TextPrimary)
                    ]
                ]
            ]
        ];
}

// ============================================================
//  REUSABLE FIELD WIDGETS
// ============================================================

TSharedRef<SWidget> SGrimoireEditorScreen::MakeTextField(
    const FText& Label, const FString& Value,
    TFunction<void(const FText&)> OnChanged, const FText& Hint)
{
    return SNew(SVerticalBox)
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, 3.f)
        [
            SNew(STextBlock)
            .Text(Label)
            .Font(GrimoireStyle::FontUI(7.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
        ]
        + SVerticalBox::Slot()
        .AutoHeight()
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::Surface2)
            .Padding(FMargin(GrimoireStyle::PadSM, 0.f))
            [
                SNew(SBox)
                .HeightOverride(GrimoireStyle::InputHeight)
                [
                    SNew(SEditableTextBox)
                    .Text(FText::FromString(Value))
                    .HintText(Hint)
                    .BackgroundColor(GrimoireStyle::Transparent)
                    .ForegroundColor(GrimoireStyle::SC_TextPrimary)
                    .Font(GrimoireStyle::FontBody(14.f))
                    .OnTextCommitted_Lambda([OnChanged](const FText& T, ETextCommit::Type){ OnChanged(T); })
                ]
            ]
        ];
}

TSharedRef<SWidget> SGrimoireEditorScreen::MakeMultilineField(
    const FText& Label, const FString& Value,
    TFunction<void(const FText&)> OnChanged,
    float HeightPx, const FText& Hint)
{
    return SNew(SVerticalBox)
        + SVerticalBox::Slot()
        .AutoHeight()
        .Padding(0.f, 0.f, 0.f, 3.f)
        [
            SNew(STextBlock)
            .Text(Label)
            .Font(GrimoireStyle::FontUI(7.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
        ]
        + SVerticalBox::Slot()
        .AutoHeight()
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::Surface2)
            .Padding(FMargin(GrimoireStyle::PadSM))
            [
                SNew(SBox)
                .HeightOverride(HeightPx)
                [
                    SNew(SMultiLineEditableTextBox)
                    .Text(FText::FromString(Value))
                    .HintText(Hint)
                    .BackgroundColor(GrimoireStyle::Transparent)
                    .ForegroundColor(GrimoireStyle::SC_TextPrimary)
                    .Font(GrimoireStyle::FontBody(14.f))
                    .AutoWrapText(true)
                    .OnTextCommitted_Lambda([OnChanged](const FText& T, ETextCommit::Type){ OnChanged(T); })
                ]
            ]
        ];
}

TSharedRef<SWidget> SGrimoireEditorScreen::MakeSectionHeader(const FText& Label)
{
    return SNew(SHorizontalBox)
        + SHorizontalBox::Slot()
        .AutoWidth()
        .VAlign(VAlign_Center)
        .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
        [
            SNew(STextBlock)
            .Text(Label)
            .Font(GrimoireStyle::FontUI(8.f))
            .ColorAndOpacity(GrimoireStyle::SC_GoldDim)
        ]
        + SHorizontalBox::Slot()
        .FillWidth(1.f)
        .VAlign(VAlign_Center)
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(GrimoireStyle::Border)
            [ SNew(SBox).HeightOverride(1.f) ]
        ];
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildTypeButton(
    EGrimoireEntryType Type, bool bActive)
{
    const FLinearColor TypeColor = GrimoireStyle::GetTypeColor(Type);
    const FLinearColor BgColor   = bActive
        ? FLinearColor(TypeColor.R*0.2f, TypeColor.G*0.2f, TypeColor.B*0.2f, 1.f)
        : GrimoireStyle::Surface2;

    return SNew(SButton)
        .ButtonStyle(FCoreStyle::Get(), "NoBorder")
        .ButtonColorAndOpacity(BgColor)
        .OnClicked_Lambda([this, Type]()
        {
            SetEntryType(Type);
            return FReply::Handled();
        })
        [
            SNew(SBorder)
            .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
            .BorderBackgroundColor(bActive ? TypeColor : GrimoireStyle::Border)
            .Padding(FMargin(GrimoireStyle::PadSM, 5.f))
            [
                SNew(STextBlock)
                .Text(GrimoireStyle::GetTypeLabel(Type))
                .Font(GrimoireStyle::FontUI(8.f))
                .ColorAndOpacity(bActive
                    ? FSlateColor(TypeColor)
                    : GrimoireStyle::SC_TextMuted)
            ]
        ];
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildToggleRow()
{
    return SNew(SHorizontalBox)

        + SHorizontalBox::Slot()
        .AutoWidth()
        .VAlign(VAlign_Center)
        .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
        [
            SNew(SButton)
            .ButtonStyle(FCoreStyle::Get(), "NoBorder")
            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
            .OnClicked_Lambda([this]()
            {
                WorkingEntry.bIsPinned = !WorkingEntry.bIsPinned;
                MarkDirty();
                RefreshUniversalHeader();
                return FReply::Handled();
            })
            [
                SNew(SHorizontalBox)
                + SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)
                .Padding(0.f, 0.f, 4.f, 0.f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("*")))
                    .Font(GrimoireStyle::FontUI(11.f))
                    .ColorAndOpacity(WorkingEntry.bIsPinned
                        ? GrimoireStyle::SC_Gold
                        : GrimoireStyle::SC_TextFaint)
                ]
                + SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("PIN")))
                    .Font(GrimoireStyle::FontUI(8.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                ]
            ]
        ]

        + SHorizontalBox::Slot()
        .AutoWidth()
        .VAlign(VAlign_Center)
        [
            SNew(SButton)
            .ButtonStyle(FCoreStyle::Get(), "NoBorder")
            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
            .OnClicked_Lambda([this]()
            {
                WorkingEntry.bIsFavourite = !WorkingEntry.bIsFavourite;
                MarkDirty();
                RefreshUniversalHeader();
                return FReply::Handled();
            })
            [
                SNew(SHorizontalBox)
                + SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)
                .Padding(0.f, 0.f, 4.f, 0.f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("o")))
                    .Font(GrimoireStyle::FontUI(11.f))
                    .ColorAndOpacity(WorkingEntry.bIsFavourite
                        ? GrimoireStyle::SC_Gold
                        : GrimoireStyle::SC_TextFaint)
                ]
                + SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TEXT("FAV")))
                    .Font(GrimoireStyle::FontUI(8.f))
                    .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
                ]
            ]
        ]
    ;
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildVisibilityRow()
{
    auto MakeVis = [this](const FText& Label, EEntryVisibility V)
    {
        const bool bActive = WorkingEntry.Visibility == V;
        return SNew(SButton)
            .ButtonStyle(FCoreStyle::Get(), "NoBorder")
            .ButtonColorAndOpacity(GrimoireStyle::Transparent)
            .OnClicked_Lambda([this, V]()
            {
                WorkingEntry.Visibility = V;
                MarkDirty();
                RefreshUniversalHeader();
                return FReply::Handled();
            })
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(bActive ? GrimoireStyle::GoldFaint : GrimoireStyle::Transparent)
                .Padding(FMargin(GrimoireStyle::PadSM, 3.f))
                [
                    SNew(STextBlock)
                    .Text(Label)
                    .Font(GrimoireStyle::FontUI(7.f))
                    .ColorAndOpacity(bActive
                        ? GrimoireStyle::SC_Gold
                        : GrimoireStyle::SC_TextFaint)
                ]
            ];
    };

    return SNew(SHorizontalBox)
        + SHorizontalBox::Slot().AutoWidth()
        [ MakeVis(FText::FromString(TEXT("PRIVATE")), EEntryVisibility::Private) ]
        + SHorizontalBox::Slot().AutoWidth()
        [ MakeVis(FText::FromString(TEXT("COVEN")),   EEntryVisibility::Coven) ]
        + SHorizontalBox::Slot().AutoWidth()
        [ MakeVis(FText::FromString(TEXT("PUBLIC")),  EEntryVisibility::Public) ]
    ;
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildCollectionPicker()
{
    FString CollectionName = TEXT("None");
    for (const FGrimoireCollection& C : AvailableCollections)
    {
        if (C.EntityID == WorkingEntry.CollectionID)
        {
            CollectionName = C.Name;
            break;
        }
    }

    return SNew(SHorizontalBox)

        + SHorizontalBox::Slot()
        .AutoWidth()
        .VAlign(VAlign_Center)
        .Padding(0.f, 0.f, GrimoireStyle::PadSM, 0.f)
        [
            SNew(STextBlock)
            .Text(FText::FromString(TEXT("COLLECTION")))
            .Font(GrimoireStyle::FontUI(7.f))
            .ColorAndOpacity(GrimoireStyle::SC_TextFaint)
        ]

        + SHorizontalBox::Slot()
        .AutoWidth()
        [
            SNew(SButton)
            .ButtonStyle(FCoreStyle::Get(), "NoBorder")
            .ButtonColorAndOpacity(GrimoireStyle::Surface2)
            .OnClicked_Lambda([this]()
            {
                // Cycle through collections
                if (AvailableCollections.Num() == 0)
                {
                    WorkingEntry.CollectionID = TEXT("");
                    return FReply::Handled();
                }
                int32 Idx = -1;
                for (int32 i = 0; i < AvailableCollections.Num(); ++i)
                {
                    if (AvailableCollections[i].EntityID == WorkingEntry.CollectionID)
                    {
                        Idx = i;
                        break;
                    }
                }
                Idx = (Idx + 1) % (AvailableCollections.Num() + 1);
                WorkingEntry.CollectionID = Idx < AvailableCollections.Num()
                    ? AvailableCollections[Idx].EntityID
                    : TEXT("");
                MarkDirty();
                RefreshUniversalHeader();
                return FReply::Handled();
            })
            [
                SNew(SBox)
                .Padding(FMargin(GrimoireStyle::PadSM, 3.f))
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(CollectionName))
                    .Font(GrimoireStyle::FontBody(12.f))
                    .ColorAndOpacity(WorkingEntry.CollectionID.IsEmpty()
                        ? GrimoireStyle::SC_TextFaint
                        : GrimoireStyle::SC_Gold)
                ]
            ]
        ]
    ;
}

// ============================================================
//  LOGIC
// ============================================================

void SGrimoireEditorScreen::LoadEntry(const FString& EntryID)
{
    if (FGrimoireLocalStore* S = Store())
    {
        FGrimoireEntry Loaded;
        if (S->LoadEntry(EntryID, Loaded))
            WorkingEntry = Loaded;
    }
}

void SGrimoireEditorScreen::LoadCollections()
{
    AvailableCollections.Empty();
    if (FGrimoireLocalStore* S = Store())
        S->LoadAllCollections(AvailableCollections);
}

void SGrimoireEditorScreen::RefreshActionBar()
{
    bConfirmingDelete = false;
    if (ActionBarContainer.IsValid())
        ActionBarContainer->SetContent(BuildActionBar());
}

void SGrimoireEditorScreen::RefreshTabBar()
{
    if (TabBarContainer.IsValid())
        TabBarContainer->SetContent(BuildTabBar());
}

void SGrimoireEditorScreen::RefreshTabContent()
{
    if (!TabContent.IsValid()) return;
    TabContent->ClearChildren();
    TabContent->AddSlot()
    .AutoHeight()
    [ BuildTabContent() ];
}

void SGrimoireEditorScreen::SwitchTab(int32 TabIndex)
{
    ActiveTab = TabIndex;
    RefreshTabContent();
    RefreshTabBar();
}

void SGrimoireEditorScreen::SetEntryType(EGrimoireEntryType NewType)
{
    WorkingEntry.EntryType = NewType;
    MarkDirty();
    RefreshTabContent();
    RefreshUniversalHeader();
}

void SGrimoireEditorScreen::SaveEntry()
{
    if (WorkingEntry.Title.IsEmpty())
    {
        if (SaveStatusText.IsValid())
            SaveStatusText->SetText(FText::FromString(TEXT("Title required to save.")));
        return;
    }

    // Set timestamps
    const FString Now = FDateTime::UtcNow().ToIso8601();
    if (WorkingEntry.CreatedAt.IsEmpty())
        WorkingEntry.CreatedAt = Now;
    WorkingEntry.UpdatedAt = Now;
    WorkingEntry.SyncStatus = ESyncStatus::Pending;

    if (FGrimoireLocalStore* S = Store())
    {
        if (S->SaveEntry(WorkingEntry))
        {
            bDirty     = false;
            bIsNewEntry = false;
            if (SaveStatusText.IsValid())
                SaveStatusText->SetText(FText::FromString(TEXT("Saved")));

            // Kick off background sync
            if (FGrimoireSyncService* SyncSvc = Sync())
            {
                SyncSvc->SyncPendingEntries(FOnSyncComplete::CreateLambda(
                    [](bool, FString){} ));
            }
            NavigateTo(FName("Entries"));
        }
        else
        {
            if (SaveStatusText.IsValid())
                SaveStatusText->SetText(FText::FromString(TEXT("Save failed")));
        }
    }
}


// ============================================================
//  VIEW MODE — Read-only grimoire page
// ============================================================

void SGrimoireEditorScreen::SetViewMode(bool bInViewMode)
{
    bViewMode = bInViewMode;

    // The tab content area shows either the edit form or the view page
    if (TabContent.IsValid())
    {
        TabContent->ClearChildren();
        TabContent->AddSlot()
        .FillHeight(1.f)
        [
            bViewMode ? BuildViewPage() : BuildTabContent()
        ];
    }

    // Show/hide the action bar
    if (ActionBarContainer.IsValid())
        ActionBarContainer->SetVisibility(
            bViewMode ? EVisibility::Collapsed : EVisibility::Visible);
}

TSharedRef<SWidget> SGrimoireEditorScreen::BuildViewPage()
{
    // ---- Header info -------------------------------------------------------
    const FString TypeStr  = WorkingEntry.GetTypeDisplayName();
    const FString DateStr  = WorkingEntry.UpdatedAt.IsEmpty()
        ? TEXT("") : WorkingEntry.UpdatedAt.Left(10);
    const FString TagsStr  = FString::Join(WorkingEntry.Tags, TEXT("  ·  "));

    // Helper: convert EMoonPhase to display string
    auto MoonPhaseStr = [](EMoonPhase Phase) -> FString
    {
        if      (Phase == EMoonPhase::New)            return TEXT("New Moon");
        else if (Phase == EMoonPhase::WaxingCrescent) return TEXT("Waxing Crescent");
        else if (Phase == EMoonPhase::FirstQuarter)   return TEXT("First Quarter");
        else if (Phase == EMoonPhase::WaxingGibbous)  return TEXT("Waxing Gibbous");
        else if (Phase == EMoonPhase::Full)            return TEXT("Full Moon");
        else if (Phase == EMoonPhase::WaningGibbous)  return TEXT("Waning Gibbous");
        else if (Phase == EMoonPhase::LastQuarter)     return TEXT("Last Quarter");
        else if (Phase == EMoonPhase::WaningCrescent)  return TEXT("Waning Crescent");
        return TEXT("");
    };

    const FColor  TypeCol  = [&](){
        if (TypeStr == TEXT("Spell"))                    return FColor(139, 26,  26);
        if (TypeStr == TEXT("Ritual"))                   return FColor( 26, 58,  92);
        if (TypeStr == TEXT("Journal Entry"))            return FColor( 74,143, 189);
        if (TypeStr == TEXT("Herbal Correspondence"))    return FColor( 45,107, 58);
        if (TypeStr == TEXT("Sigil & Symbol"))           return FColor(107, 74,139);
        if (TypeStr == TEXT("Tarot Reading"))            return FColor(123, 58,123);
        if (TypeStr == TEXT("Astrological Event"))       return FColor( 26, 42,107);
        return FColor(80, 90,180);
    }();

    TSharedRef<SScrollBox> Page = SNew(SScrollBox)
        .Orientation(Orient_Vertical);

    // ---- Type pip + title header ----------------------------------------
    Page->AddSlot()
    .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
    [
        SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
        .BorderBackgroundColor(FLinearColor(TypeCol.R/255.f*0.3f, TypeCol.G/255.f*0.3f, TypeCol.B/255.f*0.3f, 1.f))
        .Padding(FMargin(GrimoireStyle::PadMD, GrimoireStyle::PadMD))
        [
            SNew(SVerticalBox)

            // Type label
            + SVerticalBox::Slot()
            .AutoHeight()
            .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadXS)
            [
                SNew(STextBlock)
                .Text(FText::FromString(TypeStr.ToUpper()))
                .Font(GrimoireStyle::FontUI(8.f))
                .ColorAndOpacity(FLinearColor(TypeCol.R/255.f, TypeCol.G/255.f, TypeCol.B/255.f, 0.9f))
            ]

            // Title
            + SVerticalBox::Slot()
            .AutoHeight()
            .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadSM)
            [
                SNew(STextBlock)
                .Text(FText::FromString(WorkingEntry.Title))
                .Font(GrimoireStyle::FontDisplay(20.f))
                .ColorAndOpacity(GrimoireStyle::TextPrimary)
                .AutoWrapText(true)
            ]

            // Date + tags row
            + SVerticalBox::Slot()
            .AutoHeight()
            [
                SNew(SHorizontalBox)
                + SHorizontalBox::Slot()
                .AutoWidth()
                .Padding(0.f, 0.f, GrimoireStyle::PadMD, 0.f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(DateStr))
                    .Font(GrimoireStyle::FontUI(9.f))
                    .ColorAndOpacity(GrimoireStyle::TextMuted)
                ]
                + SHorizontalBox::Slot()
                .FillWidth(1.f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(TagsStr))
                    .Font(GrimoireStyle::FontUI(9.f))
                    .ColorAndOpacity(GrimoireStyle::TextFaint)
                    .AutoWrapText(true)
                ]
            ]
        ]
    ];

    // ---- Type-specific fields as readable sections -------------------------
    // Helper to add a labeled text block
    auto AddField = [&](const FString& Label, const FString& Value)
    {
        if (Value.IsEmpty()) return;
        Page->AddSlot()
        .Padding(0.f, 0.f, 0.f, GrimoireStyle::PadMD)
        [
            SNew(SVerticalBox)
            + SVerticalBox::Slot()
            .AutoHeight()
            .Padding(GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadMD, GrimoireStyle::PadXS)
            [
                SNew(SBorder)
                .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                .BorderBackgroundColor(FLinearColor(0.f, 0.f, 0.3f, 0.1f))
                .Padding(FMargin(0.f, 0.f, 0.f, GrimoireStyle::PadXS))
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(Label.ToUpper()))
                    .Font(GrimoireStyle::FontUI(8.f))
                    .ColorAndOpacity(GrimoireStyle::Gold)
                ]
            ]
            + SVerticalBox::Slot()
            .AutoHeight()
            .Padding(GrimoireStyle::PadMD, 0.f, GrimoireStyle::PadMD, 0.f)
            [
                SNew(STextBlock)
                .Text(FText::FromString(Value))
                .Font(GrimoireStyle::FontBody(15.f))
                .ColorAndOpacity(GrimoireStyle::TextPrimary)
                .AutoWrapText(true)
            ]
        ];
    };

    const EGrimoireEntryType T = WorkingEntry.EntryType;

    if (T == EGrimoireEntryType::Spell)
    {
        AddField(TEXT("Intent"),        WorkingEntry.SpellData.Intent);
        AddField(TEXT("Ingredients"),   FString::Join(WorkingEntry.SpellData.Ingredients, TEXT("\n")));
        AddField(TEXT("Instructions"),  WorkingEntry.SpellData.Instructions);
        AddField(TEXT("Incantation"),   WorkingEntry.SpellData.Incantation);
        AddField(TEXT("Moon Phase"),    MoonPhaseStr(WorkingEntry.SpellData.BestMoonPhase));
        AddField(TEXT("Best Day"),      WorkingEntry.SpellData.BestDayOfWeek);
        AddField(TEXT("Expected"),      WorkingEntry.SpellData.ExpectedOutcome);
        AddField(TEXT("Results"),       WorkingEntry.SpellData.ResultsNotes);
    }
    else if (T == EGrimoireEntryType::Ritual)
    {
        AddField(TEXT("Purpose"),    WorkingEntry.RitualData.Purpose);
        AddField(TEXT("Tradition"),  WorkingEntry.RitualData.Tradition);
        AddField(TEXT("Tools"),      FString::Join(WorkingEntry.RitualData.ToolsUsed, TEXT("\n")));
        AddField(TEXT("Ritual"),     WorkingEntry.RitualData.RitualBody);
        AddField(TEXT("Moon Phase"), MoonPhaseStr(WorkingEntry.RitualData.MoonPhasePerformed));
        AddField(TEXT("Date"),       WorkingEntry.RitualData.DatePerformed);
        AddField(TEXT("Outcome"),    WorkingEntry.RitualData.Outcome);
    }
    else if (T == EGrimoireEntryType::JournalEntry)
    {
        AddField(TEXT("Date"),          WorkingEntry.JournalData.EntryDate);
        AddField(TEXT("Moon Phase"),    MoonPhaseStr(WorkingEntry.JournalData.MoonPhase));
        AddField(TEXT("Sun Sign"),      WorkingEntry.JournalData.SunSign);
        AddField(TEXT("Mood & Energy"), WorkingEntry.JournalData.MoodEnergy);
        AddField(TEXT("Entry"),         WorkingEntry.JournalData.ReflectionBody);
        AddField(TEXT("Dreams"),        WorkingEntry.JournalData.DreamRecord);
        AddField(TEXT("Omens & Signs"), WorkingEntry.JournalData.OmensSigns);
        AddField(TEXT("Practice"),      WorkingEntry.JournalData.PracticeNotes);
    }
    else if (T == EGrimoireEntryType::HerbalCorrespondence)
    {
        AddField(TEXT("Common Name"),   WorkingEntry.HerbalData.CommonName);
        AddField(TEXT("Latin Name"),    WorkingEntry.HerbalData.LatinName);
        AddField(TEXT("Planetary"),     WorkingEntry.HerbalData.PlanetaryRuler);
        AddField(TEXT("Properties"),    FString::Join(WorkingEntry.HerbalData.MagicalProperties, TEXT(", ")));
        AddField(TEXT("Healing"),       FString::Join(WorkingEntry.HerbalData.HealingProperties, TEXT(", ")));
        AddField(TEXT("Usage Notes"),   WorkingEntry.HerbalData.UsageNotes);
        AddField(TEXT("Cautions"),      WorkingEntry.HerbalData.Cautions);
        AddField(TEXT("Notes"),         WorkingEntry.HerbalData.PersonalNotes);
    }
    else if (T == EGrimoireEntryType::Sigil)
    {
        AddField(TEXT("Intention"),   WorkingEntry.SigilData.Intent);
        AddField(TEXT("Method"),      WorkingEntry.SigilData.CreationMethod);
        AddField(TEXT("Charging"),    WorkingEntry.SigilData.ChargingMethod);
        AddField(TEXT("Destruction"), WorkingEntry.SigilData.DestructionMethod);
        AddField(TEXT("Moon Phase"),  MoonPhaseStr(WorkingEntry.SigilData.MoonPhaseCreated));
        AddField(TEXT("Date"),        WorkingEntry.SigilData.DateCreated);
        AddField(TEXT("Outcome"),     WorkingEntry.SigilData.Outcome);
        AddField(TEXT("Notes"),       WorkingEntry.SigilData.Notes);
    }
    else if (T == EGrimoireEntryType::TarotLog)
    {
        // Build a readable card list from the struct array
        FString CardList;
        for (const FTarotCardPull& Card : WorkingEntry.TarotData.CardsDrawn)
        {
            if (!CardList.IsEmpty()) CardList += TEXT("\n");
            const FString OrientStr = (Card.Orientation == ECardOrientation::Reversed)
                ? TEXT(" (Reversed)") : TEXT("");
            CardList += FString::Printf(TEXT("%s — %s%s"),
                *Card.PositionLabel, *Card.CardName, *OrientStr);
        }

        AddField(TEXT("Date"),           WorkingEntry.TarotData.ReadingDate);
        AddField(TEXT("Question"),       WorkingEntry.TarotData.Question);
        AddField(TEXT("Deck"),           WorkingEntry.TarotData.DeckUsed);
        AddField(TEXT("Spread"),         WorkingEntry.TarotData.CustomSpreadName);
        AddField(TEXT("Cards Drawn"),    CardList);
        AddField(TEXT("Interpretation"), WorkingEntry.TarotData.OverallInterpretation);
        AddField(TEXT("Moon Phase"),     MoonPhaseStr(WorkingEntry.TarotData.MoonPhase));
        AddField(TEXT("Outcome"),        WorkingEntry.TarotData.Outcome);
    }
    else if (T == EGrimoireEntryType::AstrologicalData)
    {
        AddField(TEXT("Date"),          WorkingEntry.AstrologicalData.EventDate);
        AddField(TEXT("Event Type"),    WorkingEntry.AstrologicalData.EventType);
        AddField(TEXT("Moon Phase"),    MoonPhaseStr(WorkingEntry.AstrologicalData.MoonPhase));
        AddField(TEXT("Moon Sign"),     WorkingEntry.AstrologicalData.MoonSign);
        AddField(TEXT("Rising Sign"),   WorkingEntry.AstrologicalData.RisingSign);
        AddField(TEXT("Aspects"),       FString::Join(WorkingEntry.AstrologicalData.ActiveAspects, TEXT("\n")));
        AddField(TEXT("Interpretation"),WorkingEntry.AstrologicalData.Interpretation);
        AddField(TEXT("Energy"),        WorkingEntry.AstrologicalData.EnergyForecast);
    }

    // ---- Edit button at bottom ----
    Page->AddSlot()
    .Padding(GrimoireStyle::PadMD, GrimoireStyle::PadLG, GrimoireStyle::PadMD, GrimoireStyle::PadMD)
    [
        SNew(SButton)
        .ButtonColorAndOpacity(GrimoireStyle::Surface2)
        .HAlign(HAlign_Center)
        .OnClicked_Lambda([this]()
        {
            SetViewMode(false);
            return FReply::Handled();
        })
        [
            SNew(SBox)
            .Padding(FMargin(GrimoireStyle::PadXL, GrimoireStyle::PadSM))
            [
                SNew(STextBlock)
                .Text(FText::FromString(TEXT("EDIT ENTRY")))
                .Font(GrimoireStyle::FontUI(10.f))
                .ColorAndOpacity(GrimoireStyle::Gold)
            ]
        ]
    ];

    return Page;
}

void SGrimoireEditorScreen::DeleteEntry()
{
    if (bIsNewEntry) return;

    if (FGrimoireLocalStore* S = Store())
    {
        S->SoftDeleteEntry(WorkingEntry.EntityID);
        NavigateTo(FName("Entries"));
    }
}

void SGrimoireEditorScreen::RefreshUniversalHeader()
{
    if (TypeSelectorContainer.IsValid())
        TypeSelectorContainer->SetContent(
            SNew(SScrollBox)
            .Orientation(Orient_Horizontal)
            .ScrollBarVisibility(EVisibility::Collapsed)
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::Spell, WorkingEntry.EntryType == EGrimoireEntryType::Spell) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::Ritual, WorkingEntry.EntryType == EGrimoireEntryType::Ritual) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::JournalEntry, WorkingEntry.EntryType == EGrimoireEntryType::JournalEntry) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::TarotLog, WorkingEntry.EntryType == EGrimoireEntryType::TarotLog) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::HerbalCorrespondence, WorkingEntry.EntryType == EGrimoireEntryType::HerbalCorrespondence) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::Sigil, WorkingEntry.EntryType == EGrimoireEntryType::Sigil) ]
            + SScrollBox::Slot().Padding(0.f, 0.f, 6.f, 0.f)
            [ BuildTypeButton(EGrimoireEntryType::AstrologicalData, WorkingEntry.EntryType == EGrimoireEntryType::AstrologicalData) ]
        );

    if (ToggleRowContainer.IsValid())
        ToggleRowContainer->SetContent(
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot().FillWidth(1.f)
            [ BuildToggleRow() ]
            + SHorizontalBox::Slot().AutoWidth()
            .Padding(GrimoireStyle::PadMD, 0.f, 0.f, 0.f)
            [ BuildVisibilityRow() ]
        );

    if (CollectionPickerContainer.IsValid())
        CollectionPickerContainer->SetContent(BuildCollectionPicker());
}

void SGrimoireEditorScreen::MarkDirty()
{
    bDirty = true;
    if (SaveStatusText.IsValid())
        SaveStatusText->SetText(FText::FromString(TEXT("Unsaved")));
}

FString SGrimoireEditorScreen::FormatTagArray(const TArray<FString>& Tags)
{
    return FString::Join(Tags, TEXT(", "));
}

TArray<FString> SGrimoireEditorScreen::ParseTagString(const FString& Raw)
{
    TArray<FString> Out;
    Raw.ParseIntoArray(Out, TEXT(","), true);
    for (FString& S : Out)
        S = S.TrimStartAndEnd();
    Out.RemoveAll([](const FString& S){ return S.IsEmpty(); });
    return Out;
}
