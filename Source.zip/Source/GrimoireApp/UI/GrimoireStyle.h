#pragma once

#include "CoreMinimal.h"
#include "Styling/SlateColor.h"
#include "Styling/SlateBrush.h"
#include "Fonts/SlateFontInfo.h"
#include "Fonts/CompositeFont.h"
#include "Styling/CoreStyle.h"
#include "../Core/DataModel/GrimoireEntry.h"

// ============================================================
//  GRIMOIRE APP — Design System  (header-only)
//  GrimoireStyle.h
//
//  Design: Celestial Blue
//  Fonts: Cinzel (display/UI) + Cormorant Garamond (body)
//
//  Font setup — drop TTFs into Content/Fonts/:
//    Cinzel-Regular.ttf, Cinzel-Bold.ttf
//    CormorantGaramond-Regular.ttf
//    CormorantGaramond-Medium.ttf
//    CormorantGaramond-Italic.ttf
//  Both free on Google Fonts. Falls back to Roboto if absent.
//
//  Font REGISTRATION lives in GrimoireGameInstance.cpp so that
//  FSlateStyleSet (a large header) is only pulled in once.
//  Call GrimoireStyle::RegisterFonts() from GameInstance::Init()
//  and UnregisterFonts() from GameInstance::Shutdown().
// ============================================================

namespace GrimoireStyle
{
    // --------------------------------------------------------
    //  Color Palette — Celestial Blue
    //  Deep midnight navy surfaces, aged gold accents,
    //  cool silver text, indigo action color.
    //  Matches the Skein website aesthetic.
    // --------------------------------------------------------
    inline const FLinearColor BG          = FLinearColor(0.005f, 0.008f, 0.030f, 1.f);  // #010214 deep midnight
    inline const FLinearColor Surface     = FLinearColor(0.012f, 0.018f, 0.055f, 1.f);  // #030a16 navy surface
    inline const FLinearColor Surface2    = FLinearColor(0.020f, 0.030f, 0.080f, 1.f);  // slightly lighter navy
    inline const FLinearColor Surface3    = FLinearColor(0.030f, 0.045f, 0.105f, 1.f);  // card hover surface
    inline const FLinearColor SurfaceGlow = FLinearColor(0.035f, 0.055f, 0.120f, 1.f);  // active/glow surface
    inline const FLinearColor Border      = FLinearColor(0.050f, 0.075f, 0.160f, 1.f);  // blue-tinted hairline
    inline const FLinearColor BorderLight = FLinearColor(0.075f, 0.110f, 0.220f, 1.f);  // lighter border
    inline const FLinearColor BorderGold  = FLinearColor(0.200f, 0.158f, 0.072f, 1.f);  // gold border (unchanged)
    inline const FLinearColor Gold        = FLinearColor(0.518f, 0.420f, 0.178f, 1.f);  // aged gold (unchanged)
    inline const FLinearColor GoldBright  = FLinearColor(0.680f, 0.560f, 0.240f, 1.f);  // bright gold (unchanged)
    inline const FLinearColor GoldDim     = FLinearColor(0.290f, 0.230f, 0.095f, 1.f);  // dim gold (unchanged)
    inline const FLinearColor GoldFaint   = FLinearColor(0.100f, 0.082f, 0.035f, 1.f);  // faint gold tint
    inline const FLinearColor Red         = FLinearColor(0.120f, 0.080f, 0.380f, 1.f);  // deep indigo (replaces crimson)
    inline const FLinearColor RedHover    = FLinearColor(0.160f, 0.110f, 0.460f, 1.f);  // indigo hover
    inline const FLinearColor RedDim      = FLinearColor(0.060f, 0.040f, 0.190f, 1.f);  // dim indigo
    inline const FLinearColor RedGlow     = FLinearColor(0.090f, 0.060f, 0.280f, 1.f);  // indigo glow
    inline const FLinearColor TextPrimary = FLinearColor(0.920f, 0.930f, 0.970f, 1.f);  // cool near-white
    inline const FLinearColor TextMuted   = FLinearColor(0.420f, 0.460f, 0.580f, 1.f);  // blue-grey muted
    inline const FLinearColor TextFaint   = FLinearColor(0.200f, 0.230f, 0.320f, 1.f);  // very faint blue-grey
    inline const FLinearColor TypeSpell   = FLinearColor(0.650f, 0.130f, 0.130f, 1.f);  // crimson (kept — fire energy)
    inline const FLinearColor TypeRitual  = FLinearColor(0.518f, 0.420f, 0.178f, 1.f);  // gold (kept)
    inline const FLinearColor TypeJournal = FLinearColor(0.250f, 0.480f, 0.780f, 1.f);  // sky blue
    inline const FLinearColor TypeTarot   = FLinearColor(0.480f, 0.250f, 0.750f, 1.f);  // violet
    inline const FLinearColor TypeHerbal  = FLinearColor(0.200f, 0.530f, 0.300f, 1.f);  // sage green
    inline const FLinearColor TypeSigil   = FLinearColor(0.350f, 0.280f, 0.650f, 1.f);  // periwinkle
    inline const FLinearColor TypeAstro   = FLinearColor(0.180f, 0.360f, 0.720f, 1.f);  // deep sky blue
    inline const FLinearColor Transparent = FLinearColor(0.f, 0.f, 0.f, 0.f);

    inline FSlateColor SC(const FLinearColor& C)  { return FSlateColor(C); }
    inline const FSlateColor SC_BG          = FSlateColor(BG);
    inline const FSlateColor SC_Surface     = FSlateColor(Surface);
    inline const FSlateColor SC_Gold        = FSlateColor(Gold);
    inline const FSlateColor SC_GoldBright  = FSlateColor(GoldBright);
    inline const FSlateColor SC_GoldDim     = FSlateColor(GoldDim);
    inline const FSlateColor SC_GoldFaint   = FSlateColor(GoldFaint);
    inline const FSlateColor SC_Red         = FSlateColor(Red);
    inline const FSlateColor SC_TextPrimary = FSlateColor(TextPrimary);
    inline const FSlateColor SC_TextMuted   = FSlateColor(TextMuted);
    inline const FSlateColor SC_TextFaint   = FSlateColor(TextFaint);
    inline const FSlateColor SC_Border      = FSlateColor(Border);
    inline const FSlateColor SC_BorderGold  = FSlateColor(BorderGold);
    inline const FSlateColor SC_Transparent = FSlateColor(Transparent);

    // --------------------------------------------------------
    //  Spacing — 4pt grid
    // --------------------------------------------------------
    inline constexpr float PadXS  =  4.f;
    inline constexpr float PadSM  =  8.f;
    inline constexpr float PadMD  = 16.f;
    inline constexpr float PadLG  = 24.f;
    inline constexpr float PadXL  = 40.f;
    inline constexpr float PadXXL = 56.f;

    inline constexpr float TopBarHeight    = 60.f;
    inline constexpr float BottomNavHeight = 68.f;
    inline constexpr float CollectionCardW = 130.f;
    inline constexpr float CollectionCardH = 108.f;
    inline constexpr float FABSize         = 56.f;
    inline constexpr float InputHeight     = 44.f;
    inline constexpr float ButtonHeight    = 48.f;
    inline constexpr float SigilSize       = 88.f;
    inline constexpr float CardWidth       = 400.f;
    inline constexpr float BorderPx        = 1.f;
    inline constexpr float AccentBarW      = 3.f;

    // --------------------------------------------------------
    //  Font lookup — defined in GrimoireGameInstance.cpp alongside
    //  the font store. Declared here as a non-inline so the linker
    //  resolves it to the single definition in that TU.
    //  Falls back to Roboto if fonts not yet loaded.
    // --------------------------------------------------------
    GRIMOIREAPP_API FSlateFontInfo GetFont(FName FontFamily, float Size, FName TypefaceEntry);

    inline FSlateFontInfo FontDisplay(float Size)        { return GetFont("Cinzel",    Size, "Bold");    }
    inline FSlateFontInfo FontDisplayRegular(float Size) { return GetFont("Cinzel",    Size, "Regular"); }
    inline FSlateFontInfo FontUI(float Size)             { return GetFont("Cinzel",    Size, "Regular"); }
    inline FSlateFontInfo FontBody(float Size)           { return GetFont("Cormorant", Size, "Regular"); }
    inline FSlateFontInfo FontBodyMedium(float Size)     { return GetFont("Cormorant", Size, "Medium");  }
    inline FSlateFontInfo FontBodyItalic(float Size)     { return GetFont("Cormorant", Size, "Italic");  }

    // --------------------------------------------------------
    //  Registration stubs — inline so no external symbol is emitted.
    //  The actual font registration is done directly in
    //  GrimoireGameInstance.cpp using the GrimoireFonts helpers below.
    // --------------------------------------------------------
    inline void RegisterFonts()   {}
    inline void UnregisterFonts() {}

    // --------------------------------------------------------
    //  Brushes
    // --------------------------------------------------------
    inline FSlateBrush MakeSolidBrush(const FLinearColor& Color)
    {
        FSlateBrush Brush;
        Brush.TintColor = FSlateColor(Color);
        Brush.DrawAs   = ESlateBrushDrawType::Image;
        return Brush;
    }
    inline const FSlateBrush BrushBG      = MakeSolidBrush(BG);
    inline const FSlateBrush BrushSurface = MakeSolidBrush(Surface);
    inline const FSlateBrush BrushRed     = MakeSolidBrush(Red);
    inline const FSlateBrush BrushGold    = MakeSolidBrush(Gold);

    // --------------------------------------------------------
    //  Entry type helpers
    // --------------------------------------------------------
    inline FLinearColor GetTypeColor(EGrimoireEntryType Type)
    {
        switch (Type)
        {
            case EGrimoireEntryType::Spell:                return TypeSpell;
            case EGrimoireEntryType::Ritual:               return TypeRitual;
            case EGrimoireEntryType::JournalEntry:         return TypeJournal;
            case EGrimoireEntryType::TarotLog:             return TypeTarot;
            case EGrimoireEntryType::HerbalCorrespondence: return TypeHerbal;
            case EGrimoireEntryType::Sigil:                return TypeSigil;
            case EGrimoireEntryType::AstrologicalData:     return TypeAstro;
            default:                                        return GoldDim;
        }
    }
    inline FText GetTypeLabel(EGrimoireEntryType Type)
    {
        switch (Type)
        {
            case EGrimoireEntryType::Spell:                return FText::FromString(TEXT("Spell"));
            case EGrimoireEntryType::Ritual:               return FText::FromString(TEXT("Ritual"));
            case EGrimoireEntryType::JournalEntry:         return FText::FromString(TEXT("Journal"));
            case EGrimoireEntryType::TarotLog:             return FText::FromString(TEXT("Tarot Log"));
            case EGrimoireEntryType::HerbalCorrespondence: return FText::FromString(TEXT("Herbal"));
            case EGrimoireEntryType::Sigil:                return FText::FromString(TEXT("Sigil"));
            case EGrimoireEntryType::AstrologicalData:     return FText::FromString(TEXT("Astro"));
            default:                                        return FText::FromString(TEXT("Custom"));
        }
    }
    inline FText GetTypeGlyph(EGrimoireEntryType Type)
    {
        switch (Type)
        {
            case EGrimoireEntryType::Spell:                return FText::FromString(TEXT("S"));
            case EGrimoireEntryType::Ritual:               return FText::FromString(TEXT("R"));
            case EGrimoireEntryType::JournalEntry:         return FText::FromString(TEXT("J"));
            case EGrimoireEntryType::TarotLog:             return FText::FromString(TEXT("T"));
            case EGrimoireEntryType::HerbalCorrespondence: return FText::FromString(TEXT("H"));
            case EGrimoireEntryType::Sigil:                return FText::FromString(TEXT("Si"));
            case EGrimoireEntryType::AstrologicalData:     return FText::FromString(TEXT("A"));
            default:                                        return FText::FromString(TEXT("?"));
        }
    }
}
