#include "GrimoireUpdateChecker.h"
#include "Serialization/JsonWriter.h"

void FGrimoireUpdateChecker::CheckForUpdate(
    const FString& APIEndpoint,
    const FString& CurrentVersion,
    const FString& Platform,
    FOnUpdateCheckComplete OnComplete)
{
    TSharedPtr<FJsonObject> Payload = MakeShareable(new FJsonObject());
    Payload->SetStringField(TEXT("action"), TEXT("app:version"));
    Payload->SetObjectField(TEXT("body"), [&](){
        TSharedPtr<FJsonObject> B = MakeShareable(new FJsonObject());
        B->SetStringField(TEXT("version"),  CurrentVersion);
        B->SetStringField(TEXT("platform"), Platform);
        return B;
    }());

    FString BodyStr;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&BodyStr);
    FJsonSerializer::Serialize(Payload.ToSharedRef(), Writer);

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Req =
        FHttpModule::Get().CreateRequest();
    Req->SetURL(APIEndpoint);
    Req->SetVerb(TEXT("POST"));
    Req->SetHeader(TEXT("Content-Type"), TEXT("application/json"));
    Req->SetContentAsString(BodyStr);

    Req->OnProcessRequestComplete().BindLambda(
        [OnComplete](FHttpRequestPtr, FHttpResponsePtr Resp, bool bOk)
        {
            if (!bOk || !Resp.IsValid() ||
                Resp->GetResponseCode() < 200 || Resp->GetResponseCode() >= 300)
            {
                // Fail silently — never block the user for a version check
                OnComplete.ExecuteIfBound(false, TEXT(""), TEXT(""));
                return;
            }

            TSharedPtr<FJsonObject> Json;
            TSharedRef<TJsonReader<>> Reader =
                TJsonReaderFactory<>::Create(Resp->GetContentAsString());
            if (!FJsonSerializer::Deserialize(Reader, Json) || !Json.IsValid())
            {
                OnComplete.ExecuteIfBound(false, TEXT(""), TEXT(""));
                return;
            }

            bool    bUpdate  = Json->GetBoolField(TEXT("updateAvailable"));
            FString Latest   = Json->GetStringField(TEXT("latestVersion"));
            FString DlUrl    = bUpdate ? Json->GetStringField(TEXT("downloadUrl")) : TEXT("");

            OnComplete.ExecuteIfBound(bUpdate, Latest, DlUrl);
        });

    Req->ProcessRequest();
}
