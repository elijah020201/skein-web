#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "Core/LocalDB/GrimoireLocalStore.h"
#include "Core/Services/GrimoireAuthService.h"
#include "Core/Services/GrimoireSyncService.h"
#include "GrimoireGameInstance.generated.h"

// ============================================================
//  GRIMOIRE APP — Game Instance
//  GrimoireGameInstance.h
//
//  The app-wide owner of all core services.
//  Created on launch, destroyed on close.
//
//  Every UI screen accesses services through here:
//    UGrimoireGameInstance* GI = Cast<UGrimoireGameInstance>(
//        GetGameInstance());
//    GI->GetAuthService().Login(...);
//
//  This is the ONE class that uses Unreal macros — it must
//  inherit from UGameInstance which requires UCLASS/GENERATED_BODY
//  so Unreal's object system can manage its lifetime. Our own
//  service classes remain pure C++.
// ============================================================

UCLASS()
class GRIMOIREAPP_API UGrimoireGameInstance : public UGameInstance
{
    GENERATED_BODY()

public:

    UGrimoireGameInstance();

    // --------------------------------------------------------
    //  UGameInstance interface
    // --------------------------------------------------------

    /** Called once when the app launches. We initialize all
     *  services here. */
    virtual void Init() override;

    /** Called when the app is shutting down. We close the
     *  database cleanly here. */
    virtual void Shutdown() override;

    // --------------------------------------------------------
    //  Service accessors
    //  Returns a reference so callers can't accidentally null it.
    // --------------------------------------------------------

    FGrimoireLocalStore&  GetLocalStore()   { return *LocalStore;   }

    // Update check accessors (called from Dashboard)
    bool    IsUpdateAvailable() const { return bUpdateAvailable; }
    FString GetUpdateVersion()  const { return PendingUpdateVersion; }
    FString GetUpdateURL()      const { return PendingUpdateURL; }
    void    ClearUpdateBanner()       { bUpdateAvailable = false; }
    FGrimoireAuthService& GetAuthService()  { return *AuthService;  }
    FGrimoireSyncService& GetSyncService()  { return *SyncService;  }

    // Const versions for read-only access
    const FGrimoireLocalStore&  GetLocalStore()  const { return *LocalStore;  }
    const FGrimoireAuthService& GetAuthService() const { return *AuthService; }

private:

    // --------------------------------------------------------
    //  AWS configuration constants
    //  These are the values from our AWS setup.
    //  In a shipping app these would be loaded from a config
    //  file or environment — never hardcoded in source.
    //  For development, hardcoding is fine.
    // --------------------------------------------------------

    static constexpr const TCHAR* COGNITO_USER_POOL_ID = TEXT("us-east-1_JfJbA8Guu");
    static constexpr const TCHAR* COGNITO_CLIENT_ID    = TEXT("5pactktdabhtd5rh2gu70jfdj6");
    static constexpr const TCHAR* API_ENDPOINT         =
        TEXT("https://yjgpdnscte.execute-api.us-east-1.amazonaws.com/prod/grimoire");

    // --------------------------------------------------------
    //  Update check state
    // --------------------------------------------------------
    bool    bUpdateAvailable    = false;
    FString PendingUpdateVersion;
    FString PendingUpdateURL;

    // --------------------------------------------------------
    //  Services — owned exclusively by the Game Instance
    // --------------------------------------------------------

    TUniquePtr<FGrimoireLocalStore>  LocalStore;
    TUniquePtr<FGrimoireAuthService> AuthService;
    TUniquePtr<FGrimoireSyncService> SyncService;
};
