// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;
using System.IO;

public class GrimoireApp : ModuleRules
{
    public GrimoireApp(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        // Allow includes relative to the module's source root
        PublicIncludePaths.Add(Path.Combine(ModuleDirectory));

        PublicDependencyModuleNames.AddRange(new string[]
        {
            "Core",
            "CoreUObject",
            "Engine",
            "InputCore",
            "SQLiteCore",       // Local database
            "Json",             // JSON serialization
            "HTTP",             // HTTP requests to Cognito + Lambda
            "Slate",            // UI framework
            "SlateCore",        // Slate foundation types
            "UMG",              // Widget component support
        });

        PrivateDependencyModuleNames.AddRange(new string[]
        {
            "SQLiteSupport",
            "RenderCore",       // Needed for some Slate brush types
        });
    }
}
