#pragma once

#include "CoreMinimal.h"

// ============================================================
//  GRIMOIRE APP — Core Types & Enumerations
//  GrimoireTypes.h
//
//  Foundation enums and structs shared across the entire
//  data model. All other headers depend on this file.
//  Pure C++ — no Blueprint reflection macros.
// ============================================================


// ------------------------------------------------------------
//  Entry Types
// ------------------------------------------------------------
enum class EGrimoireEntryType : uint8
{
    Spell,
    Ritual,
    JournalEntry,
    HerbalCorrespondence,
    Sigil,
    AstrologicalData,
    TarotLog,
    Custom
};


// ------------------------------------------------------------
//  Sync Status
// ------------------------------------------------------------
enum class ESyncStatus : uint8
{
    Local,      // Never synced
    Synced,     // In sync with cloud
    Pending,    // Modified, awaiting upload
    Conflict,   // Local and cloud versions differ
    Deleted     // Marked for deletion on next sync
};


// ------------------------------------------------------------
//  Visibility (future-proofing for coven sharing)
// ------------------------------------------------------------
enum class EEntryVisibility : uint8
{
    Private,
    Coven,      // Future
    Public      // Future
};


// ------------------------------------------------------------
//  Moon Phase
// ------------------------------------------------------------
enum class EMoonPhase : uint8
{
    New,
    WaxingCrescent,
    FirstQuarter,
    WaxingGibbous,
    Full,
    WaningGibbous,
    LastQuarter,
    WaningCrescent,
    Unknown
};


// ------------------------------------------------------------
//  Elemental Associations
// ------------------------------------------------------------
enum class EElement : uint8
{
    Fire,
    Water,
    Earth,
    Air,
    Spirit,
    None
};


// ------------------------------------------------------------
//  Tarot Spread Types
// ------------------------------------------------------------
enum class ETarotSpread : uint8
{
    SingleCard,
    ThreeCard,
    CelticCross,
    Horseshoe,
    YearAhead,
    Custom
};


// ------------------------------------------------------------
//  Tarot Card Orientation
// ------------------------------------------------------------
enum class ECardOrientation : uint8
{
    Upright,
    Reversed
};


// ------------------------------------------------------------
//  Asset Type
// ------------------------------------------------------------
enum class EAssetType : uint8
{
    Image,
    Audio,
    Video,
    PDF,
    SVG,
    Other
};


// ============================================================
//  BASE STRUCT — Timestamps & Sync Metadata
//  Every persistent entity inherits this.
// ============================================================
struct FGrimoireEntityBase
{
    FString EntityID;       // UUID v4, generated locally
    FString OwnerUserID;    // Cognito sub

    // ISO 8601 timestamps
    FString CreatedAt;
    FString UpdatedAt;

    ESyncStatus SyncStatus = ESyncStatus::Local;
    int32       Version    = 1;  // Optimistic locking counter for DynamoDB

    FGrimoireEntityBase()
        : SyncStatus(ESyncStatus::Local)
        , Version(1)
    {}

    virtual ~FGrimoireEntityBase() = default;
};


// ============================================================
//  ASSET REFERENCE
//  Lightweight pointer to an S3-backed binary asset.
//  Embedded directly in entry structs.
// ============================================================
struct FGrimoireAssetRef
{
    FString   AssetID;
    EAssetType AssetType    = EAssetType::Image;
    FString   S3Key;         // Path within the user's S3 prefix
    FString   FileName;      // Human-readable name for display
    FString   Caption;
    int64     FileSizeBytes = 0;

    FGrimoireAssetRef()
        : AssetType(EAssetType::Image)
        , FileSizeBytes(0)
    {}
};
