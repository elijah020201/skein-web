#pragma once

#include "CoreMinimal.h"
#include "GrimoireTypes.h"

// ============================================================
//  GRIMOIRE APP — User & Account Data Model
//  GrimoireUser.h
//  Pure C++ — no Blueprint reflection macros.
// ============================================================


// ------------------------------------------------------------
//  User Preferences
// ------------------------------------------------------------
struct FGrimoireUserPreferences
{
    FString          ThemeName                  = TEXT("DarkOccult");
    bool             bShowMoonPhaseOnJournal    = true;
    bool             bAutoPopulateAstroData     = true;
    EEntryVisibility DefaultVisibility          = EEntryVisibility::Private;
    FString          DateFormat                 = TEXT("DD MMM YYYY");

    // User's primary tradition — used to suggest relevant correspondences
    // e.g. "Wicca", "Thelema", "Chaos Magic", "Hellenic"
    FString TraditionPath;

    FGrimoireUserPreferences()
        : DefaultVisibility(EEntryVisibility::Private)
    {}
};


// ------------------------------------------------------------
//  Grimoire User
//  Top-level user entity. Linked 1:1 with a Cognito identity.
// ------------------------------------------------------------
struct FGrimoireUser : public FGrimoireEntityBase
{
    FString CognitoSub;     // Immutable Cognito 'sub' claim
    FString DisplayName;
    FString Email;

    FGrimoireAssetRef        AvatarAsset;
    FGrimoireUserPreferences Preferences;

    // Names of custom entry types this user has defined
    TArray<FString> CustomEntryTypeNames;

    // S3 prefix for this user's assets: "users/{CognitoSub}/assets/"
    FString S3AssetPrefix;

    // Total asset storage consumed in bytes (tracked server-side)
    int64 StorageUsedBytes = 0;

    // Stub for future coven membership — intentionally empty for now
    TArray<FString> CovenIDs;

    FGrimoireUser()
        : StorageUsedBytes(0)
    {}
};
