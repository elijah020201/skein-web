#pragma once

#include "CoreMinimal.h"
#include "GrimoireTypes.h"

// ============================================================
//  GRIMOIRE APP — Entry Template Structs
//  GrimoireEntryTemplates.h
//
//  One struct per entry type. The parent GrimoireEntry holds
//  whichever template is active based on EGrimoireEntryType.
//  Pure C++ — no Blueprint reflection macros.
// ============================================================


// ============================================================
//  SPELL
// ============================================================
struct FSpellTemplate
{
    FString         Intent;
    TArray<FString> Ingredients;
    TArray<FString> Tools;
    FString         Instructions;
    FString         Incantation;
    TArray<EElement> ElementalAssociations;
    EMoonPhase      BestMoonPhase  = EMoonPhase::Unknown;
    FString         BestDayOfWeek;
    FString         ExpectedOutcome;
    FString         ResultsNotes;
    TArray<FGrimoireAssetRef> Assets;

    FSpellTemplate()
        : BestMoonPhase(EMoonPhase::Unknown)
    {}
};


// ============================================================
//  RITUAL
// ============================================================
struct FRitualTemplate
{
    FString         Purpose;
    FString         Tradition;
    TArray<FString> Participants;
    FString         CircleCastingMethod;
    TArray<FString> QuarterCalls;       // N / E / S / W invocations
    TArray<FString> DeitiesInvoked;
    TArray<FString> ToolsUsed;
    FString         RitualBody;         // Main working / script
    FString         ClosingMethod;
    EMoonPhase      MoonPhasePerformed = EMoonPhase::Unknown;
    FString         DatePerformed;      // ISO 8601
    FString         Outcome;
    TArray<FGrimoireAssetRef> Assets;

    FRitualTemplate()
        : MoonPhasePerformed(EMoonPhase::Unknown)
    {}
};


// ============================================================
//  JOURNAL / BOOK OF SHADOWS
// ============================================================
struct FJournalTemplate
{
    FString    EntryDate;           // ISO 8601
    EMoonPhase MoonPhase  = EMoonPhase::Unknown;
    FString    SunSign;
    FString    MoonSign;
    FString    CurrentTransits;
    FString    DreamRecord;
    FString    OmensSigns;          // Synchronicities, omens noticed
    FString    PracticeNotes;
    FString    ReflectionBody;      // Main free-form body
    FString    MoodEnergy;          // e.g. "High", "Grounded", "Scattered"
    TArray<FGrimoireAssetRef> Assets;

    FJournalTemplate()
        : MoonPhase(EMoonPhase::Unknown)
    {}
};


// ============================================================
//  HERBAL CORRESPONDENCE
// ============================================================
struct FHerbalCorrespondenceTemplate
{
    FString          CommonName;
    FString          LatinName;
    TArray<FString>  OtherNames;            // Folk names, regional names
    TArray<EElement> ElementalAssociations;
    FString          PlanetaryRuler;        // e.g. "Venus", "Saturn"
    TArray<FString>  MagicalProperties;     // e.g. "protection", "love"
    TArray<FString>  HealingProperties;
    FString          UsageNotes;
    FString          Cautions;              // Toxicity, contraindications
    FString          PersonalNotes;
    TArray<FGrimoireAssetRef> Assets;
};


// ============================================================
//  SIGIL & SYMBOL
// ============================================================
struct FSigilTemplate
{
    FString    Intent;
    FString    CreationMethod;      // e.g. "letter elimination", "automatic drawing"
    FString    ChargingMethod;
    FString    DestructionMethod;
    FString    DateCreated;         // ISO 8601
    EMoonPhase MoonPhaseCreated = EMoonPhase::Unknown;
    FString    Outcome;
    FString    Notes;
    TArray<FGrimoireAssetRef> Assets;   // The sigil image lives here

    FSigilTemplate()
        : MoonPhaseCreated(EMoonPhase::Unknown)
    {}
};


// ============================================================
//  ASTROLOGICAL DATA
// ============================================================
struct FAstrologicalTemplate
{
    FString         EventDate;              // ISO 8601
    FString         EventType;             // e.g. "Full Moon", "Eclipse", "Ingress"
    FString         PlanetaryPositions;    // JSON string for structured data
    TArray<FString> ActiveAspects;         // e.g. "Mercury conjunct Venus"
    TArray<FString> ActiveRetrogrades;
    EMoonPhase      MoonPhase  = EMoonPhase::Unknown;
    FString         MoonSign;
    FString         RisingSign;
    FString         Interpretation;
    FString         EnergyForecast;
    TArray<FGrimoireAssetRef> Assets;

    FAstrologicalTemplate()
        : MoonPhase(EMoonPhase::Unknown)
    {}
};


// ============================================================
//  TAROT / DIVINATION LOG
// ============================================================

struct FTarotCardPull
{
    FString          CardName;
    int32            PositionIndex = 0;
    FString          PositionLabel;         // e.g. "Past", "Present", "Future"
    ECardOrientation Orientation  = ECardOrientation::Upright;
    FString          Interpretation;

    FTarotCardPull()
        : PositionIndex(0)
        , Orientation(ECardOrientation::Upright)
    {}
};

struct FTarotLogTemplate
{
    FString              ReadingDate;
    FString              Question;
    ETarotSpread         SpreadType      = ETarotSpread::ThreeCard;
    FString              CustomSpreadName;
    FString              DeckUsed;
    TArray<FTarotCardPull> CardsDrawn;
    FString              OverallInterpretation;
    EMoonPhase           MoonPhase       = EMoonPhase::Unknown;
    FString              Outcome;
    TArray<FGrimoireAssetRef> Assets;

    FTarotLogTemplate()
        : SpreadType(ETarotSpread::ThreeCard)
        , MoonPhase(EMoonPhase::Unknown)
    {}
};


// ============================================================
//  CUSTOM USER-DEFINED
//  Flexible key-value field list for user-created types.
// ============================================================

struct FCustomField
{
    FString FieldKey;
    FString FieldValue;
    FString FieldType;  // "text" | "number" | "date" | "boolean"
};

struct FCustomTemplate
{
    FString              TypeName;   // Maps to FGrimoireUser::CustomEntryTypeNames
    TArray<FCustomField> Fields;
    FString              Notes;
    TArray<FGrimoireAssetRef> Assets;
};
