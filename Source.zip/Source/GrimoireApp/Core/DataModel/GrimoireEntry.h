#pragma once

#include "CoreMinimal.h"
#include "GrimoireTypes.h"
#include "GrimoireEntryTemplates.h"

// ============================================================
//  GRIMOIRE APP — Master Entry & Collection
//  GrimoireEntry.h
//
//  FGrimoireEntry is the primary content unit stored in
//  DynamoDB. One active template per entry, selected by type.
//
//  FGrimoireCollection is a named grouping of entries.
//  Pure C++ — no Blueprint reflection macros.
// ============================================================


// ============================================================
//  GRIMOIRE ENTRY
// ============================================================
struct FGrimoireEntry : public FGrimoireEntityBase
{
    // --------------------------------------------------------
    //  Universal fields — present on every entry
    // --------------------------------------------------------
    FString              Title;
    EGrimoireEntryType   EntryType   = EGrimoireEntryType::JournalEntry;
    TArray<FString>      Tags;
    EEntryVisibility     Visibility  = EEntryVisibility::Private;
    FString              CollectionID;
    bool                 bIsPinned   = false;
    bool                 bIsFavourite = false;
    bool                 bIsDeleted  = false;

    // --------------------------------------------------------
    //  Template data
    //  Only one is populated per entry — chosen by EntryType.
    //  Inactive templates remain default/empty.
    //  Note: Unreal USTRUCT doesn't support unions, so all are
    //  present as plain members. EntryType is the discriminator.
    // --------------------------------------------------------
    FSpellTemplate               SpellData;
    FRitualTemplate              RitualData;
    FJournalTemplate             JournalData;
    FHerbalCorrespondenceTemplate HerbalData;
    FSigilTemplate               SigilData;
    FAstrologicalTemplate        AstrologicalData;
    FTarotLogTemplate            TarotData;
    FCustomTemplate              CustomData;

    // --------------------------------------------------------
    //  Helpers
    // --------------------------------------------------------

    /** Returns false if the entry has no meaningful content. */
    bool HasContent() const { return !Title.IsEmpty(); }

    /** Returns a display-friendly string for the entry type. */
    FString GetTypeDisplayName() const
    {
        switch (EntryType)
        {
            case EGrimoireEntryType::Spell:               return TEXT("Spell");
            case EGrimoireEntryType::Ritual:              return TEXT("Ritual");
            case EGrimoireEntryType::JournalEntry:        return TEXT("Journal Entry");
            case EGrimoireEntryType::HerbalCorrespondence:return TEXT("Herbal Correspondence");
            case EGrimoireEntryType::Sigil:               return TEXT("Sigil & Symbol");
            case EGrimoireEntryType::AstrologicalData:    return TEXT("Astrological Data");
            case EGrimoireEntryType::TarotLog:            return TEXT("Tarot Log");
            case EGrimoireEntryType::Custom:              return TEXT("Custom");
            default:                                       return TEXT("Unknown");
        }
    }

    FGrimoireEntry()
        : EntryType(EGrimoireEntryType::JournalEntry)
        , Visibility(EEntryVisibility::Private)
        , bIsPinned(false)
        , bIsFavourite(false)
        , bIsDeleted(false)
    {}
};


// ============================================================
//  GRIMOIRE COLLECTION
//  A named group / "book" that organises entries.
//  Stored as its own DynamoDB item.
// ============================================================
struct FGrimoireCollection : public FGrimoireEntityBase
{
    FString Name;
    FString Description;

    FGrimoireAssetRef          CoverImage;
    FString                    AccentColor = TEXT("#8B1A4A");  // Deep crimson default

    // Ordered list of EntryIDs in this collection
    TArray<FString>            EntryIDs;

    // Restricts which types can be added — empty means all allowed
    TArray<EGrimoireEntryType> AllowedEntryTypes;

    bool bIsPinned = false;

    FGrimoireCollection()
        : AccentColor(TEXT("#8B1A4A"))
        , bIsPinned(false)
    {}
};
