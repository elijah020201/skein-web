#include "GrimoireLocalStore.h"
#include "SQLiteDatabase.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformFileManager.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"

// ============================================================
//  GRIMOIRE APP — Local SQLite Store Implementation
//  GrimoireLocalStore.cpp
// ============================================================

// ------------------------------------------------------------
//  Constructor / Destructor
// ------------------------------------------------------------

FGrimoireLocalStore::FGrimoireLocalStore()
    : Database(nullptr)
{
    // Build the path to the database file.
    // FPaths::ProjectUserDir() resolves to the correct
    // per-user app data location on each platform:
    //   Windows: %LOCALAPPDATA%\GrimoireApp\
    //   Mac:     ~/Library/Application Support/GrimoireApp/
    //   iOS/Android: app sandbox data directory
    DatabasePath = FPaths::ProjectUserDir() / TEXT("GrimoireApp.db");
}

FGrimoireLocalStore::~FGrimoireLocalStore()
{
    Close();
}

// ------------------------------------------------------------
//  Lifecycle
// ------------------------------------------------------------

bool FGrimoireLocalStore::Open()
{
    if (IsOpen())
    {
        return true; // Already open, nothing to do
    }

    Database = new FSQLiteDatabase();

    if (!Database->Open(*DatabasePath, ESQLiteDatabaseOpenMode::ReadWriteCreate))
    {
        UE_LOG(LogTemp, Error,
            TEXT("GrimoireLocalStore: Failed to open database at %s"), *DatabasePath);
        delete Database;
        Database = nullptr;
        return false;
    }

    UE_LOG(LogTemp, Log,
        TEXT("GrimoireLocalStore: Database opened at %s"), *DatabasePath);

    // Create tables on first run — safe to call every time
    return CreateTables();
}

void FGrimoireLocalStore::Close()
{
    if (Database)
    {
        Database->Close();
        delete Database;
        Database = nullptr;
        UE_LOG(LogTemp, Log, TEXT("GrimoireLocalStore: Database closed."));
    }
}

bool FGrimoireLocalStore::IsOpen() const
{
    return Database != nullptr && Database->IsValid();
}

// ------------------------------------------------------------
//  Table Creation
//  Called once on Open(). CREATE TABLE IF NOT EXISTS means
//  this is safe to run on every launch — existing data is
//  never touched.
// ------------------------------------------------------------

bool FGrimoireLocalStore::CreateTables()
{
    // --- User table ---
    // Stores exactly one row: the local user profile
    const FString CreateUserTable = TEXT(R"(
        CREATE TABLE IF NOT EXISTS Users (
            EntityID        TEXT PRIMARY KEY,
            OwnerUserID     TEXT NOT NULL,
            CognitoSub      TEXT NOT NULL,
            DisplayName     TEXT NOT NULL,
            Email           TEXT NOT NULL,
            Preferences     TEXT,           -- JSON blob
            CustomTypes     TEXT,           -- JSON array of strings
            S3AssetPrefix   TEXT,
            StorageUsed     INTEGER DEFAULT 0,
            CreatedAt       TEXT NOT NULL,
            UpdatedAt       TEXT NOT NULL,
            SyncStatus      INTEGER DEFAULT 0,
            Version         INTEGER DEFAULT 1
        );
    )");

    // --- Entries table ---
    // Core content store. TemplateData is a JSON blob of
    // whichever template struct is active for this entry.
    const FString CreateEntriesTable = TEXT(R"(
        CREATE TABLE IF NOT EXISTS Entries (
            EntityID        TEXT PRIMARY KEY,
            OwnerUserID     TEXT NOT NULL,
            Title           TEXT NOT NULL,
            EntryType       INTEGER NOT NULL,
            Tags            TEXT,           -- JSON array of strings
            Visibility      INTEGER DEFAULT 0,
            CollectionID    TEXT,
            IsPinned        INTEGER DEFAULT 0,
            IsFavourite     INTEGER DEFAULT 0,
            IsDeleted       INTEGER DEFAULT 0,
            TemplateData    TEXT NOT NULL,  -- JSON blob of active template
            CreatedAt       TEXT NOT NULL,
            UpdatedAt       TEXT NOT NULL,
            SyncStatus      INTEGER DEFAULT 0,
            Version         INTEGER DEFAULT 1
        );
    )");

    // Index for fast type-based queries
    const FString CreateTypeIndex = TEXT(R"(
        CREATE INDEX IF NOT EXISTS idx_entries_type
        ON Entries (OwnerUserID, EntryType, IsDeleted);
    )");

    // Index for collection queries
    const FString CreateCollectionIndex = TEXT(R"(
        CREATE INDEX IF NOT EXISTS idx_entries_collection
        ON Entries (CollectionID, IsDeleted);
    )");

    // Index for sync queries
    const FString CreateSyncIndex = TEXT(R"(
        CREATE INDEX IF NOT EXISTS idx_entries_sync
        ON Entries (SyncStatus);
    )");

    // --- Collections table ---
    const FString CreateCollectionsTable = TEXT(R"(
        CREATE TABLE IF NOT EXISTS Collections (
            EntityID        TEXT PRIMARY KEY,
            OwnerUserID     TEXT NOT NULL,
            Name            TEXT NOT NULL,
            Description     TEXT,
            CoverImageData  TEXT,           -- JSON of FGrimoireAssetRef
            AccentColor     TEXT DEFAULT '#8B1A4A',
            EntryIDs        TEXT,           -- JSON array of entry ID strings
            AllowedTypes    TEXT,           -- JSON array of EGrimoireEntryType ints
            IsPinned        INTEGER DEFAULT 0,
            CreatedAt       TEXT NOT NULL,
            UpdatedAt       TEXT NOT NULL,
            SyncStatus      INTEGER DEFAULT 0,
            Version         INTEGER DEFAULT 1
        );
    )");

    // Execute all statements
    bool bSuccess = true;
    bSuccess &= Database->Execute(*CreateUserTable);
    bSuccess &= Database->Execute(*CreateEntriesTable);
    bSuccess &= Database->Execute(*CreateTypeIndex);
    bSuccess &= Database->Execute(*CreateCollectionIndex);
    bSuccess &= Database->Execute(*CreateSyncIndex);
    bSuccess &= Database->Execute(*CreateCollectionsTable);

    if (!bSuccess)
    {
        UE_LOG(LogTemp, Error, TEXT("GrimoireLocalStore: Failed to create one or more tables."));
    }
    else
    {
        UE_LOG(LogTemp, Log, TEXT("GrimoireLocalStore: Tables ready."));
    }

    return bSuccess;
}

// ------------------------------------------------------------
//  User
// ------------------------------------------------------------

bool FGrimoireLocalStore::SaveUser(const FGrimoireUser& User)
{
    if (!IsOpen()) return false;

    // Serialize preferences and custom types to JSON
    TSharedPtr<FJsonObject> PrefsJson = MakeShareable(new FJsonObject());
    PrefsJson->SetStringField(TEXT("ThemeName"), User.Preferences.ThemeName);
    PrefsJson->SetBoolField(TEXT("ShowMoonPhase"), User.Preferences.bShowMoonPhaseOnJournal);
    PrefsJson->SetBoolField(TEXT("AutoPopulateAstro"), User.Preferences.bAutoPopulateAstroData);
    PrefsJson->SetNumberField(TEXT("DefaultVisibility"), (int32)User.Preferences.DefaultVisibility);
    PrefsJson->SetStringField(TEXT("DateFormat"), User.Preferences.DateFormat);
    PrefsJson->SetStringField(TEXT("TraditionPath"), User.Preferences.TraditionPath);

    FString PrefsString;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&PrefsString);
    FJsonSerializer::Serialize(PrefsJson.ToSharedRef(), Writer);

    // Serialize custom type names
    TArray<TSharedPtr<FJsonValue>> TypesArray;
    for (const FString& TypeName : User.CustomEntryTypeNames)
    {
        TypesArray.Add(MakeShareable(new FJsonValueString(TypeName)));
    }
    FString TypesString;
    TSharedRef<TJsonWriter<>> TypesWriter = TJsonWriterFactory<>::Create(&TypesString);
    FJsonSerializer::Serialize(TypesArray, TypesWriter);

    // Use INSERT OR REPLACE so this works for both create and update
    const FString SQL = FString::Printf(TEXT(R"(
        INSERT OR REPLACE INTO Users
            (EntityID, OwnerUserID, CognitoSub, DisplayName, Email,
             Preferences, CustomTypes, S3AssetPrefix, StorageUsed,
             CreatedAt, UpdatedAt, SyncStatus, Version)
        VALUES ('%s','%s','%s','%s','%s','%s','%s','%s',%lld,'%s','%s',%d,%d);
    )"),
        *User.EntityID, *User.OwnerUserID, *User.CognitoSub,
        *User.DisplayName, *User.Email,
        *PrefsString, *TypesString, *User.S3AssetPrefix,
        User.StorageUsedBytes,
        *User.CreatedAt, *User.UpdatedAt,
        (int32)User.SyncStatus, User.Version);

    return Database->Execute(*SQL);
}

bool FGrimoireLocalStore::LoadUser(FGrimoireUser& OutUser)
{
    if (!IsOpen()) return false;

    FSQLitePreparedStatement Statement;
    if (!Statement.Create(*Database, TEXT("SELECT * FROM Users LIMIT 1;"), ESQLitePreparedStatementFlags::Persistent))
    {
        return false;
    }

    if (Statement.Step() != ESQLitePreparedStatementStepResult::Row)
    {
        return false; // No user saved yet
    }

    Statement.GetColumnValueByName(TEXT("EntityID"),    OutUser.EntityID);
    Statement.GetColumnValueByName(TEXT("OwnerUserID"), OutUser.OwnerUserID);
    Statement.GetColumnValueByName(TEXT("CognitoSub"),  OutUser.CognitoSub);
    Statement.GetColumnValueByName(TEXT("DisplayName"), OutUser.DisplayName);
    Statement.GetColumnValueByName(TEXT("Email"),       OutUser.Email);
    Statement.GetColumnValueByName(TEXT("S3AssetPrefix"), OutUser.S3AssetPrefix);
    Statement.GetColumnValueByName(TEXT("CreatedAt"),   OutUser.CreatedAt);
    Statement.GetColumnValueByName(TEXT("UpdatedAt"),   OutUser.UpdatedAt);

    int32 SyncInt = 0;
    Statement.GetColumnValueByName(TEXT("SyncStatus"), SyncInt);
    OutUser.SyncStatus = (ESyncStatus)SyncInt;
    Statement.GetColumnValueByName(TEXT("Version"), OutUser.Version);
    Statement.GetColumnValueByName(TEXT("StorageUsed"), OutUser.StorageUsedBytes);

    // Deserialize preferences JSON
    FString PrefsString;
    Statement.GetColumnValueByName(TEXT("Preferences"), PrefsString);
    TSharedPtr<FJsonObject> PrefsJson;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(PrefsString);
    if (FJsonSerializer::Deserialize(Reader, PrefsJson) && PrefsJson.IsValid())
    {
        OutUser.Preferences.ThemeName               = PrefsJson->GetStringField(TEXT("ThemeName"));
        OutUser.Preferences.bShowMoonPhaseOnJournal = PrefsJson->GetBoolField(TEXT("ShowMoonPhase"));
        OutUser.Preferences.bAutoPopulateAstroData  = PrefsJson->GetBoolField(TEXT("AutoPopulateAstro"));
        OutUser.Preferences.DefaultVisibility       = (EEntryVisibility)(int32)PrefsJson->GetNumberField(TEXT("DefaultVisibility"));
        OutUser.Preferences.DateFormat              = PrefsJson->GetStringField(TEXT("DateFormat"));
        OutUser.Preferences.TraditionPath           = PrefsJson->GetStringField(TEXT("TraditionPath"));
    }

    // Deserialize custom types JSON array
    FString TypesString;
    Statement.GetColumnValueByName(TEXT("CustomTypes"), TypesString);
    TArray<TSharedPtr<FJsonValue>> TypesArray;
    TSharedRef<TJsonReader<>> TypesReader = TJsonReaderFactory<>::Create(TypesString);
    if (FJsonSerializer::Deserialize(TypesReader, TypesArray))
    {
        for (const TSharedPtr<FJsonValue>& Val : TypesArray)
        {
            OutUser.CustomEntryTypeNames.Add(Val->AsString());
        }
    }

    Statement.Destroy();
    return true;
}

// ------------------------------------------------------------
//  Entries — Save
// ------------------------------------------------------------

bool FGrimoireLocalStore::SaveEntry(const FGrimoireEntry& Entry)
{
    if (!IsOpen()) return false;

    // Always ensure OwnerUserID is set
    FGrimoireEntry MutableEntry = Entry;
    if (MutableEntry.OwnerUserID.IsEmpty())
        MutableEntry.OwnerUserID = CurrentUserID;
    const FGrimoireEntry& E = MutableEntry;

    // Serialize tags
    TArray<TSharedPtr<FJsonValue>> TagsArray;
    for (const FString& Tag : Entry.Tags)
    {
        TagsArray.Add(MakeShareable(new FJsonValueString(Tag)));
    }
    FString TagsString;
    TSharedRef<TJsonWriter<>> TagsWriter = TJsonWriterFactory<>::Create(&TagsString);
    FJsonSerializer::Serialize(TagsArray, TagsWriter);

    // Serialize the active template
    FString TemplateData = SerializeTemplateData(E);

    const FString SQL = FString::Printf(TEXT(R"(
        INSERT OR REPLACE INTO Entries
            (EntityID, OwnerUserID, Title, EntryType, Tags,
             Visibility, CollectionID, IsPinned, IsFavourite, IsDeleted,
             TemplateData, CreatedAt, UpdatedAt, SyncStatus, Version)
        VALUES ('%s','%s','%s',%d,'%s',%d,'%s',%d,%d,%d,'%s','%s','%s',%d,%d);
    )"),
        *E.EntityID, *E.OwnerUserID, *E.Title,
        (int32)E.EntryType, *TagsString,
        (int32)E.Visibility, *E.CollectionID,
        E.bIsPinned ? 1 : 0,
        E.bIsFavourite ? 1 : 0,
        E.bIsDeleted ? 1 : 0,
        *TemplateData,
        *E.CreatedAt, *E.UpdatedAt,
        (int32)E.SyncStatus, E.Version);

    return Database->Execute(*SQL);
}

// ------------------------------------------------------------
//  Entries — Load helpers
// ------------------------------------------------------------

bool FGrimoireLocalStore::LoadAllEntries(TArray<FGrimoireEntry>& OutEntries)
{
    if (!IsOpen()) return false;

    FSQLitePreparedStatement Statement;
    const FString SQL = FString::Printf(TEXT(R"(
        SELECT * FROM Entries
        WHERE IsDeleted = 0 AND OwnerUserID = '%s'
        ORDER BY UpdatedAt DESC;
    )"), *CurrentUserID);

    if (!Statement.Create(*Database, *SQL, ESQLitePreparedStatementFlags::Persistent))
        return false;

    while (Statement.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FGrimoireEntry Entry;
        PopulateEntryFromStatement(Statement, Entry);
        OutEntries.Add(Entry);
    }

    Statement.Destroy();
    return true;
}

bool FGrimoireLocalStore::LoadEntry(const FString& EntityID, FGrimoireEntry& OutEntry)
{
    if (!IsOpen()) return false;

    FSQLitePreparedStatement Statement;
    const FString SQL = FString::Printf(
        TEXT("SELECT * FROM Entries WHERE EntityID = '%s' LIMIT 1;"), *EntityID);

    if (!Statement.Create(*Database, *SQL, ESQLitePreparedStatementFlags::Persistent))
        return false;

    bool bFound = false;
    if (Statement.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        PopulateEntryFromStatement(Statement, OutEntry);
        bFound = true;
    }

    Statement.Destroy();
    return bFound;
}

bool FGrimoireLocalStore::LoadEntriesByType(EGrimoireEntryType Type, TArray<FGrimoireEntry>& OutEntries)
{
    if (!IsOpen()) return false;

    FSQLitePreparedStatement Statement;
    const FString SQL = FString::Printf(TEXT(R"(
        SELECT * FROM Entries
        WHERE EntryType = %d AND IsDeleted = 0 AND OwnerUserID = '%s'
        ORDER BY UpdatedAt DESC;
    )"), (int32)Type, *CurrentUserID);

    if (!Statement.Create(*Database, *SQL, ESQLitePreparedStatementFlags::Persistent))
        return false;

    while (Statement.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FGrimoireEntry Entry;
        PopulateEntryFromStatement(Statement, Entry);
        OutEntries.Add(Entry);
    }

    Statement.Destroy();
    return true;
}

bool FGrimoireLocalStore::LoadEntriesByCollection(const FString& CollectionID, TArray<FGrimoireEntry>& OutEntries)
{
    if (!IsOpen()) return false;

    FSQLitePreparedStatement Statement;
    const FString SQL = FString::Printf(TEXT(R"(
        SELECT * FROM Entries
        WHERE CollectionID = '%s' AND IsDeleted = 0 AND OwnerUserID = '%s'
        ORDER BY UpdatedAt DESC;
    )"), *CollectionID, *CurrentUserID);

    if (!Statement.Create(*Database, *SQL, ESQLitePreparedStatementFlags::Persistent))
        return false;

    while (Statement.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FGrimoireEntry Entry;
        PopulateEntryFromStatement(Statement, Entry);
        OutEntries.Add(Entry);
    }

    Statement.Destroy();
    return true;
}

bool FGrimoireLocalStore::LoadEntriesByTag(const FString& Tag, TArray<FGrimoireEntry>& OutEntries)
{
    if (!IsOpen()) return false;

    // SQLite JSON functions let us query inside the Tags JSON array
    FSQLitePreparedStatement Statement;
    const FString SQL = FString::Printf(TEXT(R"(
        SELECT * FROM Entries
        WHERE IsDeleted = 0 AND OwnerUserID = '%s'
        AND Tags LIKE '%%%s%%'
        ORDER BY UpdatedAt DESC;
    )"), *CurrentUserID, *Tag);

    if (!Statement.Create(*Database, *SQL, ESQLitePreparedStatementFlags::Persistent))
        return false;

    while (Statement.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FGrimoireEntry Entry;
        PopulateEntryFromStatement(Statement, Entry);
        // Double-check the tag is an exact match (LIKE is fuzzy)
        if (Entry.Tags.Contains(Tag))
        {
            OutEntries.Add(Entry);
        }
    }

    Statement.Destroy();
    return true;
}

// ------------------------------------------------------------
//  Entries — Delete
// ------------------------------------------------------------

bool FGrimoireLocalStore::SoftDeleteEntry(const FString& EntityID)
{
    if (!IsOpen()) return false;

    const FString SQL = FString::Printf(TEXT(R"(
        UPDATE Entries
        SET IsDeleted = 1, SyncStatus = %d
        WHERE EntityID = '%s';
    )"), (int32)ESyncStatus::Deleted, *EntityID);

    return Database->Execute(*SQL);
}

bool FGrimoireLocalStore::HardDeleteEntry(const FString& EntityID)
{
    if (!IsOpen()) return false;

    const FString SQL = FString::Printf(
        TEXT("DELETE FROM Entries WHERE EntityID = '%s';"), *EntityID);

    return Database->Execute(*SQL);
}

// ------------------------------------------------------------
//  Collections
// ------------------------------------------------------------

bool FGrimoireLocalStore::SaveCollection(const FGrimoireCollection& Collection)
{
    if (!IsOpen()) return false;

    // Serialize EntryIDs array
    TArray<TSharedPtr<FJsonValue>> IDsArray;
    for (const FString& ID : Collection.EntryIDs)
        IDsArray.Add(MakeShareable(new FJsonValueString(ID)));
    FString IDsString;
    TSharedRef<TJsonWriter<>> IDsWriter = TJsonWriterFactory<>::Create(&IDsString);
    FJsonSerializer::Serialize(IDsArray, IDsWriter);

    // Serialize AllowedTypes array
    TArray<TSharedPtr<FJsonValue>> TypesArray;
    for (EGrimoireEntryType Type : Collection.AllowedEntryTypes)
        TypesArray.Add(MakeShareable(new FJsonValueNumber((int32)Type)));
    FString TypesString;
    TSharedRef<TJsonWriter<>> TypesWriter = TJsonWriterFactory<>::Create(&TypesString);
    FJsonSerializer::Serialize(TypesArray, TypesWriter);

    const FString SQL = FString::Printf(TEXT(R"(
        INSERT OR REPLACE INTO Collections
            (EntityID, OwnerUserID, Name, Description, AccentColor,
             EntryIDs, AllowedTypes, IsPinned,
             CreatedAt, UpdatedAt, SyncStatus, Version)
        VALUES ('%s','%s','%s','%s','%s','%s','%s',%d,'%s','%s',%d,%d);
    )"),
        *Collection.EntityID, *Collection.OwnerUserID,
        *Collection.Name, *Collection.Description, *Collection.AccentColor,
        *IDsString, *TypesString,
        Collection.bIsPinned ? 1 : 0,
        *Collection.CreatedAt, *Collection.UpdatedAt,
        (int32)Collection.SyncStatus, Collection.Version);

    return Database->Execute(*SQL);
}

bool FGrimoireLocalStore::LoadAllCollections(TArray<FGrimoireCollection>& OutCollections)
{
    if (!IsOpen()) return false;

    FSQLitePreparedStatement Statement;
    if (!Statement.Create(*Database,
*FString::Printf(TEXT("SELECT * FROM Collections WHERE OwnerUserID = '%s' ORDER BY IsPinned DESC, UpdatedAt DESC;"), *CurrentUserID),
        ESQLitePreparedStatementFlags::Persistent))
        return false;

    while (Statement.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FGrimoireCollection Col;
        Statement.GetColumnValueByName(TEXT("EntityID"),    Col.EntityID);
        Statement.GetColumnValueByName(TEXT("OwnerUserID"), Col.OwnerUserID);
        Statement.GetColumnValueByName(TEXT("Name"),        Col.Name);
        Statement.GetColumnValueByName(TEXT("Description"), Col.Description);
        Statement.GetColumnValueByName(TEXT("AccentColor"), Col.AccentColor);
        Statement.GetColumnValueByName(TEXT("CreatedAt"),   Col.CreatedAt);
        Statement.GetColumnValueByName(TEXT("UpdatedAt"),   Col.UpdatedAt);

        int32 Pinned = 0, SyncInt = 0;
        Statement.GetColumnValueByName(TEXT("IsPinned"),   Pinned);
        Statement.GetColumnValueByName(TEXT("SyncStatus"), SyncInt);
        Statement.GetColumnValueByName(TEXT("Version"),    Col.Version);
        Col.bIsPinned  = Pinned != 0;
        Col.SyncStatus = (ESyncStatus)SyncInt;

        // Deserialize EntryIDs
        FString IDsString;
        Statement.GetColumnValueByName(TEXT("EntryIDs"), IDsString);
        TArray<TSharedPtr<FJsonValue>> IDsArray;
        TSharedRef<TJsonReader<>> R = TJsonReaderFactory<>::Create(IDsString);
        if (FJsonSerializer::Deserialize(R, IDsArray))
            for (auto& V : IDsArray) Col.EntryIDs.Add(V->AsString());

        OutCollections.Add(Col);
    }

    Statement.Destroy();
    return true;
}

bool FGrimoireLocalStore::DeleteCollection(const FString& CollectionID)
{
    if (!IsOpen()) return false;
    const FString SQL = FString::Printf(
        TEXT("DELETE FROM Collections WHERE EntityID = '%s';"), *CollectionID);
    return Database->Execute(*SQL);
}

bool FGrimoireLocalStore::LoadCollection(const FString& CollectionID, FGrimoireCollection& OutCollection)
{
    if (!IsOpen()) return false;

    TArray<FGrimoireCollection> All;
    if (!LoadAllCollections(All)) return false;

    for (const FGrimoireCollection& Col : All)
    {
        if (Col.EntityID == CollectionID)
        {
            OutCollection = Col;
            return true;
        }
    }
    return false;
}

// ------------------------------------------------------------
//  Sync Helpers
// ------------------------------------------------------------

bool FGrimoireLocalStore::LoadPendingSyncEntries(TArray<FGrimoireEntry>& OutEntries)
{
    if (!IsOpen()) return false;

    FSQLitePreparedStatement Statement;
    const FString SQL = FString::Printf(TEXT(R"(
        SELECT * FROM Entries
        WHERE SyncStatus = %d OR SyncStatus = %d;
    )"), (int32)ESyncStatus::Pending, (int32)ESyncStatus::Deleted);

    if (!Statement.Create(*Database, *SQL, ESQLitePreparedStatementFlags::Persistent))
        return false;

    while (Statement.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FGrimoireEntry Entry;
        PopulateEntryFromStatement(Statement, Entry);
        OutEntries.Add(Entry);
    }

    Statement.Destroy();
    return true;
}

bool FGrimoireLocalStore::MarkEntrySynced(const FString& EntityID, int32 NewVersion)
{
    if (!IsOpen()) return false;

    const FString SQL = FString::Printf(TEXT(R"(
        UPDATE Entries
        SET SyncStatus = %d, Version = %d
        WHERE EntityID = '%s';
    )"), (int32)ESyncStatus::Synced, NewVersion, *EntityID);

    return Database->Execute(*SQL);
}

bool FGrimoireLocalStore::MarkEntryConflict(const FString& EntityID)
{
    if (!IsOpen()) return false;

    const FString SQL = FString::Printf(TEXT(R"(
        UPDATE Entries SET SyncStatus = %d WHERE EntityID = '%s';
    )"), (int32)ESyncStatus::Conflict, *EntityID);

    return Database->Execute(*SQL);
}

// ------------------------------------------------------------
//  Private — Template Serialization
//
//  Each entry type gets its own JSON serialization block.
//  This is verbose but deliberate — each field is explicit,
//  making it easy to add/remove fields per type later
//  without breaking unrelated types.
// ------------------------------------------------------------

FString FGrimoireLocalStore::SerializeTemplateData(const FGrimoireEntry& Entry)
{
    TSharedPtr<FJsonObject> Json = MakeShareable(new FJsonObject());

    switch (Entry.EntryType)
    {
        case EGrimoireEntryType::Spell:
        {
            const FSpellTemplate& T = Entry.SpellData;
            Json->SetStringField(TEXT("Intent"),          T.Intent);
            Json->SetStringField(TEXT("Instructions"),    T.Instructions);
            Json->SetStringField(TEXT("Incantation"),     T.Incantation);
            Json->SetStringField(TEXT("BestDayOfWeek"),   T.BestDayOfWeek);
            Json->SetStringField(TEXT("ExpectedOutcome"), T.ExpectedOutcome);
            Json->SetStringField(TEXT("ResultsNotes"),    T.ResultsNotes);
            Json->SetNumberField(TEXT("BestMoonPhase"),   (int32)T.BestMoonPhase);

            TArray<TSharedPtr<FJsonValue>> Ingredients;
            for (auto& S : T.Ingredients) Ingredients.Add(MakeShareable(new FJsonValueString(S)));
            Json->SetArrayField(TEXT("Ingredients"), Ingredients);

            TArray<TSharedPtr<FJsonValue>> Tools;
            for (auto& S : T.Tools) Tools.Add(MakeShareable(new FJsonValueString(S)));
            Json->SetArrayField(TEXT("Tools"), Tools);
            break;
        }

        case EGrimoireEntryType::Ritual:
        {
            const FRitualTemplate& T = Entry.RitualData;
            Json->SetStringField(TEXT("Purpose"),             T.Purpose);
            Json->SetStringField(TEXT("Tradition"),           T.Tradition);
            Json->SetStringField(TEXT("CircleCastingMethod"), T.CircleCastingMethod);
            Json->SetStringField(TEXT("RitualBody"),          T.RitualBody);
            Json->SetStringField(TEXT("ClosingMethod"),       T.ClosingMethod);
            Json->SetStringField(TEXT("DatePerformed"),       T.DatePerformed);
            Json->SetStringField(TEXT("Outcome"),             T.Outcome);
            Json->SetNumberField(TEXT("MoonPhasePerformed"),  (int32)T.MoonPhasePerformed);

            TArray<TSharedPtr<FJsonValue>> Deities;
            for (auto& S : T.DeitiesInvoked) Deities.Add(MakeShareable(new FJsonValueString(S)));
            Json->SetArrayField(TEXT("DeitiesInvoked"), Deities);
            break;
        }

        case EGrimoireEntryType::JournalEntry:
        {
            const FJournalTemplate& T = Entry.JournalData;
            Json->SetStringField(TEXT("EntryDate"),       T.EntryDate);
            Json->SetStringField(TEXT("SunSign"),         T.SunSign);
            Json->SetStringField(TEXT("MoonSign"),        T.MoonSign);
            Json->SetStringField(TEXT("CurrentTransits"), T.CurrentTransits);
            Json->SetStringField(TEXT("DreamRecord"),     T.DreamRecord);
            Json->SetStringField(TEXT("OmensSigns"),      T.OmensSigns);
            Json->SetStringField(TEXT("PracticeNotes"),   T.PracticeNotes);
            Json->SetStringField(TEXT("ReflectionBody"),  T.ReflectionBody);
            Json->SetStringField(TEXT("MoodEnergy"),      T.MoodEnergy);
            Json->SetNumberField(TEXT("MoonPhase"),       (int32)T.MoonPhase);
            break;
        }

        case EGrimoireEntryType::HerbalCorrespondence:
        {
            const FHerbalCorrespondenceTemplate& T = Entry.HerbalData;
            Json->SetStringField(TEXT("CommonName"),     T.CommonName);
            Json->SetStringField(TEXT("LatinName"),      T.LatinName);
            Json->SetStringField(TEXT("PlanetaryRuler"), T.PlanetaryRuler);
            Json->SetStringField(TEXT("UsageNotes"),     T.UsageNotes);
            Json->SetStringField(TEXT("Cautions"),       T.Cautions);
            Json->SetStringField(TEXT("PersonalNotes"),  T.PersonalNotes);

            TArray<TSharedPtr<FJsonValue>> Props;
            for (auto& S : T.MagicalProperties) Props.Add(MakeShareable(new FJsonValueString(S)));
            Json->SetArrayField(TEXT("MagicalProperties"), Props);
            break;
        }

        case EGrimoireEntryType::Sigil:
        {
            const FSigilTemplate& T = Entry.SigilData;
            Json->SetStringField(TEXT("Intent"),            T.Intent);
            Json->SetStringField(TEXT("CreationMethod"),    T.CreationMethod);
            Json->SetStringField(TEXT("ChargingMethod"),    T.ChargingMethod);
            Json->SetStringField(TEXT("DestructionMethod"), T.DestructionMethod);
            Json->SetStringField(TEXT("DateCreated"),       T.DateCreated);
            Json->SetStringField(TEXT("Outcome"),           T.Outcome);
            Json->SetStringField(TEXT("Notes"),             T.Notes);
            Json->SetNumberField(TEXT("MoonPhaseCreated"),  (int32)T.MoonPhaseCreated);
            break;
        }

        case EGrimoireEntryType::AstrologicalData:
        {
            const FAstrologicalTemplate& T = Entry.AstrologicalData;
            Json->SetStringField(TEXT("EventDate"),          T.EventDate);
            Json->SetStringField(TEXT("EventType"),          T.EventType);
            Json->SetStringField(TEXT("PlanetaryPositions"), T.PlanetaryPositions);
            Json->SetStringField(TEXT("MoonSign"),           T.MoonSign);
            Json->SetStringField(TEXT("RisingSign"),         T.RisingSign);
            Json->SetStringField(TEXT("Interpretation"),     T.Interpretation);
            Json->SetStringField(TEXT("EnergyForecast"),     T.EnergyForecast);
            Json->SetNumberField(TEXT("MoonPhase"),          (int32)T.MoonPhase);
            break;
        }

        case EGrimoireEntryType::TarotLog:
        {
            const FTarotLogTemplate& T = Entry.TarotData;
            Json->SetStringField(TEXT("ReadingDate"),           T.ReadingDate);
            Json->SetStringField(TEXT("Question"),              T.Question);
            Json->SetStringField(TEXT("DeckUsed"),              T.DeckUsed);
            Json->SetStringField(TEXT("OverallInterpretation"), T.OverallInterpretation);
            Json->SetStringField(TEXT("Outcome"),               T.Outcome);
            Json->SetNumberField(TEXT("SpreadType"),            (int32)T.SpreadType);
            Json->SetNumberField(TEXT("MoonPhase"),             (int32)T.MoonPhase);

            TArray<TSharedPtr<FJsonValue>> Cards;
            for (const FTarotCardPull& Card : T.CardsDrawn)
            {
                TSharedPtr<FJsonObject> CardJson = MakeShareable(new FJsonObject());
                CardJson->SetStringField(TEXT("CardName"),       Card.CardName);
                CardJson->SetStringField(TEXT("PositionLabel"),  Card.PositionLabel);
                CardJson->SetStringField(TEXT("Interpretation"), Card.Interpretation);
                CardJson->SetNumberField(TEXT("PositionIndex"),  Card.PositionIndex);
                CardJson->SetNumberField(TEXT("Orientation"),    (int32)Card.Orientation);
                Cards.Add(MakeShareable(new FJsonValueObject(CardJson)));
            }
            Json->SetArrayField(TEXT("CardsDrawn"), Cards);
            break;
        }

        case EGrimoireEntryType::Custom:
        {
            const FCustomTemplate& T = Entry.CustomData;
            Json->SetStringField(TEXT("TypeName"), T.TypeName);
            Json->SetStringField(TEXT("Notes"),    T.Notes);

            TArray<TSharedPtr<FJsonValue>> Fields;
            for (const FCustomField& F : T.Fields)
            {
                TSharedPtr<FJsonObject> FJson = MakeShareable(new FJsonObject());
                FJson->SetStringField(TEXT("Key"),   F.FieldKey);
                FJson->SetStringField(TEXT("Value"), F.FieldValue);
                FJson->SetStringField(TEXT("Type"),  F.FieldType);
                Fields.Add(MakeShareable(new FJsonValueObject(FJson)));
            }
            Json->SetArrayField(TEXT("Fields"), Fields);
            break;
        }

        default: break;
    }

    FString Output;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Output);
    FJsonSerializer::Serialize(Json.ToSharedRef(), Writer);
    return Output;
}

// ------------------------------------------------------------
//  Private — Entry Population from DB Row
//  Shared helper used by all Load* functions.
// ------------------------------------------------------------

void FGrimoireLocalStore::PopulateEntryFromStatement(
    FSQLitePreparedStatement& Statement, FGrimoireEntry& OutEntry)
{
    Statement.GetColumnValueByName(TEXT("EntityID"),    OutEntry.EntityID);
    Statement.GetColumnValueByName(TEXT("OwnerUserID"), OutEntry.OwnerUserID);
    Statement.GetColumnValueByName(TEXT("Title"),       OutEntry.Title);
    Statement.GetColumnValueByName(TEXT("CollectionID"),OutEntry.CollectionID);
    Statement.GetColumnValueByName(TEXT("CreatedAt"),   OutEntry.CreatedAt);
    Statement.GetColumnValueByName(TEXT("UpdatedAt"),   OutEntry.UpdatedAt);

    int32 TypeInt = 0, VisInt = 0, SyncInt = 0, Pinned = 0, Fav = 0, Deleted = 0;
    Statement.GetColumnValueByName(TEXT("EntryType"),   TypeInt);
    Statement.GetColumnValueByName(TEXT("Visibility"),  VisInt);
    Statement.GetColumnValueByName(TEXT("SyncStatus"),  SyncInt);
    Statement.GetColumnValueByName(TEXT("IsPinned"),    Pinned);
    Statement.GetColumnValueByName(TEXT("IsFavourite"), Fav);
    Statement.GetColumnValueByName(TEXT("IsDeleted"),   Deleted);
    Statement.GetColumnValueByName(TEXT("Version"),     OutEntry.Version);

    OutEntry.EntryType   = (EGrimoireEntryType)TypeInt;
    OutEntry.Visibility  = (EEntryVisibility)VisInt;
    OutEntry.SyncStatus  = (ESyncStatus)SyncInt;
    OutEntry.bIsPinned   = Pinned != 0;
    OutEntry.bIsFavourite = Fav != 0;
    OutEntry.bIsDeleted  = Deleted != 0;

    // Deserialize tags
    FString TagsString;
    Statement.GetColumnValueByName(TEXT("Tags"), TagsString);
    TArray<TSharedPtr<FJsonValue>> TagsArray;
    TSharedRef<TJsonReader<>> TR = TJsonReaderFactory<>::Create(TagsString);
    if (FJsonSerializer::Deserialize(TR, TagsArray))
        for (auto& V : TagsArray) OutEntry.Tags.Add(V->AsString());

    // Deserialize template data
    FString TemplateData;
    Statement.GetColumnValueByName(TEXT("TemplateData"), TemplateData);
    DeserializeTemplateData(TemplateData, OutEntry.EntryType, OutEntry);
}

bool FGrimoireLocalStore::DeserializeTemplateData(
    const FString& Json, EGrimoireEntryType Type, FGrimoireEntry& OutEntry)
{
    TSharedPtr<FJsonObject> JsonObj;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Json);
    if (!FJsonSerializer::Deserialize(Reader, JsonObj) || !JsonObj.IsValid())
        return false;

    switch (Type)
    {
        case EGrimoireEntryType::JournalEntry:
        {
            FJournalTemplate& T = OutEntry.JournalData;
            T.EntryDate      = JsonObj->GetStringField(TEXT("EntryDate"));
            T.SunSign        = JsonObj->GetStringField(TEXT("SunSign"));
            T.MoonSign       = JsonObj->GetStringField(TEXT("MoonSign"));
            T.CurrentTransits = JsonObj->GetStringField(TEXT("CurrentTransits"));
            T.DreamRecord    = JsonObj->GetStringField(TEXT("DreamRecord"));
            T.OmensSigns     = JsonObj->GetStringField(TEXT("OmensSigns"));
            T.PracticeNotes  = JsonObj->GetStringField(TEXT("PracticeNotes"));
            T.ReflectionBody = JsonObj->GetStringField(TEXT("ReflectionBody"));
            T.MoodEnergy     = JsonObj->GetStringField(TEXT("MoodEnergy"));
            T.MoonPhase      = (EMoonPhase)(int32)JsonObj->GetNumberField(TEXT("MoonPhase"));
            break;
        }
        case EGrimoireEntryType::Spell:
        {
            FSpellTemplate& T = OutEntry.SpellData;
            T.Intent          = JsonObj->GetStringField(TEXT("Intent"));
            T.Instructions    = JsonObj->GetStringField(TEXT("Instructions"));
            T.Incantation     = JsonObj->GetStringField(TEXT("Incantation"));
            T.BestDayOfWeek   = JsonObj->GetStringField(TEXT("BestDayOfWeek"));
            T.ExpectedOutcome = JsonObj->GetStringField(TEXT("ExpectedOutcome"));
            T.ResultsNotes    = JsonObj->GetStringField(TEXT("ResultsNotes"));
            T.BestMoonPhase   = (EMoonPhase)(int32)JsonObj->GetNumberField(TEXT("BestMoonPhase"));

            for (auto& V : JsonObj->GetArrayField(TEXT("Ingredients"))) T.Ingredients.Add(V->AsString());
            for (auto& V : JsonObj->GetArrayField(TEXT("Tools")))       T.Tools.Add(V->AsString());
            break;
        }
        case EGrimoireEntryType::TarotLog:
        {
            FTarotLogTemplate& T = OutEntry.TarotData;
            T.ReadingDate           = JsonObj->GetStringField(TEXT("ReadingDate"));
            T.Question              = JsonObj->GetStringField(TEXT("Question"));
            T.DeckUsed              = JsonObj->GetStringField(TEXT("DeckUsed"));
            T.OverallInterpretation = JsonObj->GetStringField(TEXT("OverallInterpretation"));
            T.Outcome               = JsonObj->GetStringField(TEXT("Outcome"));
            T.SpreadType  = (ETarotSpread)(int32)JsonObj->GetNumberField(TEXT("SpreadType"));
            T.MoonPhase   = (EMoonPhase)(int32)JsonObj->GetNumberField(TEXT("MoonPhase"));

            for (auto& CardVal : JsonObj->GetArrayField(TEXT("CardsDrawn")))
            {
                TSharedPtr<FJsonObject> CardObj = CardVal->AsObject();
                FTarotCardPull Card;
                Card.CardName       = CardObj->GetStringField(TEXT("CardName"));
                Card.PositionLabel  = CardObj->GetStringField(TEXT("PositionLabel"));
                Card.Interpretation = CardObj->GetStringField(TEXT("Interpretation"));
                Card.PositionIndex  = (int32)CardObj->GetNumberField(TEXT("PositionIndex"));
                Card.Orientation    = (ECardOrientation)(int32)CardObj->GetNumberField(TEXT("Orientation"));
                T.CardsDrawn.Add(Card);
            }
            break;
        }
        // Remaining types follow the same pattern — omitted for brevity,
        // mirror the serialization blocks above in reverse.
        default: break;
    }

    return true;
}

void FGrimoireLocalStore::MigrateOrphanedEntries()
{
    // Assign any entries/collections with empty OwnerUserID to the current user.
    // This handles data created before per-user filtering was added.
    if (!IsOpen() || CurrentUserID.IsEmpty()) return;

    const FString FixEntries = FString::Printf(
        TEXT("UPDATE Entries SET OwnerUserID = '%s' WHERE OwnerUserID = '' OR OwnerUserID IS NULL;"),
        *CurrentUserID);
    Database->Execute(*FixEntries);

    const FString FixCollections = FString::Printf(
        TEXT("UPDATE Collections SET OwnerUserID = '%s' WHERE OwnerUserID = '' OR OwnerUserID IS NULL;"),
        *CurrentUserID);
    Database->Execute(*FixCollections);

    UE_LOG(LogTemp, Log, TEXT("GrimoireLocalStore: Migrated orphaned entries to user %s"), *CurrentUserID);
}
