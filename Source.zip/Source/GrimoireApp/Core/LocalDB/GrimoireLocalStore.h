#pragma once

#include "CoreMinimal.h"
#include "Core/DataModel/GrimoireEntry.h"
#include "Core/DataModel/GrimoireUser.h"
#include "SQLiteDatabase.h"
#include "SQLitePreparedStatement.h"

// ============================================================
//  GRIMOIRE APP — Local SQLite Store
//  GrimoireLocalStore.h
//
//  Handles all reading and writing to the local SQLite
//  database. This is the ONLY place in the codebase that
//  talks directly to the database — everything else goes
//  through this class.
//
//  Think of it as the app's local "source of truth."
//  AWS sync reads from and writes back to this store.
// ============================================================

class GRIMOIREAPP_API FGrimoireLocalStore
{
public:

    FGrimoireLocalStore();
    ~FGrimoireLocalStore();

    // --------------------------------------------------------
    //  Lifecycle
    // --------------------------------------------------------

    /** Opens (or creates) the local database file.
     *  Call this once at app startup before anything else.
     *  Returns true on success. */
    bool Open();

    /** Closes the database connection cleanly.
     *  Call this on app shutdown. */
    void Close();

    /** Returns true if the database is open and ready. */
    bool IsOpen() const;

    // --------------------------------------------------------
    //  User
    // --------------------------------------------------------

    bool SaveUser(const FGrimoireUser& User);

    /** Set the currently logged-in user ID. All load queries will filter by this. */
    void SetCurrentUserID(const FString& InUserID) { CurrentUserID = InUserID; }
    void MigrateOrphanedEntries(); // Call once after SetCurrentUserID on first login
    FString GetCurrentUserID() const { return CurrentUserID; }
    bool LoadUser(FGrimoireUser& OutUser);

    // --------------------------------------------------------
    //  Entries
    // --------------------------------------------------------

    bool SaveEntry(const FGrimoireEntry& Entry);
    bool LoadEntry(const FString& EntityID, FGrimoireEntry& OutEntry);
    bool LoadAllEntries(TArray<FGrimoireEntry>& OutEntries);
    bool LoadEntriesByType(EGrimoireEntryType Type, TArray<FGrimoireEntry>& OutEntries);
    bool LoadEntriesByCollection(const FString& CollectionID, TArray<FGrimoireEntry>& OutEntries);
    bool LoadEntriesByTag(const FString& Tag, TArray<FGrimoireEntry>& OutEntries);

    /** Soft-deletes an entry (sets IsDeleted=true, SyncStatus=Deleted).
     *  Stays in DB until cloud deletion is confirmed, then hard-deleted. */
    bool SoftDeleteEntry(const FString& EntityID);

    /** Hard-deletes an entry. Only call after cloud deletion is confirmed. */
    bool HardDeleteEntry(const FString& EntityID);

    // --------------------------------------------------------
    //  Collections
    // --------------------------------------------------------

    bool SaveCollection(const FGrimoireCollection& Collection);
    bool LoadCollection(const FString& CollectionID, FGrimoireCollection& OutCollection);
    bool LoadAllCollections(TArray<FGrimoireCollection>& OutCollections);
    bool DeleteCollection(const FString& CollectionID);

    // --------------------------------------------------------
    //  Sync helpers
    // --------------------------------------------------------

    /** Returns all entries where SyncStatus == Pending or Deleted.
     *  The sync service calls this to know what needs uploading. */
    bool LoadPendingSyncEntries(TArray<FGrimoireEntry>& OutEntries);

    /** Marks an entry as Synced after a successful cloud write. */
    bool MarkEntrySynced(const FString& EntityID, int32 NewVersion);

    /** Marks an entry as Conflict so the UI can prompt the user. */
    bool MarkEntryConflict(const FString& EntityID);

private:

    // --------------------------------------------------------
    //  Internal helpers
    // --------------------------------------------------------

    /** Creates all tables if they don't exist yet. Safe to call every Open(). */
    bool CreateTables();

    /** Serializes the active template struct to a JSON string for DB storage. */
    FString SerializeTemplateData(const FGrimoireEntry& Entry);

    /** Deserializes TemplateData JSON back into the correct template struct. */
    bool DeserializeTemplateData(const FString& Json,
                                  EGrimoireEntryType Type,
                                  FGrimoireEntry& OutEntry);

    /** Populates an FGrimoireEntry from the current row of a prepared statement.
     *  Shared helper used by all Load* query functions. */
    void PopulateEntryFromStatement(FSQLitePreparedStatement& Statement,
                                     FGrimoireEntry& OutEntry);

    // --------------------------------------------------------
    //  Members
    // --------------------------------------------------------

    FSQLiteDatabase* Database = nullptr;
    FString CurrentUserID; // Filters all load queries — set on login, cleared on logout

    /** Absolute path to the .db file. Resolved in Open(). */
    FString DatabasePath;
};
