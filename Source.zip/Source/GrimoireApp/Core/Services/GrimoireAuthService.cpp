#include "GrimoireAuthService.h"
#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"

// ============================================================
//  GRIMOIRE APP — Authentication Service Implementation
//  GrimoireAuthService.cpp
// ============================================================

FGrimoireAuthService::FGrimoireAuthService()
{
    HttpModule = &FHttpModule::Get();

    // Attempt to restore a previous session on startup
    LoadPersistedTokens();
}

// ------------------------------------------------------------
//  Configuration
// ------------------------------------------------------------

void FGrimoireAuthService::SetConfig(const FString& InUserPoolID, const FString& InClientID)
{
    UserPoolID = InUserPoolID;
    ClientID   = InClientID;

    // Cognito's API endpoint is always this format.
    // The region is extracted from the first part of the UserPoolID
    // e.g. "us-east-1_JfJbA8Guu" → region is "us-east-1"
    FString Region;
    UserPoolID.Split(TEXT("_"), &Region, nullptr);
    CognitoEndpoint = FString::Printf(
        TEXT("https://cognito-idp.%s.amazonaws.com/"), *Region);

    UE_LOG(LogTemp, Log, TEXT("AuthService configured. Endpoint: %s"), *CognitoEndpoint);
}

// ------------------------------------------------------------
//  Registration
// ------------------------------------------------------------

void FGrimoireAuthService::RegisterUser(
    const FString& Email,
    const FString& Password,
    FOnAuthComplete OnComplete)
{
    TSharedPtr<FJsonObject> Payload = MakeShareable(new FJsonObject());
    Payload->SetStringField(TEXT("ClientId"), ClientID);
    Payload->SetStringField(TEXT("Username"), Email);
    Payload->SetStringField(TEXT("Password"), Password);

    // Pass the email as a user attribute
    TSharedPtr<FJsonObject> EmailAttr = MakeShareable(new FJsonObject());
    EmailAttr->SetStringField(TEXT("Name"),  TEXT("email"));
    EmailAttr->SetStringField(TEXT("Value"), Email);

    TArray<TSharedPtr<FJsonValue>> Attrs;
    Attrs.Add(MakeShareable(new FJsonValueObject(EmailAttr)));
    Payload->SetArrayField(TEXT("UserAttributes"), Attrs);

    PostToCognito(TEXT("AWSCognitoIdentityProviderService.SignUp"), Payload,
        [OnComplete](bool bSuccess, TSharedPtr<FJsonObject> ResponseJson)
        {
            FAuthResult Result;
            if (bSuccess)
            {
                Result.bSuccess = true;
                UE_LOG(LogTemp, Log, TEXT("AuthService: Registration successful."));
            }
            else
            {
                Result.bSuccess = false;
                if (ResponseJson.IsValid())
                    Result.ErrorMessage = ResponseJson->GetStringField(TEXT("message"));
                UE_LOG(LogTemp, Warning, TEXT("AuthService: Registration failed: %s"),
                    *Result.ErrorMessage);
            }
            OnComplete.ExecuteIfBound(Result);
        });
}

void FGrimoireAuthService::ConfirmRegistration(
    const FString& Email,
    const FString& ConfirmationCode,
    FOnAuthComplete OnComplete)
{
    TSharedPtr<FJsonObject> Payload = MakeShareable(new FJsonObject());
    Payload->SetStringField(TEXT("ClientId"),         ClientID);
    Payload->SetStringField(TEXT("Username"),         Email);
    Payload->SetStringField(TEXT("ConfirmationCode"), ConfirmationCode);

    PostToCognito(TEXT("AWSCognitoIdentityProviderService.ConfirmSignUp"), Payload,
        [OnComplete](bool bSuccess, TSharedPtr<FJsonObject> ResponseJson)
        {
            FAuthResult Result;
            Result.bSuccess = bSuccess;
            if (!bSuccess && ResponseJson.IsValid())
                Result.ErrorMessage = ResponseJson->GetStringField(TEXT("message"));
            OnComplete.ExecuteIfBound(Result);
        });
}

// ------------------------------------------------------------
//  Login
// ------------------------------------------------------------

void FGrimoireAuthService::Login(
    const FString& Email,
    const FString& Password,
    FOnAuthComplete OnComplete)
{
    TSharedPtr<FJsonObject> Payload = MakeShareable(new FJsonObject());
    Payload->SetStringField(TEXT("AuthFlow"), TEXT("USER_PASSWORD_AUTH"));
    Payload->SetStringField(TEXT("ClientId"), ClientID);

    // Auth parameters
    TSharedPtr<FJsonObject> AuthParams = MakeShareable(new FJsonObject());
    AuthParams->SetStringField(TEXT("USERNAME"), Email);
    AuthParams->SetStringField(TEXT("PASSWORD"), Password);
    Payload->SetObjectField(TEXT("AuthParameters"), AuthParams);

    PostToCognito(TEXT("AWSCognitoIdentityProviderService.InitiateAuth"), Payload,
        [this, OnComplete](bool bSuccess, TSharedPtr<FJsonObject> ResponseJson)
        {
            FAuthResult Result;

            if (bSuccess && ResponseJson.IsValid())
            {
                const TSharedPtr<FJsonObject>* AuthResult = nullptr;
                if (ResponseJson->TryGetObjectField(TEXT("AuthenticationResult"), AuthResult))
                {
                    if (ParseTokensFromResponse(*AuthResult, Result.Tokens))
                    {
                        Result.bSuccess = true;
                        CurrentTokens   = Result.Tokens;
                        bIsLoggedIn     = true;
                        PersistTokens(CurrentTokens);

                        UE_LOG(LogTemp, Log, TEXT("AuthService: Login successful. Sub: %s"),
                            *CurrentTokens.CognitoSub);
                    }
                }
            }

            if (!Result.bSuccess)
            {
                Result.bSuccess = false;
                if (ResponseJson.IsValid())
                    Result.ErrorMessage = ResponseJson->GetStringField(TEXT("message"));
                UE_LOG(LogTemp, Warning, TEXT("AuthService: Login failed: %s"),
                    *Result.ErrorMessage);
            }

            OnComplete.ExecuteIfBound(Result);
        });
}

// ------------------------------------------------------------
//  Token Refresh
// ------------------------------------------------------------

void FGrimoireAuthService::RefreshSession(FOnAuthComplete OnComplete)
{
    if (CurrentTokens.RefreshToken.IsEmpty())
    {
        FAuthResult Result;
        Result.bSuccess      = false;
        Result.ErrorMessage  = TEXT("No refresh token available. User must log in again.");
        OnComplete.ExecuteIfBound(Result);
        return;
    }

    TSharedPtr<FJsonObject> Payload = MakeShareable(new FJsonObject());
    Payload->SetStringField(TEXT("AuthFlow"), TEXT("REFRESH_TOKEN_AUTH"));
    Payload->SetStringField(TEXT("ClientId"), ClientID);

    TSharedPtr<FJsonObject> AuthParams = MakeShareable(new FJsonObject());
    AuthParams->SetStringField(TEXT("REFRESH_TOKEN"), CurrentTokens.RefreshToken);
    Payload->SetObjectField(TEXT("AuthParameters"), AuthParams);

    PostToCognito(TEXT("AWSCognitoIdentityProviderService.InitiateAuth"), Payload,
        [this, OnComplete](bool bSuccess, TSharedPtr<FJsonObject> ResponseJson)
        {
            FAuthResult Result;

            if (bSuccess && ResponseJson.IsValid())
            {
                const TSharedPtr<FJsonObject>* AuthResult = nullptr;
                if (ResponseJson->TryGetObjectField(TEXT("AuthenticationResult"), AuthResult))
                {
                    FAuthTokens NewTokens;
                    if (ParseTokensFromResponse(*AuthResult, NewTokens))
                    {
                        // Refresh flow doesn't return a new refresh token —
                        // keep the existing one
                        NewTokens.RefreshToken = CurrentTokens.RefreshToken;
                        NewTokens.CognitoSub   = CurrentTokens.CognitoSub;

                        Result.bSuccess  = true;
                        Result.Tokens    = NewTokens;
                        CurrentTokens    = NewTokens;
                        PersistTokens(CurrentTokens);

                        UE_LOG(LogTemp, Log, TEXT("AuthService: Token refresh successful."));
                    }
                }
            }

            if (!Result.bSuccess)
            {
                Result.bSuccess     = false;
                if (ResponseJson.IsValid())
                    Result.ErrorMessage = ResponseJson->GetStringField(TEXT("message"));
                UE_LOG(LogTemp, Warning, TEXT("AuthService: Token refresh failed: %s"),
                    *Result.ErrorMessage);
            }

            OnComplete.ExecuteIfBound(Result);
        });
}

// ------------------------------------------------------------
//  Logout
// ------------------------------------------------------------

void FGrimoireAuthService::Logout()
{
    CurrentTokens = FAuthTokens();
    bIsLoggedIn   = false;
    ClearPersistedTokens();
    UE_LOG(LogTemp, Log, TEXT("AuthService: User logged out."));
}

// ------------------------------------------------------------
//  Token Access
// ------------------------------------------------------------

bool FGrimoireAuthService::IsLoggedIn() const
{
    return bIsLoggedIn && !CurrentTokens.AccessToken.IsEmpty();
}

FString FGrimoireAuthService::GetAccessToken() const
{
    return CurrentTokens.AccessToken;
}

FString FGrimoireAuthService::GetCognitoSub() const
{
    return CurrentTokens.CognitoSub;
}

const FAuthTokens& FGrimoireAuthService::GetCurrentTokens() const
{
    return CurrentTokens;
}

// ------------------------------------------------------------
//  Internal — HTTP
// ------------------------------------------------------------

void FGrimoireAuthService::PostToCognito(
    const FString& Action,
    const TSharedPtr<FJsonObject>& Payload,
    TFunction<void(bool, TSharedPtr<FJsonObject>)> OnResponse)
{
    // Serialize payload to JSON string
    FString BodyString;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&BodyString);
    FJsonSerializer::Serialize(Payload.ToSharedRef(), Writer);

    // Build the HTTP request
    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = HttpModule->CreateRequest();
    Request->SetURL(CognitoEndpoint);
    Request->SetVerb(TEXT("POST"));

    // Cognito uses a custom header to specify the action
    // rather than separate URL endpoints
    Request->SetHeader(TEXT("Content-Type"),  TEXT("application/x-amz-json-1.1"));
    Request->SetHeader(TEXT("X-Amz-Target"), Action);
    Request->SetContentAsString(BodyString);

    // Bind the response callback
    Request->OnProcessRequestComplete().BindLambda(
        [OnResponse](FHttpRequestPtr Req, FHttpResponsePtr Resp, bool bConnected)
        {
            if (!bConnected || !Resp.IsValid())
            {
                UE_LOG(LogTemp, Error, TEXT("AuthService: No response from Cognito."));
                OnResponse(false, nullptr);
                return;
            }

            const FString ResponseBody = Resp->GetContentAsString();
            TSharedPtr<FJsonObject> JsonResponse;
            TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ResponseBody);
            FJsonSerializer::Deserialize(Reader, JsonResponse);

            // Cognito returns 2xx for success, 4xx for auth errors
            const bool bSuccess = Resp->GetResponseCode() >= 200
                                && Resp->GetResponseCode() < 300;

            OnResponse(bSuccess, JsonResponse);
        });

    Request->ProcessRequest();
}

// ------------------------------------------------------------
//  Internal — Token Parsing
// ------------------------------------------------------------

bool FGrimoireAuthService::ParseTokensFromResponse(
    const TSharedPtr<FJsonObject>& ResponseJson,
    FAuthTokens& OutTokens)
{
    if (!ResponseJson.IsValid()) return false;

    OutTokens.AccessToken  = ResponseJson->GetStringField(TEXT("AccessToken"));
    OutTokens.IdToken      = ResponseJson->GetStringField(TEXT("IdToken"));
    OutTokens.ExpiresIn    = (int32)ResponseJson->GetNumberField(TEXT("ExpiresIn"));

    // Refresh token is only present on full login, not on refresh
    FString RefreshToken;
    if (ResponseJson->TryGetStringField(TEXT("RefreshToken"), RefreshToken))
        OutTokens.RefreshToken = RefreshToken;

    // Decode the sub from the IdToken (it's a JWT — middle section is base64 payload)
    // We extract it without a full JWT library by splitting on '.' and decoding
    TArray<FString> JwtParts;
    OutTokens.IdToken.ParseIntoArray(JwtParts, TEXT("."));
    if (JwtParts.Num() >= 2)
    {
        // Add padding if needed for base64 decode
        FString Payload = JwtParts[1];
        while (Payload.Len() % 4 != 0) Payload += TEXT("=");

        TArray<uint8> DecodedBytes;
        FBase64::Decode(Payload, DecodedBytes);
        FString DecodedString = FString(UTF8_TO_TCHAR(
            reinterpret_cast<const char*>(DecodedBytes.GetData())));

        TSharedPtr<FJsonObject> Claims;
        TSharedRef<TJsonReader<>> ClaimsReader = TJsonReaderFactory<>::Create(DecodedString);
        if (FJsonSerializer::Deserialize(ClaimsReader, Claims) && Claims.IsValid())
        {
            OutTokens.CognitoSub = Claims->GetStringField(TEXT("sub"));
        }
    }

    return !OutTokens.AccessToken.IsEmpty();
}

// ------------------------------------------------------------
//  Internal — Token Persistence
//  Tokens are saved to a small JSON file in the user's app
//  data directory so the session survives app restarts.
//  Note: In a shipping app you'd use the OS keychain instead.
// ------------------------------------------------------------

void FGrimoireAuthService::PersistTokens(const FAuthTokens& Tokens)
{
    TSharedPtr<FJsonObject> Json = MakeShareable(new FJsonObject());
    Json->SetStringField(TEXT("AccessToken"),  Tokens.AccessToken);
    Json->SetStringField(TEXT("IdToken"),      Tokens.IdToken);
    Json->SetStringField(TEXT("RefreshToken"), Tokens.RefreshToken);
    Json->SetStringField(TEXT("CognitoSub"),   Tokens.CognitoSub);
    Json->SetNumberField(TEXT("ExpiresIn"),    Tokens.ExpiresIn);

    FString JsonString;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonString);
    FJsonSerializer::Serialize(Json.ToSharedRef(), Writer);

    const FString TokenPath = FPaths::ProjectUserDir() / TEXT("session.json");
    FFileHelper::SaveStringToFile(JsonString, *TokenPath);
}

bool FGrimoireAuthService::LoadPersistedTokens()
{
    const FString TokenPath = FPaths::ProjectUserDir() / TEXT("session.json");
    FString JsonString;

    if (!FFileHelper::LoadFileToString(JsonString, *TokenPath))
        return false;

    TSharedPtr<FJsonObject> Json;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
    if (!FJsonSerializer::Deserialize(Reader, Json) || !Json.IsValid())
        return false;

    CurrentTokens.AccessToken  = Json->GetStringField(TEXT("AccessToken"));
    CurrentTokens.IdToken      = Json->GetStringField(TEXT("IdToken"));
    CurrentTokens.RefreshToken = Json->GetStringField(TEXT("RefreshToken"));
    CurrentTokens.CognitoSub   = Json->GetStringField(TEXT("CognitoSub"));
    CurrentTokens.ExpiresIn    = (int32)Json->GetNumberField(TEXT("ExpiresIn"));

    // If we have a refresh token, consider the user logged in.
    // The sync service will refresh the access token if it's expired.
    if (!CurrentTokens.RefreshToken.IsEmpty())
    {
        bIsLoggedIn = true;
        UE_LOG(LogTemp, Log, TEXT("AuthService: Restored session for sub: %s"),
            *CurrentTokens.CognitoSub);
        return true;
    }

    return false;
}

void FGrimoireAuthService::ClearPersistedTokens()
{
    const FString TokenPath = FPaths::ProjectUserDir() / TEXT("session.json");
    IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
    PlatformFile.DeleteFile(*TokenPath);
}
