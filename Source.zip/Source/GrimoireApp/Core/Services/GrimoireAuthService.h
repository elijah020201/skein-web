#pragma once

#include "CoreMinimal.h"
#include "Http.h"

// ============================================================
//  GRIMOIRE APP — Authentication Service
//  GrimoireAuthService.h
//
//  Handles all communication with AWS Cognito:
//    - User registration
//    - Login (returns JWT tokens)
//    - Token refresh (keeps the session alive)
//    - Logout (clears tokens locally)
//
//  All operations are async. Results come back via delegates
//  so the UI can bind to them and update accordingly.
// ============================================================


// ------------------------------------------------------------
//  Result structs — passed back to callers via delegates
// ------------------------------------------------------------

struct FAuthTokens
{
    FString AccessToken;   // Used to authorize API calls (1hr expiry)
    FString IdToken;       // Contains user identity claims
    FString RefreshToken;  // Used to get new tokens (30 day expiry)
    FString CognitoSub;    // The user's permanent unique ID
    int32   ExpiresIn = 0; // Seconds until AccessToken expires
};

struct FAuthResult
{
    bool    bSuccess = false;
    FString ErrorMessage;
    FAuthTokens Tokens; // Only populated on success
};


// ------------------------------------------------------------
//  Delegates — bind these to receive async results
// ------------------------------------------------------------

DECLARE_DELEGATE_OneParam(FOnAuthComplete, const FAuthResult&);


// ------------------------------------------------------------
//  Auth Service
// ------------------------------------------------------------

class GRIMOIREAPP_API FGrimoireAuthService
{
public:

    FGrimoireAuthService();
    ~FGrimoireAuthService() = default;

    // --------------------------------------------------------
    //  Configuration
    //  Call SetConfig once at startup before any auth calls.
    // --------------------------------------------------------

    void SetConfig(const FString& InUserPoolID, const FString& InClientID);

    // --------------------------------------------------------
    //  Auth Operations
    // --------------------------------------------------------

    /** Registers a new user with email and password.
     *  On success the user receives a confirmation email.
     *  They must confirm before they can log in. */
    void RegisterUser(const FString& Email,
                      const FString& Password,
                      FOnAuthComplete OnComplete);

    /** Confirms registration using the code sent to the user's email. */
    void ConfirmRegistration(const FString& Email,
                             const FString& ConfirmationCode,
                             FOnAuthComplete OnComplete);

    /** Logs in with email and password.
     *  On success, tokens are stored internally and
     *  accessible via GetCurrentTokens(). */
    void Login(const FString& Email,
               const FString& Password,
               FOnAuthComplete OnComplete);

    /** Uses the stored refresh token to get new access/id tokens.
     *  Call this when the access token is about to expire. */
    void RefreshSession(FOnAuthComplete OnComplete);

    /** Clears all stored tokens. Call on user logout. */
    void Logout();

    // --------------------------------------------------------
    //  Token Access
    // --------------------------------------------------------

    /** Returns true if the user is currently logged in with valid tokens. */
    bool IsLoggedIn() const;

    /** Returns the current access token for use in API calls.
     *  Returns empty string if not logged in. */
    FString GetAccessToken() const;

    /** Returns the Cognito sub (permanent user ID). */
    FString GetCognitoSub() const;

    /** Returns the full current token set. */
    const FAuthTokens& GetCurrentTokens() const;

private:

    // --------------------------------------------------------
    //  Internal helpers
    // --------------------------------------------------------

    /** Sends a POST request to the Cognito endpoint.
     *  Cognito's API is a single endpoint with an action header. */
    void PostToCognito(const FString& Action,
                       const TSharedPtr<FJsonObject>& Payload,
                       TFunction<void(bool, TSharedPtr<FJsonObject>)> OnResponse);

    /** Parses tokens out of a successful Cognito AuthenticationResult. */
    bool ParseTokensFromResponse(const TSharedPtr<FJsonObject>& ResponseJson,
                                  FAuthTokens& OutTokens);

    /** Saves tokens to local storage so the session survives app restarts. */
    void PersistTokens(const FAuthTokens& Tokens);

    /** Loads persisted tokens on startup. Returns false if none exist. */
    bool LoadPersistedTokens();

    /** Clears persisted tokens from disk. */
    void ClearPersistedTokens();

    // --------------------------------------------------------
    //  Members
    // --------------------------------------------------------

    FString UserPoolID;
    FString ClientID;

    // Cognito's regional endpoint — built from UserPoolID in SetConfig
    FString CognitoEndpoint;

    // Currently active tokens
    FAuthTokens CurrentTokens;
    bool bIsLoggedIn = false;

    // Unreal's HTTP module handle
    FHttpModule* HttpModule = nullptr;
};
