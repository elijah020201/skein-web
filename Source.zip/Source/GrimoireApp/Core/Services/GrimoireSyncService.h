#pragma once

#include "CoreMinimal.h"
#include "Http.h"
#include "Core/DataModel/GrimoireEntry.h"

// ============================================================
//  GRIMOIRE APP — Sync Service
//  GrimoireSyncService.h
//
//  Handles all communication with the Lambda API endpoint.
//  Reads pending entries from the local store and pushes
//  them to DynamoDB via the grimoire-entry-handler Lambda.
//
//  Call SyncPendingEntries() whenever network is available.
//  The service is intentionally fire-and-forget from the
//  UI's perspective — it updates the local store on completion.
// ============================================================

// Forward declarations
class FGrimoireLocalStore;
class FGrimoireAuthService;

DECLARE_DELEGATE_TwoParams(FOnSyncComplete, bool /*bSuccess*/, FString /*ErrorMessage*/);

class GRIMOIREAPP_API FGrimoireSyncService
{
public:

    FGrimoireSyncService(FGrimoireLocalStore* InLocalStore,
                          FGrimoireAuthService* InAuthService);
    ~FGrimoireSyncService() = default;

    // --------------------------------------------------------
    //  Configuration
    // --------------------------------------------------------

    /** Call once at startup with the full API Gateway URL.
     *  e.g. "https://xyz.execute-api.us-east-1.amazonaws.com/prod/grimoire" */
    void SetAPIEndpoint(const FString& InEndpoint);

    // --------------------------------------------------------
    //  Sync Operations
    // --------------------------------------------------------

    /** Finds all locally pending entries and uploads them to DynamoDB.
     *  Safe to call frequently — does nothing if nothing is pending. */
    void SyncPendingEntries(FOnSyncComplete OnComplete);

    /** Downloads all entries from DynamoDB and merges with local store.
     *  Call on first login or to force a full refresh. */
    void FullSync(FOnSyncComplete OnComplete);

    /** Pushes a single entry immediately — used for real-time save. */
    void PushEntry(const FGrimoireEntry& Entry, FOnSyncComplete OnComplete);

    /** Pulls all entries from cloud and returns them via delegate. */
    void PullEntries(TFunction<void(bool, TArray<FGrimoireEntry>)> OnComplete);

private:

    // --------------------------------------------------------
    //  Internal helpers
    // --------------------------------------------------------

    /** Sends a POST request to the Lambda API endpoint. */
    void PostToAPI(const FString& Action,
                   const TSharedPtr<FJsonObject>& Body,
                   TFunction<void(bool, TSharedPtr<FJsonObject>)> OnResponse);

    /** Converts an FGrimoireEntry to a JSON object for the API. */
    TSharedPtr<FJsonObject> EntryToJson(const FGrimoireEntry& Entry);

    /** Converts a JSON object from the API back to an FGrimoireEntry. */
    bool JsonToEntry(const TSharedPtr<FJsonObject>& Json, FGrimoireEntry& OutEntry);

    // --------------------------------------------------------
    //  Members
    // --------------------------------------------------------

    FGrimoireLocalStore*  LocalStore   = nullptr;
    FGrimoireAuthService* AuthService  = nullptr;
    FString               APIEndpoint;
    FHttpModule*          HttpModule   = nullptr;
};
