#include "GrimoireSyncService.h"
#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "Dom/JsonObject.h"
#include "Dom/JsonValue.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "Core/LocalDB/GrimoireLocalStore.h"
#include "Core/Services/GrimoireAuthService.h"

// ============================================================
//  GRIMOIRE APP — Sync Service Implementation
//  GrimoireSyncService.cpp
// ============================================================

FGrimoireSyncService::FGrimoireSyncService(
    FGrimoireLocalStore*  InLocalStore,
    FGrimoireAuthService* InAuthService)
    : LocalStore(InLocalStore)
    , AuthService(InAuthService)
{
    HttpModule = &FHttpModule::Get();
}

void FGrimoireSyncService::SetAPIEndpoint(const FString& InEndpoint)
{
    APIEndpoint = InEndpoint;
    UE_LOG(LogTemp, Log, TEXT("SyncService: API endpoint set to %s"), *APIEndpoint);
}

// ------------------------------------------------------------
//  Sync Pending Entries
//  The main workhorse — called whenever network is available.
//  Iterates all locally pending entries and uploads them one
//  by one. Marks each as Synced on success, Conflict on clash.
// ------------------------------------------------------------

void FGrimoireSyncService::SyncPendingEntries(FOnSyncComplete OnComplete)
{
    if (!AuthService->IsLoggedIn())
    {
        OnComplete.ExecuteIfBound(false, TEXT("Not logged in."));
        return;
    }

    TArray<FGrimoireEntry> PendingEntries;
    if (!LocalStore->LoadPendingSyncEntries(PendingEntries))
    {
        OnComplete.ExecuteIfBound(false, TEXT("Failed to load pending entries."));
        return;
    }

    if (PendingEntries.Num() == 0)
    {
        // Nothing to do — this is the common case
        OnComplete.ExecuteIfBound(true, TEXT(""));
        return;
    }

    UE_LOG(LogTemp, Log, TEXT("SyncService: Syncing %d pending entries."),
        PendingEntries.Num());

    // Use a shared counter to know when all async uploads are done.
    // TSharedPtr keeps it alive across all the async callbacks.
    TSharedPtr<int32> Remaining   = MakeShareable(new int32(PendingEntries.Num()));
    TSharedPtr<bool>  bAnyFailed  = MakeShareable(new bool(false));

    for (const FGrimoireEntry& Entry : PendingEntries)
    {
        // Deleted entries get removed from cloud then hard-deleted locally
        if (Entry.bIsDeleted)
        {
            TSharedPtr<FJsonObject> Body = MakeShareable(new FJsonObject());
            Body->SetStringField(TEXT("entityID"), Entry.EntityID);

            PostToAPI(TEXT("entry:delete"), Body,
                [this, Entry, Remaining, bAnyFailed, OnComplete]
                (bool bSuccess, TSharedPtr<FJsonObject> Response)
                {
                    if (bSuccess)
                        LocalStore->HardDeleteEntry(Entry.EntityID);
                    else
                        *bAnyFailed = true;

                    --(*Remaining);
                    if (*Remaining == 0)
                        OnComplete.ExecuteIfBound(!*bAnyFailed, TEXT(""));
                });
        }
        else
        {
            PushEntry(Entry, FOnSyncComplete::CreateLambda(
                [this, Entry, Remaining, bAnyFailed, OnComplete]
                (bool bSuccess, FString Error)
                {
                    if (!bSuccess) *bAnyFailed = true;

                    --(*Remaining);
                    if (*Remaining == 0)
                        OnComplete.ExecuteIfBound(!*bAnyFailed, TEXT(""));
                }));
        }
    }
}

// ------------------------------------------------------------
//  Full Sync
//  Downloads everything from the cloud and merges it locally.
//  Used on first login or to recover from a conflict state.
// ------------------------------------------------------------

void FGrimoireSyncService::FullSync(FOnSyncComplete OnComplete)
{
    if (!AuthService->IsLoggedIn())
    {
        OnComplete.ExecuteIfBound(false, TEXT("Not logged in."));
        return;
    }

    UE_LOG(LogTemp, Log, TEXT("SyncService: Starting full sync."));

    PullEntries([this, OnComplete](bool bSuccess, TArray<FGrimoireEntry> CloudEntries)
    {
        if (!bSuccess)
        {
            OnComplete.ExecuteIfBound(false, TEXT("Failed to pull entries from cloud."));
            return;
        }

        int32 SavedCount = 0;
        for (FGrimoireEntry& Entry : CloudEntries)
        {
            // Mark as Synced before saving locally
            Entry.SyncStatus = ESyncStatus::Synced;
            if (LocalStore->SaveEntry(Entry))
                ++SavedCount;
        }

        UE_LOG(LogTemp, Log, TEXT("SyncService: Full sync complete. Saved %d entries."),
            SavedCount);
        OnComplete.ExecuteIfBound(true, TEXT(""));
    });
}

// ------------------------------------------------------------
//  Push Single Entry
// ------------------------------------------------------------

void FGrimoireSyncService::PushEntry(
    const FGrimoireEntry& Entry,
    FOnSyncComplete OnComplete)
{
    TSharedPtr<FJsonObject> Body = EntryToJson(Entry);

    PostToAPI(TEXT("entry:save"), Body,
        [this, EntityID = Entry.EntityID, OnComplete]
        (bool bSuccess, TSharedPtr<FJsonObject> Response)
        {
            if (bSuccess && Response.IsValid())
            {
                int32 NewVersion = (int32)Response->GetNumberField(TEXT("version"));
                LocalStore->MarkEntrySynced(EntityID, NewVersion);
                OnComplete.ExecuteIfBound(true, TEXT(""));
            }
            else
            {
                // Check if it was a conflict (409)
                if (Response.IsValid())
                {
                    FString ErrorType = Response->GetStringField(TEXT("error"));
                    if (ErrorType == TEXT("Conflict"))
                    {
                        LocalStore->MarkEntryConflict(EntityID);
                        OnComplete.ExecuteIfBound(false,
                            TEXT("Conflict: entry was modified on another device."));
                        return;
                    }
                }
                OnComplete.ExecuteIfBound(false, TEXT("Failed to push entry to cloud."));
            }
        });
}

// ------------------------------------------------------------
//  Pull Entries
// ------------------------------------------------------------

void FGrimoireSyncService::PullEntries(
    TFunction<void(bool, TArray<FGrimoireEntry>)> OnComplete)
{
    TSharedPtr<FJsonObject> Body = MakeShareable(new FJsonObject());
    // No filter — pull all entry types
    Body->SetStringField(TEXT("entryType"), TEXT(""));

    PostToAPI(TEXT("entry:list"), Body,
        [this, OnComplete](bool bSuccess, TSharedPtr<FJsonObject> Response)
        {
            TArray<FGrimoireEntry> Entries;

            if (!bSuccess || !Response.IsValid())
            {
                OnComplete(false, Entries);
                return;
            }

            const TArray<TSharedPtr<FJsonValue>>* EntriesArray = nullptr;
            if (Response->TryGetArrayField(TEXT("entries"), EntriesArray))
            {
                for (const TSharedPtr<FJsonValue>& Val : *EntriesArray)
                {
                    FGrimoireEntry Entry;
                    if (JsonToEntry(Val->AsObject(), Entry))
                        Entries.Add(Entry);
                }
            }

            OnComplete(true, Entries);
        });
}

// ------------------------------------------------------------
//  Internal — HTTP
// ------------------------------------------------------------

void FGrimoireSyncService::PostToAPI(
    const FString& Action,
    const TSharedPtr<FJsonObject>& Body,
    TFunction<void(bool, TSharedPtr<FJsonObject>)> OnResponse)
{
    // Build the full request payload
    TSharedPtr<FJsonObject> Payload = MakeShareable(new FJsonObject());
    Payload->SetStringField(TEXT("action"), Action);
    Payload->SetStringField(TEXT("userID"), AuthService->GetCognitoSub());
    Payload->SetObjectField(TEXT("body"),   Body);

    FString BodyString;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&BodyString);
    FJsonSerializer::Serialize(Payload.ToSharedRef(), Writer);

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = HttpModule->CreateRequest();
    Request->SetURL(APIEndpoint);
    Request->SetVerb(TEXT("POST"));
    Request->SetHeader(TEXT("Content-Type"),   TEXT("application/json"));
    Request->SetHeader(TEXT("Authorization"),  AuthService->GetAccessToken());
    Request->SetContentAsString(BodyString);

    Request->OnProcessRequestComplete().BindLambda(
        [OnResponse](FHttpRequestPtr Req, FHttpResponsePtr Resp, bool bConnected)
        {
            if (!bConnected || !Resp.IsValid())
            {
                UE_LOG(LogTemp, Error, TEXT("SyncService: No response from API."));
                OnResponse(false, nullptr);
                return;
            }

            TSharedPtr<FJsonObject> JsonResponse;
            TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(
                Resp->GetContentAsString());
            FJsonSerializer::Deserialize(Reader, JsonResponse);

            const bool bSuccess = Resp->GetResponseCode() >= 200
                                && Resp->GetResponseCode() < 300;
            OnResponse(bSuccess, JsonResponse);
        });

    Request->ProcessRequest();
}

// ------------------------------------------------------------
//  Internal — JSON Conversion
// ------------------------------------------------------------

TSharedPtr<FJsonObject> FGrimoireSyncService::EntryToJson(const FGrimoireEntry& Entry)
{
    TSharedPtr<FJsonObject> Json = MakeShareable(new FJsonObject());

    Json->SetStringField(TEXT("entityID"),    Entry.EntityID);
    Json->SetStringField(TEXT("title"),       Entry.Title);
    Json->SetStringField(TEXT("entryType"),   Entry.GetTypeDisplayName());
    Json->SetStringField(TEXT("collectionID"),Entry.CollectionID);
    Json->SetStringField(TEXT("createdAt"),   Entry.CreatedAt);
    Json->SetStringField(TEXT("updatedAt"),   Entry.UpdatedAt);
    Json->SetNumberField(TEXT("version"),     Entry.Version);
    Json->SetBoolField  (TEXT("isPinned"),    Entry.bIsPinned);
    Json->SetBoolField  (TEXT("isFavourite"), Entry.bIsFavourite);
    Json->SetBoolField  (TEXT("isDeleted"),   Entry.bIsDeleted);

    // Tags array
    TArray<TSharedPtr<FJsonValue>> TagsArray;
    for (const FString& Tag : Entry.Tags)
        TagsArray.Add(MakeShareable(new FJsonValueString(Tag)));
    Json->SetArrayField(TEXT("tags"), TagsArray);

    // Visibility as string
    const FString VisibilityStr =
        Entry.Visibility == EEntryVisibility::Private ? TEXT("Private") :
        Entry.Visibility == EEntryVisibility::Coven   ? TEXT("Coven")   : TEXT("Public");
    Json->SetStringField(TEXT("visibility"), VisibilityStr);

    // Template data is already serialized as JSON in the local store —
    // we re-parse it here to send as a nested object rather than a string
    // so DynamoDB stores it as a proper map rather than an escaped string
    TSharedPtr<FJsonObject> TemplateJson = MakeShareable(new FJsonObject());
    TemplateJson->SetStringField(TEXT("entryType"), Entry.GetTypeDisplayName());
    Json->SetObjectField(TEXT("templateData"), TemplateJson);

    return Json;
}

bool FGrimoireSyncService::JsonToEntry(
    const TSharedPtr<FJsonObject>& Json, FGrimoireEntry& OutEntry)
{
    if (!Json.IsValid()) return false;

    OutEntry.EntityID    = Json->GetStringField(TEXT("EntityID"));
    OutEntry.OwnerUserID = Json->GetStringField(TEXT("OwnerUserID"));
    OutEntry.Title       = Json->GetStringField(TEXT("Title"));
    OutEntry.CollectionID= Json->GetStringField(TEXT("CollectionID"));
    OutEntry.CreatedAt   = Json->GetStringField(TEXT("CreatedAt"));
    OutEntry.UpdatedAt   = Json->GetStringField(TEXT("UpdatedAt"));
    OutEntry.Version     = (int32)Json->GetNumberField(TEXT("Version"));
    OutEntry.bIsPinned   = Json->GetBoolField(TEXT("IsPinned"));
    OutEntry.bIsFavourite= Json->GetBoolField(TEXT("IsFavourite"));
    OutEntry.bIsDeleted  = Json->GetBoolField(TEXT("IsDeleted"));
    OutEntry.SyncStatus  = ESyncStatus::Synced;

    // Tags
    const TArray<TSharedPtr<FJsonValue>>* TagsArray = nullptr;
    if (Json->TryGetArrayField(TEXT("Tags"), TagsArray))
        for (auto& V : *TagsArray) OutEntry.Tags.Add(V->AsString());

    // Entry type
    FString TypeStr = Json->GetStringField(TEXT("EntryType"));
    if      (TypeStr == TEXT("Spell"))               OutEntry.EntryType = EGrimoireEntryType::Spell;
    else if (TypeStr == TEXT("Ritual"))              OutEntry.EntryType = EGrimoireEntryType::Ritual;
    else if (TypeStr == TEXT("Journal Entry"))       OutEntry.EntryType = EGrimoireEntryType::JournalEntry;
    else if (TypeStr == TEXT("Herbal Correspondence"))OutEntry.EntryType = EGrimoireEntryType::HerbalCorrespondence;
    else if (TypeStr == TEXT("Sigil & Symbol"))      OutEntry.EntryType = EGrimoireEntryType::Sigil;
    else if (TypeStr == TEXT("Astrological Data"))   OutEntry.EntryType = EGrimoireEntryType::AstrologicalData;
    else if (TypeStr == TEXT("Tarot Log"))           OutEntry.EntryType = EGrimoireEntryType::TarotLog;
    else                                              OutEntry.EntryType = EGrimoireEntryType::Custom;

    return !OutEntry.EntityID.IsEmpty();
}
